package com.api.controller;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.api.model.BeanTest;
import com.api.model.MessageBean;

@RestController
public class TestController {
	
	@Autowired
	private MessageSource messagesource;
	//@RequestMapping(method=RequestMethod.GET, path="/test")
	@GetMapping(path="/test")
	public String testMethod() {
		return "Hello TestController....";
	}
	
	@GetMapping(path="/beantest")
	public BeanTest helloWorldBean() {
		return new BeanTest("Harendra", "HelloBean", "Delhi/NCR");
	}
	@GetMapping(path="/beantest/path-variable/{name}")
	public MessageBean helloWorldBeanPathVariable(@PathVariable String name) {
		return new MessageBean(String.format("HelloWorld Message, %s", name));
	}
	
	@GetMapping(path= "/internationalized")
	public String apiInternationalized(@RequestHeader(name="Accept-Language", required=false) Locale locale) {
		//return messagesource.getMessage("good.morning.message", null, locale);
		return messagesource.getMessage("good.morning.message", null, LocaleContextHolder.getLocale());
	}

}
