package com.api.model;

public class Plans {
	private int id;
	private double coins;
	private double price;
	private double discountprice;
	private int sortorder;
	private double bestvalue;
	private int isdeleted;
	
	
	public Plans(int id, double coins, double price, double discountprice, int sortorder, double bestvalue,
			int isdeleted) {
		super();
		this.id = id;
		this.coins = coins;
		this.price = price;
		this.discountprice = discountprice;
		this.sortorder = sortorder;
		this.bestvalue = bestvalue;
		this.isdeleted = isdeleted;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getCoins() {
		return coins;
	}
	public void setCoins(double coins) {
		this.coins = coins;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public double getDiscountprice() {
		return discountprice;
	}
	public void setDiscountprice(double discountprice) {
		this.discountprice = discountprice;
	}
	public int getSortorder() {
		return sortorder;
	}
	public void setSortorder(int sortorder) {
		this.sortorder = sortorder;
	}
	public double getBestvalue() {
		return bestvalue;
	}
	public void setBestvalue(double bestvalue) {
		this.bestvalue = bestvalue;
	}
	public int getIsdeleted() {
		return isdeleted;
	}
	public void setIsdeleted(int isdeleted) {
		this.isdeleted = isdeleted;
	}
	@Override
	public String toString() {
		return "Plans [id=" + id + ", coins=" + coins + ", price=" + price + ", discountprice=" + discountprice
				+ ", sortorder=" + sortorder + ", bestvalue=" + bestvalue + ", isdeleted=" + isdeleted + "]";
	}
	

}
