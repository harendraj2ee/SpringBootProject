INSERT INTO dog(name,rescued,vaccinated)VALUES('Fluffy ','2017-08-11','1');
INSERT INTO dog(name,rescued,vaccinated)VALUES('Pooch','2017-07-21','1');
INSERT INTO dog(name,rescued,vaccinated)VALUES('Buddy','2017-08-25','0');