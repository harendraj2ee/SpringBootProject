package com.main.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class DashBoardController {
	
	@GetMapping("/login")
	public String login() {		
		return "login";		
	}
	
	@RequestMapping("/dashboard")
	public String login(Model model) {
		
		Map<String, String> aValue=new LinkedHashMap<String, String>();
		aValue.put("value1", "235");
		aValue.put("value2", "235");
		aValue.put("value3", "235");
		aValue.put("value4", "235");
		aValue.put("value5", "235");
		
		model.addAttribute("echart_donut", aValue);
		System.out.println(model);
		return "echarts";
	}

}
