package com.example.springbootdynamicchart.daos;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.springbootdynamicchart.data.CanvasjsChartData;

/** @author 		: RiteshVishwakarma 						*/
/** Organization	: International Business Machine*/
/** Project Name	: springbootdynamicchart 				*/
/** Class Name		: CanvasjsChartDaoImpl.java 					*/
/** Create Date : 13-Aug-2019 4:19:34 pm */
@Repository
public class CanvasjsChartDaoImpl implements CanvasjsChartDao {

	@Autowired
	private CanvasjsChartData canvasjsChartData;

	/**
	 * @param canvasjsChartData the canvasjsChartData to set
	 */
	public void setCanvasjsChartData(CanvasjsChartData canvasjsChartData) {
		this.canvasjsChartData = canvasjsChartData;
	}

	@Override
	public List<List<Map<Object, Object>>> getCanvasjsChartData() {
		return canvasjsChartData.getCanvasjsDataList();
	}

	@Override
	public List<List<Map<Object, Object>>> getCanvasjsChartData2() {
		return canvasjsChartData.getCanvasjsDataList2();
	}

}