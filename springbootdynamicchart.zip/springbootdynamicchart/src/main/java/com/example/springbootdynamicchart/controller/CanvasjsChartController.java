package com.example.springbootdynamicchart.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.springbootdynamicchart.services.CanvasjsChartService;

/** @author 		: RiteshVishwakarma 						*/
/** Organization	: International Business Machine*/
/** Project Name	: springbootdynamicchart 				*/
/** Class Name		: CanvasjsChartController.java 					*/
/** Create Date		: 13-Aug-2019 4:14:04 pm 				*/

@Controller
public class CanvasjsChartController {

	@Autowired
	private CanvasjsChartService canvasjsChartService;
	
	@RequestMapping(value="/canvasjschart1")
	public String doughnutChart1(ModelMap modelMap) {
		System.out.println("canvasjschart called....");
		List<List<Map<Object, Object>>> canvasjsDataList = canvasjsChartService.getCanvasjsChartData();
		modelMap.addAttribute("dataPointsList", canvasjsDataList);
		return "chart";
		
	}
	
	@RequestMapping("/canvasjschart2")
	public String doughnutChart2(ModelMap modelMap) {
		List<List<Map<Object, Object>>> canvasjsDataList = canvasjsChartService.getCanvasjsChartData2();
		modelMap.addAttribute("dataPointsList", canvasjsDataList);
		return "chart2";
	}
	
	@RequestMapping("/index")
	public String hello() {
		System.out.println("hello");
		return "index";
	}
}
