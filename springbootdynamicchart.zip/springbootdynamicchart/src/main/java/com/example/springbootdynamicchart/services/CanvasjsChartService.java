package com.example.springbootdynamicchart.services;

import java.util.List;
import java.util.Map;

/** @author 		: RiteshVishwakarma 						*/
/** Organization	: International Business Machine*/
/** Project Name	: springbootdynamicchart 				*/
/** Class Name		: CanvasjsChartService.java 					*/
/** Create Date : 13-Aug-2019 4:16:53 pm */
public interface CanvasjsChartService {
	List<List<Map<Object, Object>>> getCanvasjsChartData();
	List<List<Map<Object, Object>>> getCanvasjsChartData2();
}
