package com.example.springbootdynamicchart.daos;

import java.util.List;
import java.util.Map;

/** @author 		: RiteshVishwakarma 						*/
/** Organization	: International Business Machine*/
/** Project Name	: springbootdynamicchart 				*/
/** Class Name		: CanvasjsChartDao.java 					*/
/** Create Date : 13-Aug-2019 4:18:59 pm */
public interface CanvasjsChartDao {
	List<List<Map<Object, Object>>> getCanvasjsChartData();
	List<List<Map<Object, Object>>> getCanvasjsChartData2();
}
