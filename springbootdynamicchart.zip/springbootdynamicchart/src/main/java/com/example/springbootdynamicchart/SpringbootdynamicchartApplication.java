package com.example.springbootdynamicchart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootdynamicchartApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootdynamicchartApplication.class, args);
	}

}
