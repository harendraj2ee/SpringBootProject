package com.example.springbootdynamicchart.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/** @author 		: RiteshVishwakarma 						*/
/** Organization	: International Business Machine*/
/** Project Name	: springbootdynamicchart 				*/
/** Class Name		: CanvasjsChartData.java 					*/
/** Create Date : 13-Aug-2019 4:20:37 pm */

@Repository
public class CanvasjsChartData {

	public List<List<Map<Object, Object>>> getCanvasjsDataList() {
		Map<Object, Object> map = null;
		List<List<Map<Object, Object>>> list = new ArrayList<List<Map<Object, Object>>>();
		List<Map<Object, Object>> dataPoints1 = new ArrayList<Map<Object, Object>>();

		map = new HashMap<Object, Object>();
		map.put("name", "Overhead");
		map.put("y", 9.1);
		dataPoints1.add(map);
		map = new HashMap<Object, Object>();
		map.put("name", "Problem Solving");
		map.put("y", 3.7);
		dataPoints1.add(map);
		map = new HashMap<Object, Object>();
		map.put("name", "Debugging");
		map.put("y", 36.4);
		dataPoints1.add(map);
		map = new HashMap<Object, Object>();
		map.put("name", "Writing Code");
		map.put("y", 30.7);
		dataPoints1.add(map);
		map = new HashMap<Object, Object>();
		map.put("name", "Firefighting");
		map.put("y", 20.1);
		dataPoints1.add(map);

		list.add(dataPoints1);
		return list;
	}

	public List<List<Map<Object, Object>>> getCanvasjsDataList2() {

		Map<Object, Object> map = null;
		List<List<Map<Object, Object>>> list = new ArrayList<List<Map<Object, Object>>>();
		List<Map<Object, Object>> dataPoints1 = new ArrayList<Map<Object, Object>>();
		List<Map<Object, Object>> dataPoints2 = new ArrayList<Map<Object, Object>>();
		List<Map<Object, Object>> dataPoints3 = new ArrayList<Map<Object, Object>>();

		map = new HashMap<Object, Object>();
		map.put("name", "New Visitors");
		map.put("y", 519960);
		map.put("color", "#E7823A");
		dataPoints1.add(map);
		map = new HashMap<Object, Object>();
		map.put("name", "Returning Visitors");
		map.put("y", 363040);
		map.put("color", "#546BC1");
		dataPoints1.add(map);

		map = new HashMap<Object, Object>();
		map.put("x", 1420050600000L);
		map.put("y", 33000);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1422729000000L);
		map.put("y", 35960);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1425148200000L);
		map.put("y", 42160);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1427826600000L);
		map.put("y", 42240);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1430418600000L);
		map.put("y", 43200);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1433097000000L);
		map.put("y", 40600);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1435689000000L);
		map.put("y", 42560);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1438367400000L);
		map.put("y", 44280);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1441045800000L);
		map.put("y", 44800);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1443637800000L);
		map.put("y", 48720);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1446316200000L);
		map.put("y", 50840);
		dataPoints2.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1448908200000L);
		map.put("y", 51600);
		dataPoints2.add(map);

		map = new HashMap<Object, Object>();
		map.put("x", 1420050600000L);
		map.put("y", 22000);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1422729000000L);
		map.put("y", 26040);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1425148200000L);
		map.put("y", 25840);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1427826600000L);
		map.put("y", 23760);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1430418600000L);
		map.put("y", 28800);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1433097000000L);
		map.put("y", 29400);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1435689000000L);
		map.put("y", 33440);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1438367400000L);
		map.put("y", 37720);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1441045800000L);
		map.put("y", 35200);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1443637800000L);
		map.put("y", 35280);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1446316200000L);
		map.put("y", 31160);
		dataPoints3.add(map);
		map = new HashMap<Object, Object>();
		map.put("x", 1448908200000L);
		map.put("y", 34400);
		dataPoints3.add(map);

		list.add(dataPoints1);
		list.add(dataPoints2);
		list.add(dataPoints3);

		return list;
	}
}