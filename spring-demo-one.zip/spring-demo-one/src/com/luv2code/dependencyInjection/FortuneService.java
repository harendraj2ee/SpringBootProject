package com.luv2code.dependencyInjection;

public interface FortuneService {

	public String getFortune();
	
}
