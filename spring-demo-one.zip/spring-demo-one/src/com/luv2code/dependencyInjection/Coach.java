package com.luv2code.dependencyInjection;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();

}
