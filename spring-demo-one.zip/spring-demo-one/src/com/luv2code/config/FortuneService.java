package com.luv2code.config;

public interface FortuneService {

	public String getFortune();
	
}
