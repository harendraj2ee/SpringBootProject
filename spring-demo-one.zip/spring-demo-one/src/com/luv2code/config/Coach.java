package com.luv2code.config;

public interface Coach {

	public String getDailyWorkout();

	public String getDailyFortune();
	
}
