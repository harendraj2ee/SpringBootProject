package com.luv2code.configInjectValuesFomPropertiesFile;

public interface Coach {

	public String getDailyWorkout();

	public String getDailyFortune();
	
}
