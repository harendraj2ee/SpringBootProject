package com.luv2code.configInjectValuesFomPropertiesFile;

public interface FortuneService {

	public String getFortune();
	
}
