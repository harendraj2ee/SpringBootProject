package com.luv2code.ioc;

public interface Coach {

	public String getDailyWorkout();
	
}
