package com.luv2code.annotationDefaultComponentNames;

public interface Coach {

	public String getDailyWorkout();
	
}
