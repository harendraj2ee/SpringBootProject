package com.luv2code.injectingValuesFromPropertiesFile;

public interface FortuneService {

	public String getFortune();
	
}
