package com.luv2code.injectingValuesFromPropertiesFile;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();

}
