package com.luv2code.configDefineBeans;

public interface Coach {

	public String getDailyWorkout();

	public String getDailyFortune();
	
}
