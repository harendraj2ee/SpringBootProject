package com.luv2code.configDefineBeans;

public interface FortuneService {

	public String getFortune();
	
}
