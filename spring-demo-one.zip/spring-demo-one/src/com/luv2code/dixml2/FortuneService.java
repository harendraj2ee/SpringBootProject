package com.luv2code.dixml2;

public interface FortuneService {

	public String getFortune();
	
}
