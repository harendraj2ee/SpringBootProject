package com.luv2code.dixml2;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
