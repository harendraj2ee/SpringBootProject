package com.luv2code.roughPrototype;

public interface Coach {

	public String getDailyWorkout();
	
}
