package com.luv2code.iocxml1;

public interface Coach {

	public String getDailyWorkout();
	
}
