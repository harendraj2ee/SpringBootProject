package com.luv2code.iocxml1;

public class GolfCoach implements Coach {

	@Override
	public String getDailyWorkout() {
		return "Practice your putting skills for 2 hours today";
	}

}
