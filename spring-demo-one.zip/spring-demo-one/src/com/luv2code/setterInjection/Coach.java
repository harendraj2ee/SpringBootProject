package com.luv2code.setterInjection;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();

}
