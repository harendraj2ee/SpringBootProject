package com.luv2code.setterInjection;

public interface FortuneService {

	public String getFortune();
	
}
