package com.luv2code.iocannotations4;

public interface Coach {

	public String getDailyWorkout();
	
}
