package com.luv2code.annotationBeanScope;

public interface Coach {

	public String getDailyWorkout();

	public String getDailyFortune();
	
}
