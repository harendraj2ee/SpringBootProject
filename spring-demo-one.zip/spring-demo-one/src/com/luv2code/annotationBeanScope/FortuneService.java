package com.luv2code.annotationBeanScope;

public interface FortuneService {

	public String getFortune();
	
}
