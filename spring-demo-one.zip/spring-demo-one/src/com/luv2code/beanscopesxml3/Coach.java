package com.luv2code.beanscopesxml3;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
