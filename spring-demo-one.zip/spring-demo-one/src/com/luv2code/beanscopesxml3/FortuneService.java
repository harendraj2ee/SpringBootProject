package com.luv2code.beanscopesxml3;

public interface FortuneService {

	public String getFortune();
	
}
