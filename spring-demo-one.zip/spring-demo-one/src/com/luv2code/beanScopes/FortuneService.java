package com.luv2code.beanScopes;

public interface FortuneService {

	public String getFortune();
	
}
