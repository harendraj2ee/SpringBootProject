package com.luv2code.beanScopes;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();

}
