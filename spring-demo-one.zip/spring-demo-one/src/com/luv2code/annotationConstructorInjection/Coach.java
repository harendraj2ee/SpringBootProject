package com.luv2code.annotationConstructorInjection;

public interface Coach {

	public String getDailyWorkout();

	public String getDailyFortune();
	
}
