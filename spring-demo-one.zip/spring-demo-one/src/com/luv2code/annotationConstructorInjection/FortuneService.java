package com.luv2code.annotationConstructorInjection;

public interface FortuneService {

	public String getFortune();
	
}
