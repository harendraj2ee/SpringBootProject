package com.luv2code.beanLifeCycle;

public interface FortuneService {

	public String getFortune();
	
}
