package com.luv2code.annotationBeanLifecycleMethods;

public interface Coach {

	public String getDailyWorkout();

	public String getDailyFortune();
	
}
