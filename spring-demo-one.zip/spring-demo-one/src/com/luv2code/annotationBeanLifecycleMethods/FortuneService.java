package com.luv2code.annotationBeanLifecycleMethods;

public interface FortuneService {

	public String getFortune();
	
}
