package com.luv2code.beanscopesannotations6;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
