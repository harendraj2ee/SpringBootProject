package com.luv2code.beanscopesannotations6;

public interface FortuneService {

	public String getFortune();
	
}
