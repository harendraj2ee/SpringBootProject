package com.luv2code.annotations5di;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
