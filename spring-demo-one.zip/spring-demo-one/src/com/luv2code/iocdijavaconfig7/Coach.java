package com.luv2code.iocdijavaconfig7;

public interface Coach {

	public String getDailyWorkout();
	
	public String getDailyFortune();
	
}
