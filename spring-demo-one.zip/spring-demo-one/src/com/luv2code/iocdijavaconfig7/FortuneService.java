package com.luv2code.iocdijavaconfig7;

public interface FortuneService {

	public String getFortune();
	
}
