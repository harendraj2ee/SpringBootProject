package com.infinity.onlinetest.v1.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.infinity.onlinetest.v1.entity.Technology;
import com.infinity.onlinetest.v1.entity.User;


@Repository
public interface TechnologyRepository extends PagingAndSortingRepository<Technology, Long> {
	
	Page<Technology> findByIsPublishedTrue(Pageable pageable);

	Page<Technology> findByCreatedBy(User user, Pageable pageable);

	@Query("select t from Technology t where t.name like %?1%")
	Page<Technology> searchByName(String name, Pageable pageable);

}
