package com.infinity.onlinetest.v1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infinity.onlinetest.v1.entity.UserQuiz;


public interface UserQuizRepository extends JpaRepository<UserQuiz, Long>{

}
