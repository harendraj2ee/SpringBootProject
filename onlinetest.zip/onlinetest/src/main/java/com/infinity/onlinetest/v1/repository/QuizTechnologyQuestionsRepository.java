package com.infinity.onlinetest.v1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infinity.onlinetest.v1.entity.QuizTechnologyQuestions;

public interface QuizTechnologyQuestionsRepository extends JpaRepository<QuizTechnologyQuestions, Long>{

}
