package com.infinity.onlinetest.v1.entity;

import java.util.Calendar;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "technology_question")
public class TechnologyQuestion extends BaseModel  {

	@Size(min = 2, max = 150, message = "The question should be between 2 and 150 characters")
	@NotNull(message = "Question text not provided")
	private String text;

	@ManyToOne
	@JsonIgnore
	private Technology technology;

	@Column(name = "q_order")
	private Integer order;

	//@JsonIgnore
	@OneToMany(mappedBy = "technology_question", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	private List<TechnologyAnswer> answers;

	@JsonIgnore
	@OneToOne
	private TechnologyAnswer correctAnswer;

	@Column(columnDefinition = "TIMESTAMP DEFAULT CURRENT_TIMESTAMP", insertable = false, updatable = false)
	private Calendar createdDate;

	@JsonIgnore
	private Boolean isValid = false;

	public Calendar getCreatedDate() {
		return createdDate;
	}

	public List<TechnologyAnswer> getAnswers() {
		return answers;
	}

	public void setAnswers(List<TechnologyAnswer> answers) {
		this.answers = answers;
	}


	public Technology getTechnology() {
		return technology;
	}

	public void setTechnology(Technology technology) {
		this.technology = technology;
	}

	public void setCreatedDate(Calendar createdDate) {
		this.createdDate = createdDate;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}


	public Integer getOrder() {
		return order;
	}

	public void setOrder(Integer order) {
		this.order = order;
	}

	public Boolean getIsValid() {
		return isValid;
	}

	public void setIsValid(Boolean isValid) {
		this.isValid = isValid;
	}

	public TechnologyAnswer getCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswer(TechnologyAnswer correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

}
