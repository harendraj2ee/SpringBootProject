package com.infinity.onlinetest.v1.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "user-quiz-questions")
public class UserQuizQuestions {
	
	@Column(name = "user_id")
	private Integer userId;
	
	@Column(name = "technology_id")
	private Integer technologyId;
	
	@Column(name = "tech_question_id")
	private Integer techQuestionId;
	
	@Column(name="answer_id")
	private Integer answerId;
	
	@Column(name="correct_answer_id")
	private Integer correctAnswerId;
	
	@Column(name="date_of_quiz")
	private Date dateOfQuiz;
	
	@Column(name="rule_breached")
	private Boolean ruleBreached;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(Integer technologyId) {
		this.technologyId = technologyId;
	}

	public Integer getTechQuestionId() {
		return techQuestionId;
	}

	public void setTechQuestionId(Integer techQuestionId) {
		this.techQuestionId = techQuestionId;
	}

	public Integer getAnswerId() {
		return answerId;
	}

	public void setAnswerId(Integer answerId) {
		this.answerId = answerId;
	}

	public Integer getCorrectAnswerId() {
		return correctAnswerId;
	}

	public void setCorrectAnswerId(Integer correctAnswerId) {
		this.correctAnswerId = correctAnswerId;
	}

	public Date getDateOfQuiz() {
		return dateOfQuiz;
	}

	public void setDateOfQuiz(Date dateOfQuiz) {
		this.dateOfQuiz = dateOfQuiz;
	}

	public Boolean getRuleBreached() {
		return ruleBreached;
	}

	public void setRuleBreached(Boolean ruleBreached) {
		this.ruleBreached = ruleBreached;
	}
	

}
