package com.infinity.onlinetest.v1.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infinity.onlinetest.v1.entity.QuizTemplate;


public interface QuizTemplateRepository extends JpaRepository<QuizTemplate, Long>{

}
