package com.infinity.onlinetest.v1.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "quiz-technology-questions")
public class QuizTechnologyQuestions {
	
	@Column(name = "quiz_template_id")
	private Integer quizTemplateId;
	
	@Column(name="tech_question_id")
	private Integer techQuestionId;

	public Integer getQuizTemplateId() {
		return quizTemplateId;
	}

	public void setQuizTemplateId(Integer quizTemplateId) {
		this.quizTemplateId = quizTemplateId;
	}

	public Integer getTechQuestionId() {
		return techQuestionId;
	}

	public void setTechQuestionId(Integer techQuestionId) {
		this.techQuestionId = techQuestionId;
	}
	

}
