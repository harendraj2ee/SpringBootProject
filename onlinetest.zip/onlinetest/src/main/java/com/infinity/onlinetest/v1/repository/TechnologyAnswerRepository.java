package com.infinity.onlinetest.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infinity.onlinetest.v1.entity.TechnologyAnswer;
import com.infinity.onlinetest.v1.entity.TechnologyQuestion;



public interface TechnologyAnswerRepository extends JpaRepository<TechnologyAnswer, Long>{

	int countByQuestion(TechnologyQuestion question);

	List<TechnologyAnswer> findByQuestionOrderByOrderAsc(TechnologyQuestion question);
}
