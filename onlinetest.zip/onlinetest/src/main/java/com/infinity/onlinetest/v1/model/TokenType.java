package com.infinity.onlinetest.v1.model;

public enum TokenType {
	REGISTRATION_MAIL, FORGOT_PASSWORD
}
