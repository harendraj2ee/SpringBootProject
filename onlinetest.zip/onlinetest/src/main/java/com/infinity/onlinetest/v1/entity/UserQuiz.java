package com.infinity.onlinetest.v1.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "user_quiz")
public class UserQuiz {
	
	@Column(name = "user_id")
	private Integer userId;
	
	@Column(name = "technology_id")
	private Integer technologyId;
	
	@Column(name = "enabled")
	private Boolean enabled;
	
	@Column(name = "test_attempted_on")
	private Date testAttemptedOn;
	
	@Column(name= "test_finished_on")
	private Date testFinishedOn;
	
	@Column(name= "question_attempted")
	private Integer questionAttempted;
	
	@Column(name= "correct_answer")
	private Integer correctAnswer;
	
	@Column(name= "pass")
	private String passFlag;
	
	@Column(name= "ip")
	private String ipAddress;

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public Integer getTechnologyId() {
		return technologyId;
	}

	public void setTechnologyId(Integer technologyId) {
		this.technologyId = technologyId;
	}

	public Boolean getEnabled() {
		return enabled;
	}

	public void setEnabled(Boolean enabled) {
		this.enabled = enabled;
	}

	public Date getTestAttemptedOn() {
		return testAttemptedOn;
	}

	public void setTestAttemptedOn(Date testAttemptedOn) {
		this.testAttemptedOn = testAttemptedOn;
	}

	public Date getTestFinishedOn() {
		return testFinishedOn;
	}

	public void setTestFinishedOn(Date testFinishedOn) {
		this.testFinishedOn = testFinishedOn;
	}

	public Integer getQuestionAttempted() {
		return questionAttempted;
	}

	public void setQuestionAttempted(Integer questionAttempted) {
		this.questionAttempted = questionAttempted;
	}

	public Integer getCorrectAnswer() {
		return correctAnswer;
	}

	public void setCorrectAnswer(Integer correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	public String getPassFlag() {
		return passFlag;
	}

	public void setPassFlag(String passFlag) {
		this.passFlag = passFlag;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	

}
