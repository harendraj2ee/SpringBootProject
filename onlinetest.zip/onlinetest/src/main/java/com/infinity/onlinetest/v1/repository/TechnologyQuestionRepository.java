package com.infinity.onlinetest.v1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infinity.onlinetest.v1.entity.Technology;
import com.infinity.onlinetest.v1.entity.TechnologyQuestion;



public interface TechnologyQuestionRepository extends JpaRepository<TechnologyQuestion, Long>{

	int countByQuiz(Technology technology);

	int countByQuizAndIsValidTrue(Technology technology);

	List<TechnologyQuestion> findByQuizOrderByOrderAsc(Technology technology);

	List<TechnologyQuestion> findByQuizAndIsValidTrueOrderByOrderAsc(Technology technology);
}
