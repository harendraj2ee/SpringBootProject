package com.infinity.onlinetest.v1.controller;

public class UserController {

}
