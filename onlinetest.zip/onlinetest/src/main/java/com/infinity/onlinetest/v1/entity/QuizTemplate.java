package com.infinity.onlinetest.v1.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name = "quiz_template")
public class QuizTemplate extends BaseModel{

	
	@Column(name = "enabled")
	private Boolean isPublished;
	
	@Column(name = "quiz_template_name")
	private String  quizTemplateName;
	
	@Column(name="quiz_start_date")
	private Date quizStartDate;
	
	@Column(name="quiz_end_date")
	private Date quizEndDate;
	
	@Column(name="technology_mapping")
	private String technologyMapping;
	
	@Column(name="period_of_quiz")
	private String periodOfQuiz;
	
	@Column(name="min_quiz_passing_criteria")
	private String minQuizPassingCriteria;



	public Boolean getIsPublished() {
		return isPublished;
	}

	public void setIsPublished(Boolean isPublished) {
		this.isPublished = isPublished;
	}

	public String getQuizTemplateName() {
		return quizTemplateName;
	}

	public void setQuizTemplateName(String quizTemplateName) {
		this.quizTemplateName = quizTemplateName;
	}

	public Date getQuizStartDate() {
		return quizStartDate;
	}

	public void setQuizStartDate(Date quizStartDate) {
		this.quizStartDate = quizStartDate;
	}

	public Date getQuizEndDate() {
		return quizEndDate;
	}

	public void setQuizEndDate(Date quizEndDate) {
		this.quizEndDate = quizEndDate;
	}

	public String getTechnologyMapping() {
		return technologyMapping;
	}

	public void setTechnologyMapping(String technologyMapping) {
		this.technologyMapping = technologyMapping;
	}

	public String getPeriodOfQuiz() {
		return periodOfQuiz;
	}

	public void setPeriodOfQuiz(String periodOfQuiz) {
		this.periodOfQuiz = periodOfQuiz;
	}

	public String getMinQuizPassingCriteria() {
		return minQuizPassingCriteria;
	}

	public void setMinQuizPassingCriteria(String minQuizPassingCriteria) {
		this.minQuizPassingCriteria = minQuizPassingCriteria;
	}
	

}
