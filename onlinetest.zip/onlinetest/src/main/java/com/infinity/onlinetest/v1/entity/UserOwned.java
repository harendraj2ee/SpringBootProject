package com.infinity.onlinetest.v1.entity;

public interface UserOwned {
	User getUser();
}
