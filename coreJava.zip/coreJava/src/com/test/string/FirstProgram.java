package com.test.string;

class FirstProgram {
public static void main(String[] args) {

   String myName = "PRASHAN";
   System.out.println("Hello " + myName);

   myName = "PRABHU";
   System.out.println("Hello " + myName);
   }
}