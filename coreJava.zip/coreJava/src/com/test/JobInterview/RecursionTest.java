package com.test.JobInterview;

import java.util.TreeSet;

public class RecursionTest {

	public static void main(String[] args) {
		TreeSet t = new TreeSet();
		t.add("AA");
		t.add("AA");
		
		
	}

}
