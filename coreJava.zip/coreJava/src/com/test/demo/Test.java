package com.test.demo;

public class Test {
	public static void main(String args[]){
		int x=4;
		System.out.println(x++);  //4
		System.out.println(x);    //5
		System.out.println(++x); //6
		System.out.println(++x); //7
		System.out.printf ("Value is %s", x);
		
	}

}
