package com.test.demo;


public class ObjClass {
static int id=33;
String name;
	public static void main(String[] args) {
		ObjClass a=new ObjClass();
		System.out.println(a.id);
		System.out.println(a.name);
		System.out.println(id);
	}

}
