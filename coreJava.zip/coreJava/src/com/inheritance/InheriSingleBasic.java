/*
Note :- 
in single class 
 
 */
package com.inheritance;

class A{
     public void add()
    {
        System.out.println("1st method of add ");
    }     
}
public class InheriSingleBasic {
    public static void main(String[] args) {
        A obj=new A();
        obj.add();
    }
    
}
