package com.main.same.extend;

public class P {
	public static void main(String args[]){
		int a=40,b=80;
		System.out.println("I LOVE MY INDIA...");
		System.out.println(++a);
		System.out.println(a+b);
		System.out.println(4^5);
		System.out.println(4|5);
		System.out.println(4&5);
		System.out.println(~5);

	}

}
