/*
 TwoDPoint3
Adding to the previous problem, modify the class TestTwoDPoint and add another function to it. 
This function takes two TwoDPoints as input and returns the TwoDPoint that is farthest from the 
point (0,0).
 */
package com.module4a.specialClass;


public class TwoDPoint3 {
    
}
