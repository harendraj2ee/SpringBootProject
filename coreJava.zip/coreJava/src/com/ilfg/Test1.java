package com.ilfg;

class AA{
	 static int i=0;
	static{
		System.out.println("1");
		//i=100;
	}
}
public class Test1 {
	//System.out.print("12");
	public static void main(String args[]){
	System.out.println("as");
	//new AA();
	for(int j=0;j<5;j++){
		
	System.out.println(AA.i);
	}
}
}