package com.sorting.searching.greeksforgreeks;

public class Loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=0; i<10; i++) {
			for(int j=i; j<10; j++) {
				System.out.print(" "+i);
			}
			System.out.println("");

		}

	}

}
