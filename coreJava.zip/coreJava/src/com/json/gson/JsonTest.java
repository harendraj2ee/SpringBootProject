//package com.json.gson;
//
//import org.json.simple.JSONArray;
//import org.json.simple.JSONObject;
//
//public class JsonTest {
//	public static void main(String args[]){
//		JSONObject jsonObj=new JSONObject();
//		jsonObj.put("Name", "Harendra");
//		jsonObj.put("MobileNo", "9968444679");
//		jsonObj.put("SSSSSSSSS", "CCCCC");
//		System.out.println("jsonobj :: "+jsonObj);
//		JSONObject jsonObj2=new JSONObject();
//		jsonObj2.put("Village", jsonObj);
//		jsonObj2.put("Village22", jsonObj);
//		System.out.println("jsonObj2 >>"+jsonObj2);
//		JSONObject jsonObj3=new JSONObject();
//		jsonObj3.put("AA", jsonObj2);
//		System.out.println("jsonedd >> "+jsonObj3);
//		JSONArray b=new JSONArray();
//		b.add(jsonObj3);
//		System.out.println("LL "+b);
//		JSONArray bb=new JSONArray();
//		bb.add(jsonObj3);
//		System.out.println(bb);
//	}
//
//}
