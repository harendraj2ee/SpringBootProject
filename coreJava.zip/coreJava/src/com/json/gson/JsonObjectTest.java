//package com.json.gson;
//
//import java.util.ArrayList;
//
//import org.json.simple.JSONObject;
//
//public class JsonObjectTest {
//	public static void main(String args[]){
//	ArrayList<JSONObject> list=new ArrayList<JSONObject> ();
//	JSONObject ug=new JSONObject();
//	ug.put("ugYear", "2014");
//	ug.put("ugCourse", "B.Tech");
//	System.out.println(ug);
//	JSONObject pg=new JSONObject();
//	pg.put("pgYear", "2017");
//	pg.put("pgCourse", "M.Tech");
//	
//	JSONObject gm=new JSONObject();
//	gm.put("ug", ug);
//	gm.put("pg", pg);
//	
//	System.out.println(gm);
//	JSONObject main=new JSONObject();
//	main.put("Education", gm);
//	System.out.println(main);
//	list.add(main);
//	System.out.println("List value :: "+list);
//	
//	}
//	
//
//}
