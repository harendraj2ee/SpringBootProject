package com.a1.operator;
import com.abstractClass.Hks;
public class Hks2 {

	public static void main(String[] args) {
		Hks h = new Hks();

		h.m1();
	}

}
