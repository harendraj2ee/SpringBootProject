/*
 Write a Program like this
        
********** 
********* 
******** 
******* 
****** 
***** 
**** 
*** 
** 
* 

 */
package com.harry.star;

public class TriangleStar3
{
    public static void main(String[] args) 
    {
        System.out.println("To Print * is like this ");
        for(int i=1; i<=10; i++)
        {
            for(int j=i; j<=10; j++)
            {
                System.out.print("*");
            }
            System.out.println("");
            
        }
        
    }
    
}
