package com.collection.harendra;

public class CollectionInterface {

}
