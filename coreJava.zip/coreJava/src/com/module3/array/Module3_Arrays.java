/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.module3.array;

/**
 *
 * @author Home
 */
public class Module3_Arrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
}
