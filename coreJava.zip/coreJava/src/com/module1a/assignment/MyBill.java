/*
 MyBill

You have gone out to a restaurant with your two friends. The food bill amount is amt. 
On top of the bill, there is a tax of 10%. Finally you paid a tip of 12% on the food bill + tax. 
Now that you and your 2 friends want to share the bill equally, calculate what is each person’s share. 
Note that amt is provided as input.
 */
package com.module1a.assignment;


public class MyBill
{
    public static void main(String[] args) {
        
    }
    
}
