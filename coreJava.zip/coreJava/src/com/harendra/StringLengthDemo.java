/*
 Java – String length() Method example
 */
package com.harendra;


public class StringLengthDemo 
{
    
    public static void main(String args[]) {
       String str1= new String("Test String");
       String str2= new String("Chaitanya");
       String str3= new String("BeginnersBook");
       System.out.println("Length of str1:"+str1.length());
       System.out.println("Length of str2:"+str2.length());
       System.out.println("Length of str3:"+str3.length());
   }
}
