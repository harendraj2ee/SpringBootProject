package com.harendra.singltone;

public class SingleToneMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingletonLazy.getInstance();

	}

}
