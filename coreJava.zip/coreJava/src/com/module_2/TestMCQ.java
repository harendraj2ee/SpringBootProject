/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.module_2;

/**
 *
 * @author Home
 */
class TestMCQ
{
    public static void main(String[] args) {
        TestMCQ mc=new TestMCQ();
        System.out.println(mc.j());
    }
    public String j()
    {
        return "Hi Chu";
    }

}