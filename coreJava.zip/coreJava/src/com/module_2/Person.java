/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.module_2;

/**
 *
 * @author Home
 */
public class Person {
		String name;
		int age;
		//Person(){
			//System.out.print("Football ");
		//}
		Person(String name,int age){
			System.out.println("World Cup");
		}
		public static void main(String[] args){
			
		Person p=new Person("Ronaldo",28);
                        System.out.println(p);
			
		}
	}

   
              

