package com.file.io;

import java.io.File;

public class FileDemo {
	
	public static void main(String args[]){
	File file=new File("abc.txt");	
	System.out.println("done");
	file.exists();
	
	}

}
