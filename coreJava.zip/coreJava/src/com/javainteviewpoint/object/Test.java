package com.javainteviewpoint.object;

public class Test {
	static {
		System.out.println("Static block is called..");
	}
	public Test() {
		System.out.println("Inside Test Constructor is called..");
	}

}
