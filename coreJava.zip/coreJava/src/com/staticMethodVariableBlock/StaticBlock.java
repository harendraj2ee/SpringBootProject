/*
 Static Block
 */
package com.staticMethodVariableBlock;

public class StaticBlock 
{
    static 
    {
        System.out.println("Hello Static");
    }
    public static void main(String[] args) 
    {
        
    }
    
}
