package com.array.basic;

public class VarArgMethod2 {
	public static void m2(int... x){
		int total=0;
		for(int y:x){
			total=total+y;
		}
		System.out.println("Total values is ::: "+total);
	}
	public static void main(String args[]){
		m2();
		m2(5);
		m2(10,20);
		m2(30,45,15);
		m2(5,5,5,5,5,5,5);
	}

}
