package com.array.basic;

public class VarArgMethod {
	public static void m1(int... x){
		System.out.println("Arguments type method just like array");
		
	}
	public static void main(String args[]){
		m1(55);
		m1(55);
		m1(23,34);
		m1(33,44,55);
		m1(66,77,88,99);
	}
}
