package com.abstractClass;

public class Testdddd {

}
