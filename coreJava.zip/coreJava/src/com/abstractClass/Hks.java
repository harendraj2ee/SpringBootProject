package com.abstractClass;

 public class Hks {
	 public void m1() {
		 System.out.println("welcome package11...");
	 }

}
