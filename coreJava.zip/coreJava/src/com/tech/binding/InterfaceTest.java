/*package com.tech.binding;
//Referenced Parties
class A implements Printable
{
	public void print()
	{
		System.out.println("A is Printable.");
	}
	public void extra()
	{
		System.out.println("It is not part of the Printable role.");
	}
}
class B implements Printable
{
	public void print()
	{
		System.out.println("B is a also Printable.");
	}
}
class InterfaceTest
{
	public static void main(String arr[])
	{
		A x=new A();
		B y=new B();
		
		Invoker.invoke(x);
		Invoker.invoke(y);
	}
}*/