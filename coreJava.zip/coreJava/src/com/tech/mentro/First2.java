package com.tech.mentro;
class First2
{
	static public  void main(String arr[])
	{
	System.out.println("Welcome Harendra First  static public ");
	}
}