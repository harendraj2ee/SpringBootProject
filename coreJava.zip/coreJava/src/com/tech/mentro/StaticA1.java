package com.tech.mentro;
class StaticA1
{
	static int a=5;
	public static void main(String arr[])
	{
		System.out.println(a);
	}
}