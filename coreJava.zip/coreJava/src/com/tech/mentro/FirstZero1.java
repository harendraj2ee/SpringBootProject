package com.tech.mentro;
class FirstZero1
{
	public static void main(String arr[])
	{
	System.out.println("Welcome Harendra First");
	}
}