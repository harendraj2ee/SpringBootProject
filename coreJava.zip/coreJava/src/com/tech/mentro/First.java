package com.tech.mentro;
class First
{
	public static void main(String arr[])
	{
	System.out.println("we use Multiple class using this program");
	}
	class Second
	{
	}
	class Third
	{
	}
	class Fourth
	{
	}
	// we use mupltiple class in java
}