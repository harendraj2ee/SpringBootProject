package com.myenum;

public enum Mobile  {
	
	Mobile()
	

}
