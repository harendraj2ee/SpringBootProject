package com.oops.abstracts;

public abstract class Animal {
	abstract public void soundOfAnimal();  // its just a idea.
}
