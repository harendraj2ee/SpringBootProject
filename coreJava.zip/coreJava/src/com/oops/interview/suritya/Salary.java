package com.oops.interview.suritya;

public class Salary {
	int ta,da,hra;
	{
		ta=100;
		da=200;
		hra=300;
	}
}
