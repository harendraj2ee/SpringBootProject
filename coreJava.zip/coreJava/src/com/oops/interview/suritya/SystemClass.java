package com.oops.interview.suritya;
//jconsole to check health of cmd of java
class Test{//Test = System
	public static final String s="Harendra"; //s=out
}
public class SystemClass {

	public static void main(String[] args) {
		System.out.println(Test.s.isEmpty());
		System.out.println(Test.s.length());// length(); =println();
	}

}
