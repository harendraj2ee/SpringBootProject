package com.oops.interview.suritya;

public class Address {
	String city,state,country;
	{
		city="Noida";
		state="UP";
		country="India";
	}

}
