//Its a working fine.

//package com.oops.interview.suritya;
//
//abstract public class WithOutMainMethod extends javafx.application.Application {
//	static {
//		System.out.println("Without Main Method To run..");
//		System.exit(0);
//	}
//}
