package com.oops.polymorphisms;

class Hk{
	 static void cc() {
		System.out.println("kkkkkk");
	}
}
class HH extends Hk{
	 static void cc() {
		System.out.println("jhjjjj");
	}
}
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Hk.cc();
	}

}
