package com.mysql.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestJdbc05DB {

	public static void main(String[] args) {

		String jdbcUrl = "jdbc:mysql://localhost:3307/hb-05-many-to-many?useSSL=false&serverTimezone=UTC";
		String user = "root";
		String pass = "root";
		
		try {
			System.out.println("Connecting to database: " + jdbcUrl);
			
			Connection myConn =
					DriverManager.getConnection(jdbcUrl, user, pass);
						
			System.out.println("Connection successful!!!");
			
		}
		catch (Exception exc) {
			exc.printStackTrace();
		}
		
	}

}



