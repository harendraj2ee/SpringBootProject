package com.mysql.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;

public class TestJDBC {

	public static void main(String[] args) {
		String jdbcUrl = "jdbc:mysql://localhost:3307/balco_db?useSSL=false";
		String userName = "root";
		String password = "root";
		try {
			System.out.println("connecting to database.."+jdbcUrl);
			Connection myConn = DriverManager.getConnection(jdbcUrl, userName, password);
			System.out.println("Successfully connection done.. :::  " +myConn);
				
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
