package com.login.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.login.demo.data.entity.UserDetailsEntity;
import com.login.demo.data.repository.UserDetailsRepository;

@Service
public class UserDetailsImpl implements UserDetailsService {

	@Autowired
	private UserDetailsRepository userDetailsRepository;

	@Override
	public UserDetailsEntity getUserDetails(Integer id) {
		// TODO Auto-generated method stub
		return userDetailsRepository.findOne(id);
	}

	@Override
	public List<UserDetailsEntity> getAllUserDetails() {
		// TODO Auto-generated method stub
		return userDetailsRepository.findAll();
	}
	


}
