package com.login.demo.service;

import java.util.List;

import com.login.demo.data.entity.UserDetailsEntity;

public interface UserDetailsService {
	 UserDetailsEntity getUserDetails(Integer id);
	 List<UserDetailsEntity> getAllUserDetails();

}
