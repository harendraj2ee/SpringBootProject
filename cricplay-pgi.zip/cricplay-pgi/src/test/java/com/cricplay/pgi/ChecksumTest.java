package com.cricplay.pgi;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ChecksumTest {
	@BeforeClass
	public static void beforeClass() {
		System.setProperty("spring.profiles.active","dev");
		System.setProperty("node", "APP");
	}
	
	@Test
	public void checksum() throws IOException
	{
		String expectedData="{\n" + 
				"    \"checksumAttributes\": {\n" + 
				"        \"website\": \"WEBSTAGING\",\n" + 
				"        \"callBackUrl\": \"http://203.122.19.100:3500/account/order-summary/1234\",\n" + 
				"        \"orderId\": \"1234\",\n" + 
				"        \"custId\": \"1234\",\n" + 
				"        \"industryTypeId\": \"Retail\",\n" + 
				"        \"checksum\": \"gMbzFRox6IhSzY+riUQDrw7duWcDbGPpoyX7NkZcTsNcGIOhOkC9OKOhm2PribwYB5wnS3NYgymnF+7nXwy/JcTWiCw4RXeei1OAfe5hA6U=\",\n" + 
				"        \"mid\": \"CRICTI63889900710694\",\n" + 
				"        \"channelId\": \"WEB\",\n" + 
				"        \"txnAmount\": \"1\"\n" + 
				"    }\n" + 
				"}";
		
		FileInputStream file = new FileInputStream("src/test/java/resources/checksum.json");
		String actualData = IOUtils.toString(file, "UTF-8");
		Assert.assertEquals(expectedData, actualData.trim());
	}
}
