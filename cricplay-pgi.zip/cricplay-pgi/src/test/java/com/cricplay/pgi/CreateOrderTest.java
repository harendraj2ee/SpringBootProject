package com.cricplay.pgi;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CreateOrderTest {
	@Test
	public void createOrder() throws IOException {
		String expectedData ="{\n" + 
				"    \"orderId\": \"PG1965\",\n" + 
				"    \"planId\": 22,\n" + 
				"    \"planName\": \"gold\",\n" + 
				"    \"orderStatus\": \"initiated\",\n" + 
				"    \"createdOn\": \"09 Mar, 2019 14:17:12\",\n" + 
				"    \"modifiedOn\": \"09 Mar, 2019 14:17:12\",\n" + 
				"    \"winningBalanceUsed\": 2,\n" + 
				"    \"amountPaidByPG\": 8,\n" + 
				"    \"amountPaid\": 10,\n" + 
				"    \"coins\": 10,\n" + 
				"    \"message\": \"\"\n" + 
				"}";
		
		FileInputStream file = new FileInputStream("src/test/java/resources/createOrder.json");
		String actualData = IOUtils.toString(file, "UTF-8");
		Assert.assertEquals(expectedData, actualData.trim());		
	}

}
