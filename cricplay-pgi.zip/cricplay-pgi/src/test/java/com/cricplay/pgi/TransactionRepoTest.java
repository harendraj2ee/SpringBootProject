package com.cricplay.pgi;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.repository.TransactionRepository;

@RunWith(SpringRunner.class)
@SpringBootTest
public class TransactionRepoTest {

	@Autowired
	OrderDao orderDao;
	@Autowired
	TransactionRepository transactionRepository;
	@BeforeClass
	public static void beforeClass(){
		System.setProperty("spring.profiles.active","dev");
		System.setProperty("node","APP");
	}

	@Test
	public void testUpdateTransaction() throws  Exception{
		TransactionEntity transactionEntity=transactionRepository.findTransacitonById(3359);
		transactionEntity.setTransStatus("TXN_update");
		System.out.println("result:::"+orderDao.updateTransactionAndDtl(transactionEntity));
	}
	


}
