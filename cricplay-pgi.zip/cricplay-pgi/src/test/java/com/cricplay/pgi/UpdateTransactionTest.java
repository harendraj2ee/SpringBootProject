package com.cricplay.pgi;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class UpdateTransactionTest {
	
	@BeforeClass
	public static void beforeClass(){
		System.setProperty("spring.profiles.active","dev");
		System.setProperty("node","APP");
	}
	@Test
	public void updatePgTransaction() throws IOException {
		String expectedData="{\n" + 
				"	\"orderId\":74,\n" + 
				"	\"pgTransaction\":{\n" + 
				"		\"status\":\"PENDING\",\n" + 
				"		\"pgTxnId\":\"209032434324358787984358398948593849\",\n" + 
				"		\"bankTxnId\":\"1321323232323232232\",\n" + 
				"		\"txnType\":\"PAYTM\",\n" + 
				"		\"gatewayName\":\"PAYTM\",\n" + 
				"		\"respCode\":\"01\",\n" + 
				"		\"respMsg\":\"TxnPending\",\n" + 
				"		\"bankName\":\"HDFCBANK\",\n" + 
				"		\"paymentMode\":\"DC\",\n" + 
				"		\"refundAmount\":\"10\",\n" + 
				"		\"txnDate\":\"2019-03-05\"\n" + 
				"	}\n" + 
				"}";
		
		FileInputStream file = new FileInputStream("src/test/java/resources/updatePGTransaction.json");
		String actualData = IOUtils.toString(file, "UTF-8");
		Assert.assertEquals(expectedData, actualData.trim());	
		
		
	}

}
