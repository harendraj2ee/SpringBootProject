package com.cricplay.pgi;

import com.cricplay.pgi.data.entity.*;
import com.cricplay.pgi.data.repository.*;
import com.cricplay.pgi.util.MessageSelector;
import com.cricplay.pgi.util.StringUtils;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.*;

@RunWith(SpringRunner.class)
@SpringBootTest
public class LanguageRepoTest {

	@BeforeClass
	public static void beforeClass(){

		System.setProperty("spring.profiles.active","dev");
		System.setProperty("node","APP");
	}

	@Autowired
	private LanguagePlaceholderRepository languagePlaceholderRepository;

	@Autowired
	MessageSelector messageSelector;

	//@Test
	public void getLanguagePlaceholder() {

		List<LanguagePlaceholderEntity> l=languagePlaceholderRepository.findAll();

		System.out.println("list::"+l);
	}

	@Test
	public void getPlaceholderByEventLangType() {

		LanguagePlaceholderEntity l1=languagePlaceholderRepository.getPlaceholderByEventLangType(
				"EVENT_LABEL_FLASH_CASH_CREDIT","EN","SMS");

		System.out.println("list::"+l1);
	}

	@Test
	public void testVariablePopulate() {

		LanguagePlaceholderEntity l1=languagePlaceholderRepository.getPlaceholderByEventLangType(
				"EVENT_LABEL_FLASH_CASH_CREDIT","en","SMS");

		String message=l1.getMessage();
		Map<String,String> variablesMap=new HashMap<>();
		variablesMap.put("expirydate","20-Jan-2019");
		String str=StringUtils.populateVariables(message,variablesMap);

		System.out.println("updated string::"+str);
	}

	@Test
	public void testMessageLabels() throws Exception{

		Map<String,String> variablesMap=new HashMap<>();
		variablesMap.put("teamSeq","12333");
		variablesMap.put("match","90");
		String str=messageSelector.getMessageLabel("EVENT_LABEL_ORDER_PG_ONLY_FAILED_227","",variablesMap);
		System.out.println("updated string::"+str);
	}

}
