package com.cricplay.pgi;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.entity.TransDetailsEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.repository.OrderRepository;
import com.cricplay.pgi.data.repository.PlanRepository;
import com.cricplay.pgi.data.repository.TransDetailsRepository;
import com.cricplay.pgi.data.repository.TransactionRepository;
import com.cricplay.pgi.model.OrderModel;

@RunWith(SpringRunner.class)
@SpringBootTest
public class OrderRepoTest {

	@Autowired PlanRepository planRepository;
	
	@Autowired OrderRepository orederRepository;
	
	@Autowired TransactionRepository transactionRepository;
	
	@Autowired TransDetailsRepository transDetailsRepository;
	
	
	@Test
	public void orderSummary() {
		OrderModel orderModel = (OrderModel) orederRepository.getOrderStatus(1965, "dcc86b51-38c6-4654-86ad-7684e2e37bd5");
		System.out.println("orderModel >> "+orderModel);
	}
	
	@Test
	public void planData() {
		PlanEntity planEntity = (PlanEntity) planRepository.findAll();
		System.out.println("planEntity started.. "+planEntity);
	}
	
	@Test
	public void planById() {
		PlanEntity planEntity = planRepository.findPlanById(26);
		System.out.println("planById is Started .. "+planEntity);
	}
	
	
	@Test
	//@Transactional
	public void createOrder() {
		PlanEntity planEntity= planRepository.findPlanById(1231);
		//System.out.println(buildOrder(planEntity, "14"));
		OrderEntity order=buildOrder(planEntity, "14");
		
		List<TransactionEntity> transactionEntityList=transactionRepository.saveAll(order.getTransactions());
		for(TransactionEntity transactionEntity:order.getTransactions()) {
			System.out.println("transactionEntity:::"+transactionEntity);
			transDetailsRepository.save(buildTransDetails(transactionEntity));
		}
		
	}
	
	@Test
	public void fetchOrder() {
		 OrderEntity orderEntity=orederRepository.findOrderById(45);
		 System.out.println(orderEntity);
		
	}
	
	@Test
	public void updateOrder() {
		int count=orederRepository.updateOrderStatusById("success",new Date(),45);
		System.out.println(count);
	}
	
	@Test
	public void updateTransactionStatusById() {
		int count=transactionRepository.updateTransactionStatusById("success","",new Date(),29);
		System.out.println(count);
	}
	
	public OrderEntity buildOrder(PlanEntity plan,String userId) {
		OrderEntity orderEntity=new OrderEntity();
		orderEntity.setPlanId(plan.getPlanId());
		orderEntity.setUserId(userId);
		orderEntity.setPrice(plan.getAmount());
		orderEntity.setOrderType("WinningAndPG");
		orderEntity.setCreatedOn(new Date());
		orderEntity.setModifiedOn(new Date());
		orderEntity.setStatus("Success");
		orderEntity=orederRepository.save(orderEntity);
		orderEntity.setTransactions(buildTransaction(orderEntity,userId));
		return orderEntity;
	}
	
	public Set<TransactionEntity> buildTransaction(OrderEntity order,String userId) {
		Set<TransactionEntity> transactionEntitySet= new HashSet<>();
		TransactionEntity transactionEntity1=new TransactionEntity();
		transactionEntity1.setOrder(order);
		transactionEntity1.setPaymentType("PG");
		transactionEntity1.setAmount(50.0);
		transactionEntity1.setEventType("PRO_WINNINGS_DEBIT");
		transactionEntity1.setUserId(userId);
		transactionEntity1.setPrice(50.00);
		transactionEntity1.setValuation(50);
		transactionEntity1.setCreated_on(new Date());
		transactionEntity1.setModified_on(new Date());
		transactionEntity1.setDescription("Amount is debited successfully");
		//transactionEntity1.setTransDetailsEntity(buildTransDetails(userId));
		
		TransactionEntity transactionEntity2=new TransactionEntity();
		transactionEntity2.setOrder(order);
		transactionEntity2.setPaymentType("Winnings");
		transactionEntity2.setAmount(20.0);
		transactionEntity2.setEventType("PRO_Coins_DEBIT");
		transactionEntity2.setUserId(userId);
		transactionEntity2.setPrice(50.00);
		transactionEntity2.setCreated_on(new Date());
		transactionEntity2.setModified_on(new Date());
		transactionEntity2.setValuation(50);
		transactionEntity2.setDescription("Coins is debited successfully");
		//transactionEntity2.setTransDetailsEntity(buildTransDetails(plan,userId));
		transactionEntitySet.add(transactionEntity1);
		transactionEntitySet.add(transactionEntity2);
		return transactionEntitySet;
		
	}
	
	
	public TransDetailsEntity buildTransDetails(TransactionEntity transactionEntity) {
		//Set<TransDetailsEntity> transDetailsEntitySet= new HashSet<>();
		TransDetailsEntity transDetailsEntity=new TransDetailsEntity();
		transDetailsEntity.setUserId(transactionEntity.getUserId());
		transDetailsEntity.setTransaction(transactionEntity);
		transDetailsEntity.setPaymentType(transactionEntity.getPaymentType());
		transDetailsEntity.setCreatedOn(new Date());
		transDetailsEntity.setModifiedOn(new Date());
		transDetailsEntity.setStatus("Initiated");
		transDetailsEntity.setDescription("Transaction Initiated");
		
/*		TransDetailsEntity transDetailsEntity2=new TransDetailsEntity();
		transDetailsEntity2.setUserId(userId);
		transDetailsEntity2.setPaymentType("PG");
		transDetailsEntity2.setCreatedOn(new Date());
		transDetailsEntity2.setModifiedOn(new Date());
		transDetailsEntity2.setStatus("Initiated");
		transDetailsEntity2.setDescription("Transaction is in Progress");
		transDetailsEntitySet.add(transDetailsEntity1);
		transDetailsEntitySet.add(transDetailsEntity2);*/
		return transDetailsEntity;
		
	}

}
