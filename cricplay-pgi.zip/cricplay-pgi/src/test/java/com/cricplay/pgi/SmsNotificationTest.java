package com.cricplay.pgi;

import java.util.HashMap;
import java.util.Map;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cricplay.pgi.notification.NotificationRequest;
import com.cricplay.pgi.notification.Notifier;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SmsNotificationTest {


	@BeforeClass
	public static void beforeClass(){

		System.setProperty("spring.profiles.active","dev");
		System.setProperty("node","APP");
	}

	@Autowired
	Notifier smsNotifier;
	
	@Test
	public void testSmsNotification() throws Exception{

		NotificationRequest notificationRequest=new NotificationRequest();
		notificationRequest.setEvent("EVENT_LABEL_REFERRAL_SIGNUP");
		notificationRequest.setUserId("d4b659cb-f586-498f-a617-4c371b4887df");
		notificationRequest.setLanguage("hi");

		Map<String,String> variablesMap=new HashMap<>();
		variablesMap.put("referredBy","Harendra");

		notificationRequest.setVariablesMap(variablesMap);

		System.out.println("sms notifier response:::"+smsNotifier.notify(notificationRequest));
	}


}
