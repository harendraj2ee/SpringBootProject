package com.cricplay.pgi;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PlanTest{
	
	@Test
	public void verifyUser() throws IOException {
		//final String Authorization="eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI5OTY4NDQ0Njc5In0.elrH-1Oc88F3xOr2zLQJKaCeEwWjjFUEEZ2TdEAt1FjeLjvcthOQaNhWeprpoUuXCXFXO4W1ms_MbXZRQmnb0A";
		//if(Authorization.equalsIgnoreCase("eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiI5OTY4NDQ0Njc5In0.elrH-1Oc88F3xOr2zLQJKaCeEwWjjFUEEZ2TdEAt1FjeLjvcthOQaNhWeprpoUuXCXFXO4W1ms_MbXZRQmnb0A")) {
			String expectedData = "{\n" + 
					"    \"userUniqueId\": \"219bc173-fcef-4fe9-833c-4b0c0c84c5f1\",\n" + 
					"    \"mobile\": \"9968444679\",\n" + 
					"    \"alias\": \"Harendra\",\n" + 
					"    \"avatar\": null,\n" + 
					"    \"referralLink\": \"https://cricst.test-app.link/harendra\",\n" + 
					"    \"referredBy\": null,\n" + 
					"    \"winnings\": null,\n" + 
					"    \"coins\": null,\n" + 
					"    \"referredCoin\": null,\n" + 
					"    \"paytmNumber\": \"9968444679\",\n" + 
					"    \"messageCounter\": 0,\n" + 
					"    \"hasFacebookHandle\": false,\n" + 
					"    \"megaContestPlayed\": false,\n" + 
					"    \"firstTeamCreated\": false,\n" + 
					"    \"superleagueContestPlayed\": false\n" + 
					"}";

			FileInputStream file = new FileInputStream("src/test/java/resources/verifyUser.json");
			String actualData = IOUtils.toString(file, "UTF-8");
		    Assert.assertEquals(expectedData, actualData.trim());
		}
	//}
	
	
	  @Test
	    public void plansRetriveAll() throws IOException {
		  
	        String expectedData = "{\n" + 
	        		"    \"plans\": [\n" + 
	        		"        {\n" + 
	        		"            \"planId\": 22,\n" + 
	        		"            \"planName\": \"gold\",\n" + 
	        		"            \"coins\": 10,\n" + 
	        		"            \"bonusCoins\": 15,\n" + 
	        		"            \"amount\": 10,\n" + 
	        		"            \"extra\": 0,\n" + 
	        		"            \"sortOrder\": 1,\n" + 
	        		"            \"bestValue\": \"N\",\n" + 
	        		"            \"isDeleted\": \"N\",\n" + 
	        		"            \"image\": \"https://prod.cricplay.com/img/coins-icon.png\",\n" + 
	        		"            \"created_at\": \"2017-02-25T16:17:15.000+0000\",\n" + 
	        		"            \"modified_at\": \"2019-03-13T03:52:41.000+0000\"\n" + 
	        		"        },\n" + 
	        		"       \n" + 
	        		"        {\n" + 
	        		"            \"planId\": 1231,\n" + 
	        		"            \"planName\": \"inclusive\",\n" + 
	        		"            \"coins\": 350,\n" + 
	        		"            \"bonusCoins\": 0,\n" + 
	        		"            \"amount\": 30,\n" + 
	        		"            \"extra\": 25,\n" + 
	        		"            \"sortOrder\": 5,\n" + 
	        		"            \"bestValue\": \"N\",\n" + 
	        		"            \"isDeleted\": \"N\",\n" + 
	        		"            \"image\": \"https://prod.cricplay.com/img/coins-icon.png\",\n" + 
	        		"            \"created_at\": \"2019-02-26T16:17:15.000+0000\",\n" + 
	        		"            \"modified_at\": \"2019-03-13T03:52:02.000+0000\"\n" + 
	        		"        }\n" + 
	        		"    ]\n" + 
	        		"}";
	             
	        FileInputStream file = new FileInputStream("src/test/java/resources/plan.json");
	        String actualData = IOUtils.toString(file, "UTF-8");
	             
	        Assert.assertEquals(expectedData, actualData.trim());
	    }
	  
	  @Test
	    public void plansById() throws IOException {
	        String expectedData = "{\n" + 
	        		"    \"plans\": [\n" + 
	        		"        {\n" + 
	        		"            \"planId\": 22,\n" + 
	        		"            \"planName\": \"gold\",\n" + 
	        		"            \"coins\": 10,\n" + 
	        		"            \"bonusCoins\": 15,\n" + 
	        		"            \"amount\": 10,\n" + 
	        		"            \"extra\": 0,\n" + 
	        		"            \"sortOrder\": 1,\n" + 
	        		"            \"bestValue\": \"N\",\n" + 
	        		"            \"isDeleted\": \"N\",\n" + 
	        		"            \"image\": \"https://prod.cricplay.com/img/coins-icon.png\",\n" + 
	        		"            \"created_at\": \"2017-02-25T16:17:15.000+0000\",\n" + 
	        		"            \"modified_at\": \"2019-03-13T03:52:41.000+0000\"\n" + 
	        		"        }\n" + 
	        		"    ]\n" + 
	        		"}";
	             
	        FileInputStream file = new FileInputStream("src/test/java/resources/planId.json");
	        String actualData = IOUtils.toString(file, "UTF-8");
	        Assert.assertEquals(expectedData, actualData.trim());
	    }
	  
}
