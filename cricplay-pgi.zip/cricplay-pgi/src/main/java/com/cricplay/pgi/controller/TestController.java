/*package com.cricplay.pgi.controller;


import java.io.File;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;
import com.cricplay.pgi.data.repository.OrderRepository;
import com.cricplay.pgi.data.repository.TransactionDetailsRepository;
import com.cricplay.pgi.data.repository.TransactionRepository;
import com.cricplay.pgi.model.DebitResponse;
import com.cricplay.pgi.model.PGTxnUpdate;
import com.cricplay.pgi.model.PGTxnUpdateResponse;
import com.cricplay.pgi.services.CreateOrderService;
import com.cricplay.pgi.services.CreateTransDetailService;
import com.cricplay.pgi.services.CurrencyCheckSevice;
import com.cricplay.pgi.services.TransactionUpdateService;

@RestController
@RequestMapping(value="/cricplay/api/v1")
@PropertySource(value= {"classpath:application-${spring.profiles.active}.properties"})
public class TestController {

	@Autowired
	AppProperties appProperties;
	
	
	@Autowired
	CreateOrderService createOrderService;
	
	@Autowired
	TransactionUpdateService transactionUpdateService;
	
	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	TransactionDao transactionDao;
	
	@Autowired
	CreateTransDetailService createTransDetailService;
	
	@Autowired
	CurrencyCheckSevice currencyCheckService;
	
	@RequestMapping(value="/getwinningbalance", method =RequestMethod.GET, headers = "Accept=application/json")
	public @ResponseBody Double getWinningBalance(@RequestParam(value="userId") String userId) throws Exception {
	Double bal=createOrderService.getWinningBalance(userId);
	return bal;
	}
	
	
	@RequestMapping(value="/debitCreditUserWinning",method =RequestMethod.POST,headers = "Accept=application/json")
	public @ResponseBody ResponseEntity<DebitResponse> debitCreditUserWinning() throws Exception{
		MetaData metaData=new MetaData();
		metaData.setOrderId("51");
		metaData.setPlanName("exclusive");
		DebitCreditRequest data=new DebitCreditRequest();
		data.setRequestId("PG38");
		data.setEvent("PRO_WINNING_DEBIT");
		data.setUserId("888fda4b-2146-4317-a10d-f47dd089755f");
		data.setAmount(1);
		data.setMetadata(metaData);
		
		//HttpEntity<DebitCreditRequest> request = new HttpEntity<DebitCreditRequest>(data);
		JSONObject obj = new JSONObject(data);
		String strJson = obj.toString();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> request = new HttpEntity<String>(strJson, headers);
		RestTemplate restTemplate=new RestTemplate();
		
		ResponseEntity<DebitResponse> response=restTemplate.postForEntity(appProperties.getWinningDebitUrl(), request, DebitResponse.class);

	    
		return response;
	}
	
	@RequestMapping(value="/creditCoin", method=RequestMethod.POST, headers = "Accept=application/json")
	public @ResponseBody ResponseEntity<CoinCreditResponse> creditCoin() throws Exception{
		
		MetaData metaData=new MetaData();
		metaData.setOrderId("51");
		metaData.setPlanName("exclusive");
		DebitCreditRequest data=new DebitCreditRequest();
		data.setRequestId("PG40");
		data.setEvent("PRO_COIN_CREDIT");
		data.setUserId("888fda4b-2146-4317-a10d-f47dd089755f");
		data.setAmount(10);
		data.setMetadata(metaData);
		
		JSONObject obj = new JSONObject(data);
		String strJson = obj.toString();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> request = new HttpEntity<String>(strJson, headers);
		RestTemplate restTemplate=new RestTemplate();
		
		ResponseEntity<CoinCreditResponse> response=restTemplate.postForEntity(appProperties.getCoinCreditUrl(), request, CoinCreditResponse.class);
		if(response.getStatusCodeValue()==200) {
			System.out.println("coin credited...");
			return response;
		}
		return null;
		
	}
	
	@RequestMapping(value="/getTransactionIdByOrder", method=RequestMethod.POST, headers = "Accept=application/json")
	public @ResponseBody Integer findTransactionIdByOrderId(@RequestBody PGTxnUpdate pgTxnUpdate) throws Exception{
		
			RestTemplate restTemplate= new RestTemplate();
	     	HttpHeaders headers = new HttpHeaders();
	     	headers.add("language", "en");
	     	headers.add("Content-Type", "application/json");
	     	JSONObject obj = new JSONObject(pgTxnUpdate);
			String strJson = obj.toString();
	        HttpEntity<String> entity = new HttpEntity<String>(strJson,headers);
	        StringBuilder strBuilder=new StringBuilder(appProperties.getBaseUrl());
	        strBuilder.append(File.separator).append("transaction-update");
	        ResponseEntity<PGTxnUpdateResponse> response = restTemplate.exchange(strBuilder.toString(), HttpMethod.PUT, entity,
	        		PGTxnUpdateResponse.class);
		
		return transactionUpdateService.findTransactionIdByOrderId(pgTxnUpdate.getOrderId());
		
		
	}
	
	
	
	@RequestMapping(value="/getTransactionByOrder", method=RequestMethod.GET, headers = "Accept=application/json")
	public  TransactionEntitySinglton findTransactionByOrderId(@RequestParam Integer orderId, @RequestParam String paymentType) throws Exception{
	
		List<TransactionEntitySinglton> transactinEntity=transactionDao.findTransaction(orderId, paymentType);
		
		TransactionEntitySinglton transaction=transactinEntity.get(0);
	    
		return transaction;
		
	}
	
	
	@RequestMapping(value="/insert", method=RequestMethod.POST, headers = "Accept=application/json")
	public TransDetailsEntitySinglton insertTransDetails(TransDetailsEntitySinglton transDetails) {
		transDetails.setUserId("123456789");
		transDetails.setTransId(71);
		transDetails.setStatus("STATUS");
		transDetails.setDescription("TESTING");
		transDetails.setEventType("EVENT_TYPE");
		transDetails.setPaymentType("PG");
		transDetails.setCreatedAt(new Date());
		transDetails.setModifiedAt(new Date());
		transDetails.setRequestId("PG79-9876542424242");
		return transactionDetailsRepository.save(transDetails);
		
	}
	
	
	
	
	@RequestMapping(value="/currency-check" ,method=RequestMethod.GET, headers="Accept=application/json")
	public ResponseEntity<CurrencyStatusCheckResponse> getCurrencyStatusCheck(String requestId){
		
		return currencyCheckService.currencyStatusCheck(requestId);
		
	}
	
	
	
	@RequestMapping(value="/updatePgTransaction", method=RequestMethod.PUT, headers="Accept=application/json")
	public @ResponseBody ResponseEntity<PGTxnUpdateResponse> updatePgTransaciton(@RequestBody PGTxnUpdate pgTxnUpdate) throws Exception{
		
		int count=transactionUpdateService.updatePgTransaction(pgTxnUpdate, pgTxnUpdate.getOrderId(), AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
		
		// pull record from order table for the current order id
		OrderEntity orderEntity=orderRepository.findOrderById(pgTxnUpdate.getOrderId());
		
		Integer transId=transactionRepository.findTransactionIdByOrderIdAndPaymentType(pgTxnUpdate.getOrderId(), AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
		
		//maintain transaction in pg_transdetails
		createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),"","");
		
		TransDetailsEntity transDetailsEntity=new TransDetailsEntity();
		TransactionEntity transactionEntity=new TransactionEntity();
		transactionEntity.setTransId(transId);
		transDetailsEntity.setTransaction(transactionEntity);
		transDetailsEntity.setUserId(orderEntity.getUserId());
		transDetailsEntity.setPaymentType(AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
		transDetailsEntity.setDescription(pgTxnUpdate.getPgTransaction().getRespMsg());
		transDetailsEntity.setStatus(pgTxnUpdate.getPgTransaction().getStatus());
		transDetailsEntity.setCreatedOn(new Date());
		transDetailsEntity.setModifiedOn(new Date());
		
		transactionDetailsRepository.saveAndFlush(transDetailsEntity);
		
		
		
		if(count==1) {
			
			if(pgTxnUpdate.getPgTransaction().getStatus()=="TXN_SUCCESS") {
				
				// call coin credit service
				
			}
			else if(pgTxnUpdate.getPgTransaction().getStatus()=="TXN_FAILURE") {
				
				*//**
				 * IF(OrderType=="Winning & PG")
				 * {
				 * 		Insert into TransactionRefund Table for WinningCredit
				 * }
				 * Return to Order Summary
				 * 
				 * 
				 * 
				 *//*
			
				
			}
			else
			{
				*//**
				 * Update Transaction Status=Pending
				 * Return to Order Summary 
				  *//*
			}
			
			
					
			
		}
		
		else if(count==0){
			
			// logging the error
			// return order summary response with error code and customize error msg
			
		}
		
		return null;
		
	}
	
	
}
*/