package com.cricplay.pgi.model;

import java.util.Date;

public class BatchConfigration {
	
	private Integer id;
	private String batchName; 
	private String batchType ;
	private Integer executionExpression ;
	private String batchStatus ;
	private  Date creationDate;
	private  Date modifyDate;
	private  String currentStatus;
	
	
	
	public BatchConfigration() {
		super();
	}

	public BatchConfigration(Integer id, String batchName, String batchType, Integer executionExpression,
			String batchStatus, Date creationDate, Date modifyDate, String currentStatus) {
		super();
		this.id = id;
		this.batchName = batchName;
		this.batchType = batchType;
		this.executionExpression = executionExpression;
		this.batchStatus = batchStatus;
		this.creationDate = creationDate;
		this.modifyDate = modifyDate;
		this.currentStatus = currentStatus;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getBatchName() {
		return batchName;
	}
	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}
	public String getBatchType() {
		return batchType;
	}
	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}
	public Integer getExecutionExpression() {
		return executionExpression;
	}
	public void setExecutionExpression(Integer executionExpression) {
		this.executionExpression = executionExpression;
	}
	public String getBatchStatus() {
		return batchStatus;
	}
	public void setBatchStatus(String batchStatus) {
		this.batchStatus = batchStatus;
	}
	public Date getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}
	public Date getModifyDate() {
		return modifyDate;
	}
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}
	public String getCurrentStatus() {
		return currentStatus;
	}
	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	@Override
	public String toString() {
		return "BatchConfigration [id=" + id + ", batchName=" + batchName + ", batchType=" + batchType
				+ ", executionExpression=" + executionExpression + ", batchStatus=" + batchStatus + ", creationDate="
				+ creationDate + ", modifyDate=" + modifyDate + ", currentStatus=" + currentStatus + "]";
	}
	
	
	
}