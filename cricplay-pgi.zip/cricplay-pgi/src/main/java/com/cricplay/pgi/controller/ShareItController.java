package com.cricplay.pgi.controller;

import java.util.Date;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.model.PGTransaction;
import com.cricplay.pgi.model.PGTxnUpdate;
import com.cricplay.pgi.model.PGTxnUpdateResponse;
import com.cricplay.pgi.model.ShareItRefund;
import com.cricplay.pgi.model.ShareItToken;
import com.cricplay.pgi.services.TransactionUpdateService;
import com.cricplay.pgi.util.CommonUtil;


@CrossOrigin
@RestController
@RequestMapping(value = "/cricplay/api/v1")
public class ShareItController {

	private static Logger LOGGER=Logger.getLogger(ShareItController.class);
	

	@Autowired
	AppProperties appProperties;
	
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	private TransactionUpdateService transactionUpdateService;

	@Autowired
	CommonUtil commonUtil;
	
	@Autowired
	OrderDao orderDao;
	
	@RequestMapping(path = "/token", method = RequestMethod.POST)
	public String tokenGenerate(@RequestBody ShareItToken shareItToken) throws Exception{
		
		ResponseEntity<String> responseToken=commonUtil.getShareitToken();
		
		return responseToken.toString(); 
	}

	@RequestMapping(path = "/notify/paymentResult", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public String notifyPaymentResult(@RequestBody String paymentResultStr) throws Exception{
		//String str="{"amount":"10.0","payType":"PAYU104","payOrderNo":"CHL20190325140313453955703","merchantId":"M51063207024","countryCode":"IN","sign":"e591e8c080bdbbeb59e9fafc3303e72b","tradeOrderNo":"3481","transactionTime":1553522729977,"userId":"P01204598784","payChannelOrderNo":"CHL20190325140313453955703","currencyCode":"INR","status":"PAYORDER_STATUS_SUCCESS"}
		LOGGER.info("paymentResult notification recieved from shareit :::"+paymentResultStr);
		String payType=null;
		String tradeOrderNo=null;
		String payChannelOrderNo=null;
		String sign=null;
		String countryCode=null;
		String currencyCode=null;
		Date transactionTime=null;
		String respCode=null;
		
		JSONObject repsonseJson=new JSONObject();
		JSONObject requestJson=new JSONObject(paymentResultStr);
		
		if(requestJson.has("payType")) {
			payType=requestJson.get("payType").toString();
		}
		if(requestJson.has("tradeOrderNo")) {
			tradeOrderNo=requestJson.get("tradeOrderNo").toString();
		}
		if(requestJson.has("payChannelOrderNo")) {
			payChannelOrderNo=requestJson.get("payChannelOrderNo").toString();
		}
		if(requestJson.has("sign")) {
			sign=requestJson.get("sign").toString();
		}
		if(requestJson.has("countryCode")) {
			countryCode=requestJson.get("countryCode").toString();
		}
		if(requestJson.has("currencyCode")) {
			currencyCode=requestJson.get("currencyCode").toString();
		}
		if(requestJson.has("transactionTime")) {
			transactionTime=new Date(Long.parseLong(requestJson.get("transactionTime").toString()));
		}
		if(requestJson.has("status")) {
			if(requestJson.get("status").toString().equalsIgnoreCase("PAYORDER_STATUS_SUCCESS")) {
				respCode="10000";
			}
			
		}
		Integer orderId=Integer.parseInt(requestJson.get("orderId").toString());
		String status=("PAYORDER_STATUS_SUCCESS".equals(requestJson.get("status"))?
				AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[1]:AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[0]);
		try {
			// find order by id
			OrderEntity orderEntity = orderDao.findOrderById(orderId);
			// update transaction and order against the order Id.
			TransactionEntity pgTransactionEntity = transactionUpdateService.findTransactionByOrderIdAndPaymentType(
					orderId, AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());

			pgTransactionEntity.setTransStatus(status);
			pgTransactionEntity.setTxnType(payType);
			pgTransactionEntity.setPgTxnId(tradeOrderNo);
			pgTransactionEntity.setBankTxnId(payChannelOrderNo);
			pgTransactionEntity.setSign(sign);
			pgTransactionEntity.setTransactionTime(transactionTime);
			pgTransactionEntity.setCountryCode(countryCode);
			pgTransactionEntity.setCurrencyCode(currencyCode);
			pgTransactionEntity.setBankTxnId(payChannelOrderNo);
			pgTransactionEntity.setRespCode(respCode);

			transactionUpdateService.updateTransactionAndDtlStatusById(pgTransactionEntity);	
			
			if(orderEntity.getStatus().equalsIgnoreCase("initiated") && orderEntity.getCreditCoinReqId()==null) {
				RestTemplate template= new RestTemplate();
				
				PGTxnUpdate pgTxnUpdate = new PGTxnUpdate();
				pgTxnUpdate.setOrderId(orderId);
				
				PGTransaction pgTransaction=new PGTransaction();
				pgTransaction.setStatus(status);
				pgTransaction.setRespCode(respCode);
				
				pgTxnUpdate.setPgTransaction(pgTransaction);
				
		     	HttpHeaders headers = new HttpHeaders();
		     	headers.add("language", "en");
		     	headers.add("Content-Type", "application/json");
		     	JSONObject obj = new JSONObject(pgTxnUpdate);
				String strJson = obj.toString();
		        HttpEntity<String> entity = new HttpEntity<String>(strJson,headers);
		        ResponseEntity<PGTxnUpdateResponse> response = template.exchange(appProperties.getShareitTransactionUpdateUrl(), HttpMethod.PUT, entity,
		        		PGTxnUpdateResponse.class);
		        if(response.getStatusCodeValue()==200) {
		        	LOGGER.debug("post shareit notify transaction-update done.");
		        }
				
			}
			LOGGER.debug("shareit callback updated successfully...");
		} catch (Exception e) {
			LOGGER.error("Failed to update status for shareit", e);
		}

		repsonseJson.put("result_code",200);
		repsonseJson.put("message","success");
		return repsonseJson.toString();
	
	}
	
	@RequestMapping(path = "/refund-notify/paymentResult", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public String refundNotifyPaymentResult(@RequestBody String paymentResultStr) throws Exception{

		LOGGER.info("paymentResult notification recieved from shareit :::"+paymentResultStr);

		JSONObject repsonseJson=new JSONObject();
		JSONObject requestJson=new JSONObject(paymentResultStr);
		
		/*String payOrderNo=requestJson.get("payOrderNo").toString();
		Integer orderId=Integer.parseInt(StringUtils.remove(payOrderNo, "PG"));
		
		String tradeOrderNo=requestJson.get("tradeOrderNo").toString();
		String status=("PAYORDER_STATUS_SUCCESS".equals(requestJson.get("status"))?
				AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[1]:AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[0]);
		String payChannelOrderNo=requestJson.get("payChannelOrderNo").toString();

		//update transaction and order against the order Id.
		TransactionEntity pgTransactionEntity= transactionUpdateService.findTransactionByOrderIdAndPaymentType(orderId, AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());

		pgTransactionEntity.setTransStatus(status);
		pgTransactionEntity.setPgTxnId(tradeOrderNo);
		pgTransactionEntity.setBankTxnId(payChannelOrderNo);

		try{
			transactionUpdateService.updateTransactionAndDtlStatusById(pgTransactionEntity);
		}catch (Exception e){
			LOGGER.error("Failed to update status for shareit",e);
		}

		repsonseJson.put("result_code",200);
		repsonseJson.put("message","success");*/
		return repsonseJson.toString();
	
	}
	
	
	@RequestMapping(path = "/refund-apply/paymentResult", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public String refundPaymentResult(@RequestBody ShareItRefund shareItRefund) throws Exception{

		LOGGER.info("paymentResult status recieved from shareit :::"+shareItRefund);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
		ResponseEntity<String> responseToken=commonUtil.getShareitToken();
		
		JSONObject responseData = new JSONObject();
		responseData = new JSONObject(responseToken.getBody());
		
		// multipart form-data creating for data
		MultiValueMap<String, String> mapRequest= new LinkedMultiValueMap<String, String>();
		mapRequest.add("refundId", shareItRefund.getRefundId());
		mapRequest.add("tradeNo", shareItRefund.getTradeNo());
		mapRequest.add("orderId", shareItRefund.getOrderId());
		mapRequest.add("amount", shareItRefund.getAmount());
		mapRequest.add("callbackUrl", shareItRefund.getCallbackUrl());		
		mapRequest.add("comments", shareItRefund.getComments());
		mapRequest.add("bizType", shareItRefund.getBizType());
		mapRequest.add("merchantId", shareItRefund.getMerchantId());
		mapRequest.add("timestamp", shareItRefund.getTimestamp());
		mapRequest.add("version", shareItRefund.getVersion());
		headers.set("token", responseData.get("data").toString());
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(mapRequest, headers);
		ResponseEntity<String> response = restTemplate.postForEntity(appProperties.getCricPlayShareItApiUrl(), request , String.class );
		return response.toString(); 	

	}
	
	
	@RequestMapping(path ="/refund-qry/paymentResult",method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public String refundQryResult(@RequestBody ShareItRefund shareItRefund) throws Exception{
		LOGGER.info("refundQryResult shareit :::"+shareItRefund);
		
		ResponseEntity<String> responseToken=commonUtil.getShareitToken();
		
		JSONObject responseData = new JSONObject();
		responseData = new JSONObject(responseToken.getBody());
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set("token", responseData.get("data").toString());
		
		// multipart form-data creating for data
		MultiValueMap<String, String> mapRequest= new LinkedMultiValueMap<String, String>();
		mapRequest.add("refundId", shareItRefund.getRefundId());
		mapRequest.add("tradeNo", shareItRefund.getTradeNo());
		mapRequest.add("orderId", shareItRefund.getOrderId());
		mapRequest.add("comments", shareItRefund.getComments());
		mapRequest.add("bizType", shareItRefund.getBizType());
		mapRequest.add("merchantId", shareItRefund.getMerchantId());
		mapRequest.add("timestamp", shareItRefund.getTimestamp());
		mapRequest.add("version", shareItRefund.getVersion());
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(mapRequest, headers);
		ResponseEntity<String> response = restTemplate.postForEntity(appProperties.getCricPlayShareItApiUrl(), request , String.class );
		return response.toString(); 
	}
	
	@RequestMapping(path = "/status/paymentResult", method = RequestMethod.POST,consumes = MediaType.APPLICATION_JSON_VALUE)
	public String statusPaymentResult(@RequestBody ShareItRefund shareItRefund) throws Exception{

		LOGGER.info("paymentResult status recieved from shareit :::"+shareItRefund);
		JSONObject responseData = new JSONObject();
		ResponseEntity<String> responseToken=commonUtil.getShareitToken();
		responseData = new JSONObject(responseToken.getBody());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		headers.set("token", responseData.get("data").toString());
		
		// multipart form-data creating for data
		MultiValueMap<String, String> mapRequest= new LinkedMultiValueMap<String, String>();
		mapRequest.add("orderId", shareItRefund.getOrderId());
		mapRequest.add("bizType", shareItRefund.getBizType());
		mapRequest.add("merchantId", shareItRefund.getMerchantId());
		mapRequest.add("timestamp", shareItRefund.getTimestamp());
		mapRequest.add("version", shareItRefund.getVersion());
		
		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(mapRequest, headers);
		ResponseEntity<String> response = restTemplate.postForEntity(appProperties.getCricPlayShareItApiUrl(), request , String.class);
		return response.toString(); 	

	}
	
}
