package com.cricplay.pgi.services;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.model.VerifyUserResponse;

/**
 * 
 * @author infinity labs
 *
 */
@Service
public class VerifyUserServiceImpl implements VerifyUserService{

	public static final Logger LOGGER = Logger.getLogger(VerifyUserServiceImpl.class);
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	AppProperties appProperties;
	
	
	
	/**
	 * verifying user against authorization token
	 */
	@Override
	public  ResponseEntity<VerifyUserResponse> verifyUser(String authorizationToken) throws Exception{
		
		ResponseEntity<VerifyUserResponse> response=null;
		
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", authorizationToken);
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        
        try {
        	response = restTemplate.exchange(appProperties.getVerifyUserUrl(), HttpMethod.GET, entity, VerifyUserResponse.class);
        	LOGGER.info("Response from verifying User service ::"+response);
        }catch(Exception e) {
        	LOGGER.debug("Error while verifying user.");
        	LOGGER.debug("Exception :::"+e.getCause());
        }
        return response;
	}
	
}
