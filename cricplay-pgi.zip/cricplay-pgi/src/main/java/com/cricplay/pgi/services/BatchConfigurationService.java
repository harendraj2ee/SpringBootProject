package com.cricplay.pgi.services;

import com.cricplay.pgi.data.entity.BatchConfigurationEntity;

public interface BatchConfigurationService {
	
	public BatchConfigurationEntity findBatchConfigurationByType(String batchType) throws Exception;
	
	public BatchConfigurationEntity updateBatchConfigurationById(String currentStatus,String batchStatus, Integer Id) throws Exception;
	
	public BatchConfigurationEntity findBatchConfigurationByStatus();

}

