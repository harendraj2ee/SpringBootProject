package com.cricplay.pgi.model;

import com.cricplay.pgi.util.StringUtils;

import java.io.Serializable;

public class SmsRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String userId;
	private String message;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	public SmsRequest(String userId, String message) {
		this.userId = userId;
		this.message = message;
	}

	public SmsRequest() {

	}
	@Override
	public String toString() {
		return StringUtils.toJson(this);
	}
	
	
}
