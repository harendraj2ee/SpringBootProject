package com.cricplay.pgi.model;

import java.io.Serializable;

public class VerifyUserResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String userUniqueId;
	String mobile;
	String alias;
	String avatar;
	String referralLink;
	String referredBy;
	Integer winnings;
	Integer coins;
	Integer referredCoin;
	String paytmNumber;
	Integer messageCounter;
	boolean hasFacebookHandle;
	boolean megaContestPlayed;
	boolean firstTeamCreated;
	boolean superleagueContestPlayed;

	public String getUserUniqueId() {
		return userUniqueId;
	}

	public void setUserUniqueId(String userUniqueId) {
		this.userUniqueId = userUniqueId;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAlias() {
		return alias;
	}

	public void setAlias(String alias) {
		this.alias = alias;
	}

	public String getAvatar() {
		return avatar;
	}

	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}

	public String getReferralLink() {
		return referralLink;
	}

	public void setReferralLink(String referralLink) {
		this.referralLink = referralLink;
	}

	public String getReferredBy() {
		return referredBy;
	}

	public void setReferredBy(String referredBy) {
		this.referredBy = referredBy;
	}

	public Integer getWinnings() {
		return winnings;
	}

	public void setWinnings(Integer winnings) {
		this.winnings = winnings;
	}

	public Integer getCoins() {
		return coins;
	}

	public void setCoins(Integer coins) {
		this.coins = coins;
	}

	public Integer getReferredCoin() {
		return referredCoin;
	}

	public void setReferredCoin(Integer referredCoin) {
		this.referredCoin = referredCoin;
	}

	public String getPaytmNumber() {
		return paytmNumber;
	}

	public void setPaytmNumber(String paytmNumber) {
		this.paytmNumber = paytmNumber;
	}

	public Integer getMessageCounter() {
		return messageCounter;
	}

	public void setMessageCounter(Integer messageCounter) {
		this.messageCounter = messageCounter;
	}

	public boolean isHasFacebookHandle() {
		return hasFacebookHandle;
	}

	public void setHasFacebookHandle(boolean hasFacebookHandle) {
		this.hasFacebookHandle = hasFacebookHandle;
	}

	public boolean isMegaContestPlayed() {
		return megaContestPlayed;
	}

	public void setMegaContestPlayed(boolean megaContestPlayed) {
		this.megaContestPlayed = megaContestPlayed;
	}

	public boolean isFirstTeamCreated() {
		return firstTeamCreated;
	}

	public void setFirstTeamCreated(boolean firstTeamCreated) {
		this.firstTeamCreated = firstTeamCreated;
	}

	public boolean isSuperleagueContestPlayed() {
		return superleagueContestPlayed;
	}

	public void setSuperleagueContestPlayed(boolean superleagueContestPlayed) {
		this.superleagueContestPlayed = superleagueContestPlayed;
	}


	@Override
	public String toString() {
		return "VerifyUserResponse [userUniqueId=" + userUniqueId + ", mobile=" + mobile + ", alias=" + alias
				+ ", avatar=" + avatar + ", referralLink=" + referralLink + ", referredBy=" + referredBy + ", winnings="
				+ winnings + ", coins=" + coins + ", referredCoin=" + referredCoin + ", paytmNumber=" + paytmNumber
				+ ", messageCounter=" + messageCounter + ", hasFacebookHandle=" + hasFacebookHandle
				+ ", megaContestPlayed=" + megaContestPlayed + ", firstTeamCreated=" + firstTeamCreated
				+ ", superleagueContestPlayed=" + superleagueContestPlayed + "]";
	}

}
