package com.cricplay.pgi.services;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.dao.TransactionRefundDao;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.entity.TransactionRefundHistory;
import com.cricplay.pgi.model.PGTxnUpdate;

@Service
public class TransactionRefundServiceImpl implements TransactionRefundService{
	
	public static final Logger LOGGER = Logger.getLogger(TransactionRefundServiceImpl.class);
	
	@Autowired
	TransactionDao transactionDao;
	
	@Autowired
	TransactionRefundDao transactionRefundDao;

	@Override
	public TransactionRefundEntity createTransactionRefund(PGTxnUpdate pgTxnUpdate,String orderType)
			throws Exception {
		LOGGER.debug("TransactionRefundService start...");
		
		TransactionRefundEntity transactionRefundEntity = new TransactionRefundEntity();
		
		if(orderType.equalsIgnoreCase(AppConstant.ORDER_TYPE.PG_ONLY.getValue())) {
			
			
			
		}
		
		
		else if(orderType.equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue())) {
			
			
			if(pgTxnUpdate.getOrderId()!=null) {
				transactionRefundEntity.setOrderId(pgTxnUpdate.getOrderId());
			}
			if(pgTxnUpdate.getPgTransaction().getPgTxnId()!=null) {
				transactionRefundEntity.setTransactionRefId(pgTxnUpdate.getPgTransaction().getPgTxnId());
			}
			//??? txn type will be from order.getOrderType()
			if(pgTxnUpdate.getPgTransaction().getTxnType()!=null) {
				transactionRefundEntity.setTranscationType(pgTxnUpdate.getPgTransaction().getTxnType());
			}
			if(pgTxnUpdate.getPgTransaction().getRefundAmount()!=null) {
				transactionRefundEntity.setRefundAmount(pgTxnUpdate.getPgTransaction().getRefundAmount());
			}
			if(pgTxnUpdate.getPgTransaction().getRefundAmount()!=null) {
				transactionRefundEntity.setTotalRefundAmount(pgTxnUpdate.getPgTransaction().getRefundAmount());
			}
			if(pgTxnUpdate.getPgTransaction().getStatus()!=null) {
				transactionRefundEntity.setRefundStatus(pgTxnUpdate.getPgTransaction().getStatus());
			}
			transactionRefundEntity.setRefundDate(null);
			
			if(pgTxnUpdate.getPgTransaction().getRespMsg()!=null) {
				transactionRefundEntity.setComment(pgTxnUpdate.getPgTransaction().getRespMsg());
			}
			transactionRefundEntity.setPgRefundTransId(null);
			
			if(pgTxnUpdate.getPgTransaction().getBankTxnId()!=null) {
				transactionRefundEntity.setBankTxnId(pgTxnUpdate.getPgTransaction().getBankTxnId());
			}
			
		}
		
		return transactionDao.createTransactionRefund(transactionRefundEntity);
	}

	
	/**
	 * for entry in pg_transaction_refund table.
	 */
	@Override
	public int saveTransactionRefund(TransactionEntity transactionEntity,String refundStatus) throws Exception {
		int counter=0;
		TransactionRefundEntity transactionRefundEntity=new TransactionRefundEntity();
		
		if(transactionEntity.getOrder()!=null) {
			transactionRefundEntity.setOrderId(transactionEntity.getOrder().getOrderId());
		}
		
		if(transactionEntity.getBankTxnId()!=null) {
			transactionRefundEntity.setBankTxnId(transactionEntity.getBankTxnId());
		}
		
		if(transactionEntity.getAmount()!=null) {
			transactionRefundEntity.setRefundAmount(String.valueOf(transactionEntity.getAmount()));
		}
		
		if(transactionEntity.getAmount()!=null) {
		transactionRefundEntity.setTotalRefundAmount(transactionEntity.getAmount().toString());
		}
		
		if(!StringUtils.isEmpty(refundStatus)) {
			transactionRefundEntity.setRefundStatus(refundStatus);
		}else {
			transactionRefundEntity.setRefundStatus(AppConstant.PG_REFUND_STATUS.PG_REFUND_INITIATED.getValue());
		}
		
		transactionRefundEntity.setRefundStatus(refundStatus);

		transactionRefundEntity.setRefundDate(null);
		transactionRefundEntity.setComment("");
		
		if(transactionEntity.getPgTxnId()!=null) {
			transactionRefundEntity.setTransactionRefId(transactionEntity.getPgTxnId());
		}else{
			transactionRefundEntity.setTransactionRefId("0");
		}
		
		transactionRefundEntity.setPgRefundTransId(null);
		
		if(transactionEntity.getPaymentType()!=null) {
		transactionRefundEntity.setTranscationType(transactionEntity.getPaymentType());
		}
		
		if(transactionEntity.getTransId()!=null) {
			transactionRefundEntity.setTransId(transactionEntity.getTransId());
		}else {
			transactionRefundEntity.setTransId(0);
		}
		transactionRefundEntity.setRetryCounter(counter);
	
		LOGGER.info("save transactionRefundEntity ::"+transactionRefundEntity);
		
		return transactionDao.saveTransactionRefund(transactionRefundEntity);
	}
	
	@Override
	public List<TransactionRefundEntity> findTransactionRefundByTransType(String transcationType, String refundStatus) throws Exception {
		return transactionRefundDao.findTransactionRefundByTransType(transcationType, refundStatus);

	}

	@Override
	public Set<TransactionRefundEntity> findTransactionRefundByRefundStatus(String refundStatus, String transcationType) throws Exception {
		return transactionRefundDao.findTransactionRefundByRefundStatus(refundStatus, transcationType);
	}
	
	@Override
	public List<TransactionRefundEntity> findTransactionRefundByOderId(Integer orderId,String refundStatus){
		return transactionRefundDao.findTransactionRefundByOderId(orderId, refundStatus);
	}

	/**
	 * for entry in pg_transaction_refund history table.
	 */
	@Override
	public int saveTransactionRefundHistory(TransactionEntity transactionEntity,String refundStatus) throws Exception {
		
		TransactionRefundHistory transactionRefundHistory=new TransactionRefundHistory();
		
		if(transactionEntity.getOrder().getOrderId()!=null) {
			transactionRefundHistory.setOrderId(transactionEntity.getOrder().getOrderId());
		}
		
		if(transactionEntity.getBankTxnId()!=null) {
			transactionRefundHistory.setBankTxnId(transactionEntity.getBankTxnId());
		}
		
		if(transactionEntity.getAmount()!=null) {
			transactionRefundHistory.setRefundAmount(String.valueOf(transactionEntity.getAmount()));
		}
		
		if(transactionEntity.getAmount()!=null) {
			transactionRefundHistory.setTotalRefundAmount(transactionEntity.getAmount().toString());
		}else {
			transactionRefundHistory.setTotalRefundAmount("0");
		}

		transactionRefundHistory.setRefundStatus(refundStatus);
		
		transactionRefundHistory.setRefundDate(new Date());
		transactionRefundHistory.setComment("");
		
		if(transactionEntity.getPgTxnId()!=null) {
			transactionRefundHistory.setTransactionRefId(transactionEntity.getPgTxnId());
		}else{
			transactionRefundHistory.setTransactionRefId("0");
		}
		
		transactionRefundHistory.setPgRefundTransId(null);
		
		if(transactionEntity.getPaymentType()!=null) {
			transactionRefundHistory.setTranscationType(transactionEntity.getPaymentType());
		}
		
		if(transactionEntity.getTransId()!=null) {
			transactionRefundHistory.setTransId(transactionEntity.getTransId());
		}else {
			transactionRefundHistory.setTransId(0);
		}

		LOGGER.info("save transactionRefundEntity ::"+transactionRefundHistory);
		
		return transactionDao.saveTransactionRefundHistory(transactionRefundHistory);
	}


}