package com.cricplay.pgi.model;

import java.io.Serializable;

public class OrderResponse extends Response implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String orderId;
	private Checksum checksum;
	private ShareItToken token;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Checksum getChecksum() {
		return checksum;
	}

	public void setChecksum(Checksum checksum) {
		this.checksum = checksum;
	}

	public ShareItToken getToken() {
		return token;
	}

	public void setToken(ShareItToken token) {
		this.token = token;
	}


	

}
