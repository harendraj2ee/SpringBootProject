
package com.cricplay.pgi.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.PlanEntity;

@Repository
public interface PlanRepository extends JpaRepository<PlanEntity, Integer>{

	@Query(value = "SELECT * FROM pg_plan where plan_id=?", nativeQuery = true)
	PlanEntity findPlanById(Integer planId);

}

