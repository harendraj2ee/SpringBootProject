package com.cricplay.pgi.services;

import java.util.List;

import com.cricplay.pgi.data.entity.TransactionEntitySinglton;

public interface TransactionEntityService {
	
	public List<TransactionEntitySinglton> findTransactionByOrderId(Integer orderId);

}
