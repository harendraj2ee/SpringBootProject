package com.cricplay.pgi.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.TransDetailsEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.entity.TransactionRefundHistory;
import com.cricplay.pgi.data.repository.TransDetailsRepository;
import com.cricplay.pgi.data.repository.TransactionRefundHistoryRepository;
import com.cricplay.pgi.data.repository.TransactionRefundRepository;
import com.cricplay.pgi.data.repository.TransactionRepository;

@Repository
public class TransactionDaoImpl implements TransactionDao{

	public static final Logger LOGGER = Logger.getLogger(OrderDaoImpl.class);
	
	@Autowired
	TransactionRepository transacitonRepository;
	
	@Autowired
	TransDetailsRepository transactionDetailsRepository;
	
	@Autowired
	TransactionRefundRepository transactionRefundRepository;
	
	@Autowired
	TransactionRefundHistoryRepository transactionRefundHistoryRepository;
	
	@Autowired
	EntityManager em;
	
	@Override
	public TransactionEntity updateTransaction(TransactionEntity transactinEntity) {
		
		
		return transacitonRepository.save(transactinEntity);
		
	}

	@Override
	public Integer findTransactionIdByOrderIdAndPaymentType(Integer orderId, String paymentType) throws Exception{
		
		return transacitonRepository.findTransactionIdByOrderIdAndPaymentType(orderId, paymentType);
	}

	@Override
	public int updatePgTransaciton(String transStatus, String pgTxnId, String bankTxnId, String txnType,
			String gatewayName, String respCode, String respmsg,String bankName, String paymentMode, String refundAmt, String txnDate,
			Integer orderId, String paymentType) throws Exception {
		
		return transacitonRepository.updatePgTransaction(transStatus, pgTxnId, bankTxnId, txnType, gatewayName, respCode, respmsg, bankName, paymentMode, refundAmt, txnDate, orderId, paymentType);
		
	}

	@Override
	public TransDetailsEntity createTransDetail(TransDetailsEntity transDetailsEntity) throws Exception {
		
		return transactionDetailsRepository.saveAndFlush(transDetailsEntity);
		
	}

	@Override
	public TransactionRefundEntity createTransactionRefund(TransactionRefundEntity transactinRefundEntity)
			throws Exception {
		return transactionRefundRepository.saveAndFlush(transactinRefundEntity);
	}

	@Override
	public int saveTransactionRefund(TransactionRefundEntity transactinRefundEntity) throws Exception {
		try {
			Long count = transactionRefundRepository
					.findTransactionRefundEntityCountByTransId(transactinRefundEntity.getTransId());
			if (count == 0) {
				transactionRefundRepository.saveAndFlush(transactinRefundEntity);
				return 1;
			}
			else {
				LOGGER.debug("Transaction already exist in refund table");
				return 1;
			}
		} catch (Exception e) {
			LOGGER.debug("Error while saving Transaction Refund Entity");
		}
		return 0;
	}

	@Override
	public Object[] findTransactionByOrderIdAndPaymentType(Integer orderId, String paymentType) {
		return transacitonRepository.findTransactionByOrderIdAndPaymentType(orderId,paymentType);
		
	}
	
	
	public TransactionEntity findTransByOrderIdAndPaymentType(Integer orderId,String paymentType) {
		return transacitonRepository.findTransByOrderIdAndPaymentType(orderId,paymentType);
		
	}
	

	@Override
	public List<TransactionEntitySinglton> findTransaction(Integer orderId, String paymentType) {
		
		Query query=em.createNativeQuery("select * from pg_transaction where order_id=? and payment_type=?", TransactionEntitySinglton.class);
		query.setParameter(1, orderId);
		query.setParameter(2, paymentType);
		
		List<TransactionEntitySinglton>  transactionList=query.getResultList();
		
		return transactionList;
	}
	
	@Override
	public List<TransactionEntity> findTransactionEntity(Integer orderId, String paymentType) {
		
		Query query=em.createNativeQuery("select * from pg_transaction where order_id=? and payment_type=?", TransactionEntity.class);
		query.setParameter(1, orderId);
		query.setParameter(2, paymentType);
		
		List<TransactionEntity>  transactionList=query.getResultList();
		
		return transactionList;
	}
	
	@Override
	public List<TransactionEntity> findTransByOrderId(Integer orderId){
		
		return transacitonRepository.findTransByOrderId(orderId);
		
	}

	@Override
	public List<TransactionEntitySinglton> findTransactionStatusBytransStatus(String transStatus) {
		
		Query query=em.createNativeQuery("select * from pg_transaction where trans_status=?", TransactionEntitySinglton.class);
		query.setParameter(1, transStatus);
		List<TransactionEntitySinglton>  transactionList=query.getResultList();
		
		return transactionList;
		
		
	}

	@Override
	public List<TransactionEntitySinglton> findTransactionByOrderId(Integer orderId) {
		
		Query query=em.createNativeQuery("select * from pg_transaction where order_id=?", TransactionEntitySinglton.class);
		query.setParameter(1, orderId);
		List<TransactionEntitySinglton>  transactionList=query.getResultList();
		return transactionList;
		//return transacitonRepository.findTransacitonByOrderId(orderId);
	}
	
	@Override
	public TransactionEntity getTransactionEntity(Integer transactionId) {
		TransactionEntity transactionEntity=transacitonRepository.findTransacitonById(transactionId);
		return transactionEntity;
	}

	@Override
	public List<TransactionEntity> findTransactionStatusBytransStatus(String transStatus, String paymentType) {
		Query query=em.createNativeQuery("select * from pg_transaction where trans_status=? and payment_type=?", TransactionEntity.class);
		query.setParameter(1, transStatus);
		query.setParameter(2, paymentType);
		List<TransactionEntity>  transactionList=query.getResultList();
		
		return transactionList;
		
	}

	@Override
	public List<TransactionEntity> findTransactionByStatusAndPaymentType(String transStatus, String paymentType,
			Date createdOn) {
		Query query=em.createNativeQuery("select * from pg_transaction where trans_status=? and payment_type=? and created_on<=? limit 100", TransactionEntity.class);
		query.setParameter(1, transStatus);
		query.setParameter(2, paymentType);
		query.setParameter(3, createdOn);
		@SuppressWarnings("unchecked")
		List<TransactionEntity>  transactionList=query.getResultList();
		
		return transactionList;
	}

	@Override
	public int saveTransactionRefundHistory(TransactionRefundHistory transactinRefundHistory) throws Exception {
		
		TransactionRefundHistory transactionRefundHistory=transactionRefundHistoryRepository.save(transactinRefundHistory);
		
		if(transactionRefundHistory.getId()!=null) {
			return 1;
		}
		return 0;
	}
}
