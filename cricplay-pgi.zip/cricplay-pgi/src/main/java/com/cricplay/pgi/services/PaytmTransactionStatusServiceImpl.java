package com.cricplay.pgi.services;

import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.model.Checksum;
import com.paytm.pg.merchant.CheckSumServiceHelper;


@Service
public class PaytmTransactionStatusServiceImpl implements PaytmTransactionStatusService {

	public static final Logger LOGGER = Logger.getLogger(Checksum.class);

	@Autowired
	AppProperties appProperties;

	@Autowired
	RestTemplate restTemplate;

	public String paytmtransactionStatus(String orderid) {

		JSONObject responseData = new JSONObject();
		RestTemplate restTemplate = new RestTemplate();

		LOGGER.info("\n orderId - " + orderid);

			String merchantMid = appProperties.getMerchantId();
			String orderId = orderid;
			String merchantKey = appProperties.getMerchantKey();

			TreeMap<String, String> paytmParams = new TreeMap<String, String>();

			paytmParams.put("MID", merchantMid);
			paytmParams.put("ORDERID", orderId);

			try {
				paytmParams.put("CHECKSUM",
						CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(merchantKey, paytmParams));
				JSONObject responseObj = new JSONObject(paytmParams);

				HttpEntity<String> payload = new HttpEntity<String>(new JSONObject(paytmParams).toString());

				LOGGER.info("\n payload request STATUS = " + payload);

				ResponseEntity<String> response = restTemplate.exchange(appProperties.getPaytmTransactionStatusUrl(),
						HttpMethod.POST, payload, String.class);

				JSONObject RESPONSE = new JSONObject(response.getBody());

				LOGGER.info("\n PG transaction status with TXN Id and STATUS  " + RESPONSE);

				if (RESPONSE.get("STATUS").equals("TXN_SUCCESS")) {
					responseData.put("status", RESPONSE.get("STATUS"));
					responseData.put("message", "refund initiated successfully");
					responseData.put("response", RESPONSE);
					responseData.put("statusCode", RESPONSE.get("RESPCODE"));
				} else {
					responseData.put("status", RESPONSE.get("STATUS"));
					responseData.put("message", RESPONSE.get("RESPMSG"));
					responseData.put("response", RESPONSE);
					responseData.put("statusCode", RESPONSE.get("RESPCODE"));
				}

			} catch (Exception exception) {
				exception.printStackTrace();
		}
		return responseData.toString();

	}
}
