package com.cricplay.pgi.util;

import com.cricplay.pgi.data.entity.LanguagePlaceholderEntity;
import com.cricplay.pgi.data.repository.LanguagePlaceholderRepository;
import com.cricplay.pgi.notification.SmsNotifier;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class MessageSelector {

    public static final Logger LOGGER = Logger.getLogger(MessageSelector.class);
    private static final String SUCCESS = "SUCCESS";
    private static final String FAILURE = "FAILURE";

    @Autowired
    private LanguagePlaceholderRepository languagePlaceholderRepository;

    /**
     * get message label based on event and user language
     * @param event
     * @param language
     * @param variablesMap
     * @return
     * @throws Exception
     */
    public String getMessageLabel(String event, String language, Map<String,String> variablesMap) throws Exception {

        LOGGER.debug("get message label request received ::");
        try {
            //1.fetch the sms content form db.
            if(org.springframework.util.StringUtils.isEmpty(language)){
                language="en";
            }
            LanguagePlaceholderEntity languagePlaceholderEntity = languagePlaceholderRepository.getPlaceholderByEventLangType(
                    event, language, "LABEL");

            if (languagePlaceholderEntity == null) {
                    LOGGER.error("No placeholder found for ::" + event + " ::" + language);
                throw new Exception("No placeholder found for ::" + event + " ::" + language);
            }

            String message = StringUtils.populateVariables(languagePlaceholderEntity.getMessage(), variablesMap);

            return message;

        } catch (Exception e) {
            LOGGER.error("get message label failed ::", e);
            throw e;

        }

    }

}
