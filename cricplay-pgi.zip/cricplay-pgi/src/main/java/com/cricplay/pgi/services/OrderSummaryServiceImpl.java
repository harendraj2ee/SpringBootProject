package com.cricplay.pgi.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.common.BaseDaoResponse;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.model.OrderModel;

@Service
public class OrderSummaryServiceImpl implements OrderSummaryService{
	
	@Autowired
	OrderDao orderDao;

	@Override
	public OrderModel getOrderSummary(Integer orderId, String userId) throws Exception {
		
		OrderModel orderModel=new OrderModel();
		BaseDaoResponse object = orderDao.getOrderSummary(orderId, userId);
		Object[] responseArray= (Object[])object.getResponse();
		
		if(responseArray[0]!=null) {
			orderModel.setOrderId(responseArray[0].toString());
		}
		if(responseArray[1]!=null) {
			orderModel.setPlanId((Integer) responseArray[1]);
		}
		if(responseArray[2]!=null) {
			orderModel.setPlanName((String) responseArray[2]);
		}
		if(responseArray[3]!=null) {
			orderModel.setOrderStatus((String) responseArray[3]);
		}
		if(responseArray[4]!=null) {
			orderModel.setCreatedOn(responseArray[4].toString());
		}
		if(responseArray[5]!=null) {
			orderModel.setModifiedOn(responseArray[5].toString());
		}
		if(responseArray[6]!=null) {
			orderModel.setWinningBalanceUsed(Double.valueOf(responseArray[6].toString()) );
		}
		if(responseArray[7]!=null) {
			orderModel.setAmountPaidByPG((Double) Double.valueOf(responseArray[7].toString()));
		}
		if(responseArray[8]!=null) {
			orderModel.setAmountPaid((Double) Double.valueOf(responseArray[8].toString()));
		}
		if(responseArray[9]!=null) {
			orderModel.setCoins( (Integer.parseInt(responseArray[9].toString())));
		}
		orderModel.setMessage("");
		return orderModel;
	}

	@Override
	public OrderEntity getOrderById(Integer orderId) throws Exception {
		
		return orderDao.getOrderSummary(orderId);
		
	}

	@Override
	public List<OrderEntity> findOrderByStatus(String status) {
		List<OrderEntity> orderEntityList=orderDao.findOrderEntityListByStatus(status);
		return orderEntityList;
	}

}
