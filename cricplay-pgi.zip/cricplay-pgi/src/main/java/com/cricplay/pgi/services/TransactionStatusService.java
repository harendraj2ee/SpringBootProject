package com.cricplay.pgi.services;

import org.springframework.http.ResponseEntity;

import com.cricplay.pgi.model.TransactionStatusRequest;
import com.cricplay.pgi.model.TransactionStatusResponse;

public interface TransactionStatusService {
	
	public ResponseEntity<TransactionStatusResponse> getTransactionStatus(TransactionStatusRequest payload);

}
