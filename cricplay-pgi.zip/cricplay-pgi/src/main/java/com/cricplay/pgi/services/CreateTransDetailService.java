package com.cricplay.pgi.services;

import com.cricplay.pgi.data.entity.TransDetailsEntity;
import com.cricplay.pgi.model.PGTxnUpdate;

public interface CreateTransDetailService {

	public TransDetailsEntity createTransDetail(PGTxnUpdate pgTxnUpdate,String userId,String paymentType,String requestId,String eventType) throws Exception;
	
}
