package com.cricplay.pgi.controller;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.OrderStatusEntity;
import com.cricplay.pgi.services.BatchConfigurationService;
import com.cricplay.pgi.services.BatchJobService;
import com.cricplay.pgi.services.CreateOrderService;
@CrossOrigin
@RestController
@RequestMapping(value = "/cricplay/api/v1")
public class BatchConfigurationController {
	
	private static final Logger LOGGER = Logger.getLogger(BatchConfigurationController.class);

	@Autowired
	BatchConfigurationService batchConfigurationService;

	@Autowired
	BatchJobService batchJobService;

	@Autowired
	CreateOrderService createOrderService;

	@RequestMapping(value = "/getBatchConfigByType", method = RequestMethod.GET)
	public BatchConfigurationEntity findConfigurationByType(@RequestParam(value = "batchtype") String batchType)
			throws Exception {
		BatchConfigurationEntity batchConfigurationEntity = null;
		BatchJobEntity batchJobEntity = null;
		BatchConfigurationEntity updatedBatchConfigurationEntity = null;
		List<OrderStatusEntity> orderStatusEntity = null;

		batchConfigurationEntity = batchConfigurationService.findBatchConfigurationByType(batchType);
		LOGGER.info("Batch Configruation enity list data " + batchConfigurationEntity);
		
		try {

			if (!batchConfigurationEntity.getCurrentStatus().equalsIgnoreCase("Running")) {

				updatedBatchConfigurationEntity = batchConfigurationService.updateBatchConfigurationById("Running",
						"Active", batchConfigurationEntity.getId());
				LOGGER.info("Batch Configration Entity update by cron type" + updatedBatchConfigurationEntity);

				batchJobEntity = batchJobService.insertBatchJobByRow(batchConfigurationEntity.getId(),
						batchConfigurationEntity.getBatchType(), new Date(), null, null );
				LOGGER.info("Batch Job inserted data in Batch Table by Batchtype Id" + batchJobEntity);

				String orderStatusCoin = "CoinCreditPending";
				orderStatusEntity = createOrderService.findOrderListByStatus(orderStatusCoin);

				Integer count = 0;
				boolean transactionServiceStatus = true;
				for (OrderStatusEntity orderListEntity : orderStatusEntity) {
					count = count + 1;
					if (transactionServiceStatus == true) {
						System.out.println("Transaction job is running");

					} else {
						System.out.println("Transaction job is not running ");

					}
				}

				LOGGER.info("Current Row id from Batch job table" + batchJobEntity.getId());
				LOGGER.info("Batch Job updated the count of order Table by Batchtype Id" + orderStatusEntity.size());
				batchJobEntity = batchJobService.updateBatchJobByRow(count, batchJobEntity.getId());

				System.out.println("batchConfigurationEntity.getId() - " + batchConfigurationEntity.getId());
				updatedBatchConfigurationEntity = batchConfigurationService.updateBatchConfigurationById("Ideal",
						"Active", batchConfigurationEntity.getId());
				LOGGER.info("Batch Configration Entity update after Batch Transaction cron type"
						+ updatedBatchConfigurationEntity);

			} else {
				LOGGER.info("Batch process could not start, Because process is running mode");
				return batchConfigurationEntity;
			}

			return batchConfigurationEntity;
		} catch (Exception e) {
			LOGGER.error("Exception occured while creating order::" + e.getMessage());
			throw new Exception(e);

		}

	}
	
	
	public static String encodeByMd5(String plainText) {
		try {
		MessageDigest digest = MessageDigest.getInstance("MD5");
		byte[] result = digest.digest(plainText.getBytes());
		StringBuffer buffer = new StringBuffer();
		for (byte b : result) {
		int number = b & 0xff;
		String str = Integer.toHexString(number);
		if (str.length() == 1) {
		buffer.append("0");
		}
		buffer.append(str);
		}
		return buffer.toString();
		} catch (NoSuchAlgorithmException e) {
		e.printStackTrace();
		return "";
		}
	}
	
	public static void main(String args[]){
		System.out.println(encodeByMd5("M36|MDdFBGAME|IN|INR|2018082011|10.0"));//签名结果  为:7da929b8690d35bcdb94eb78c704e1ce
		}

}
