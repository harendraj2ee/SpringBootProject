package com.cricplay.pgi.controller;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.repository.PlanRepository;
import com.cricplay.pgi.model.Plan;
import com.cricplay.pgi.model.PlanDTO;
import com.cricplay.pgi.model.VerifyUserResponse;
import com.cricplay.pgi.util.CommonUtil;
/**
 * 
 * @author infinity labs
 *
 */

@CrossOrigin
@RestController
@RequestMapping(value="/cricplay/api/v1")
public class PlanController {
	
	private static final Logger logger = Logger.getLogger(CommonUtil.class);
	
	@Autowired
	private PlanRepository planRepo;
	
	@Autowired 
	CommonUtil commonUtil;
	
	/**
	 * Get all plans from pg_plan table
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/plan",method =RequestMethod.GET, headers = "Accept=application/json")
	public @ResponseBody  PlanDTO plansRetriveAll(HttpServletRequest request) throws Exception {
		PlanDTO planDTO=new PlanDTO();
		ResponseEntity<VerifyUserResponse> verifyUserResponse;
		if (request.getHeader("Authorization")!=null) {
			 verifyUserResponse=commonUtil.verifyUser(request.getHeader("Authorization"));
			 
		    if(!StringUtils.isEmpty(verifyUserResponse)) {
		    	
		    	String userUniqueId=verifyUserResponse.getBody().getUserUniqueId();
	            
	            if(!StringUtils.isEmpty(userUniqueId)) {
	            	
	            	List<PlanEntity> planEntityList= planRepo.findAll();
	        		List<Plan> planList= new ArrayList<Plan>();
	        		
	        		planDTO.setMessage("User is Authenticated."); 
	        		planDTO.setStatus("success");
	        		planDTO.setStatusCode(200);
	        		
	        		for(PlanEntity planEntity:planEntityList) {			
	        			Plan plan = new Plan();
	        			plan.setAmount(planEntity.getAmount());
	        			plan.setBestValue(planEntity.getBestValue());
	        			plan.setBonusCoins(planEntity.getBonusCoins());
	        			plan.setCreatedOn(planEntity.getCreatedOn());
	        			plan.setExtra(planEntity.getExtra());
	        			plan.setImage(planEntity.getImage());
	        			plan.setIsDeleted(planEntity.getIsDeleted());
	        			plan.setModifiedOn(planEntity.getModifiedOn());
	        			plan.setPlanName(planEntity.getPlanName());
	        			plan.setPlanId(planEntity.getPlanId());
	        			plan.setSortOrder(planEntity.getSortOrder());
	        			plan.setCoins(planEntity.getCoins());
	        			planList.add(plan);
	        			planDTO.setPlans(planList);
	            	
	            }
	            
	        }
			
		}else {
			logger.debug("Not valid user...");
			planDTO.setStatusCode(400);
			planDTO.setMessage("Not valid user...");
			planDTO.setStatus("Failure");
		}

		}
		else {
			planDTO.setStatusCode(404);
			planDTO.setMessage("Authorization Token can't be empty");
			planDTO.setStatus("Failure");
		}

		return planDTO;
	}
	
	
	/**
	 * Get plan by id form pg_plan table
	 * @param planid
	 * @param request
	 * @return
	 * @throws Exception
	 */
	
	  @RequestMapping(value="/planid",method =RequestMethod.GET, headers ="Accept=application/json") 
	  public @ResponseBody PlanDTO plansById(@RequestParam(value="pid") Integer planid,HttpServletRequest request ) throws Exception { 
	  
		  PlanDTO planDTO=new PlanDTO(); 

			ResponseEntity<VerifyUserResponse> verifyUserResponse;
			if (request.getHeader("Authorization")!=null) {
				 verifyUserResponse=commonUtil.verifyUser(request.getHeader("Authorization"));
				 
			    if(!StringUtils.isEmpty(verifyUserResponse)) {
			    	
			    	String userUniqueId=verifyUserResponse.getBody().getUserUniqueId();
		            
		          if(!StringUtils.isEmpty(userUniqueId)) {
				  PlanEntity planEntity= planRepo.findPlanById(planid); 
				  List<Plan> planList= new ArrayList<Plan>();
				  
				  //PlanDTO planDTO=new PlanDTO(); 
				  Plan plan=new Plan();
				  
				  planDTO.setMessage("User is Authenticated."); 
				  planDTO.setStatus("success");
				  planDTO.setStatusCode(200);
				  
				  plan.setAmount(planEntity.getAmount());
				  plan.setBestValue(planEntity.getBestValue());
				  plan.setBonusCoins(planEntity.getBonusCoins());
				  plan.setCreatedOn(planEntity.getCreatedOn());
				  plan.setExtra(planEntity.getExtra()); 
				  plan.setImage(planEntity.getImage());
				  plan.setIsDeleted(planEntity.getIsDeleted());
				  plan.setModifiedOn(planEntity.getModifiedOn());
				  plan.setPlanName(planEntity.getPlanName());
				  plan.setPlanId(planEntity.getPlanId());
				  plan.setSortOrder(planEntity.getSortOrder());
				  plan.setCoins(planEntity.getCoins());
				  
				  planList.add(plan); 
				  planDTO.setPlans(planList); 
				 
				  }
			 }
				 
			else {
				logger.debug("Not valid user...");
				planDTO.setStatusCode(400);
				planDTO.setMessage("Not valid user...");
				planDTO.setStatus("Failure");
			}
			}
			else {
				planDTO.setStatusCode(404);
				planDTO.setMessage("Authorization Token can't be empty");
				planDTO.setStatus("Failure");
			}
			return planDTO;
		}
	
}

