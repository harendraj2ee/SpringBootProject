package com.cricplay.pgi.data.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.cricplay.pgi.util.StringUtils;

@Entity
@Table(name = "pg_order")
public class OrderEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "order_id", updatable = false, nullable = false)
	private Integer orderId;
	
	@Column(name = "plan_id")
	private Integer planId;
	
	@Column(name = "user_id")
	private String userId;
	
	@Column(name = "price")
	private Double price;
	
	@Column(name = "created_on")
	private Date createdOn;
	
	@Column(name = "modified_on")
	private Date modifiedOn;
	
	@Column(name = "status")
	private String status;
	
	@Column(name ="order_type")
	private String orderType;
	
	@Column(name ="credit_coin_request_id")
	private String creditCoinReqId;
	
	@Column(name ="coins")
	private Double coins;
	
	@Column(name ="retry_counter") 
	private Integer retryCounter;
	
	@OneToMany(mappedBy="order")
	//@OneToMany(fetch=FetchType.LAZY, mappedBy="order", cascade = {CascadeType.PERSIST})
	//@OneToMany(mappedBy="order", cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	
	
	private Set<TransactionEntity> transactions;
	
	public Set<TransactionEntity> getTransactions() {
		return transactions;
	}
	public void setTransactions(Set<TransactionEntity> transactions) {
		this.transactions = transactions;
	}
	
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOrderType() {
		return orderType;
	}
	public void setOrderType(String orderType) {
		this.orderType = orderType;
	}
	public String getCreditCoinReqId() {
		return creditCoinReqId;
	}
	public void setCreditCoinReqId(String creditCoinReqId) {
		this.creditCoinReqId = creditCoinReqId;
	}
	
	
	@Override
	public String toString() {
		return StringUtils.toJson(this);
	}
	public Double getCoins() {
		return coins;
	}
	public void setCoins(Double coins) {
		this.coins = coins;
	}
	public Integer getRetryCounter() {
		return retryCounter;
	}
	public void setRetryCounter(Integer retryCounter) {
		this.retryCounter = retryCounter;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public Date getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

}
