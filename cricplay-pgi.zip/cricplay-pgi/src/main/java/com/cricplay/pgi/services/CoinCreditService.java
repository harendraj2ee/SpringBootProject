package com.cricplay.pgi.services;

import org.springframework.http.ResponseEntity;

import com.cricplay.pgi.model.CoinCreditResponse;
import com.cricplay.pgi.model.DebitCreditRequest;

public interface CoinCreditService {

	public ResponseEntity<CoinCreditResponse> creditCoin(DebitCreditRequest request) throws Exception;
}
