package com.cricplay.pgi.Jobs;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.clevertap.model.CleverTap;
import com.cricplay.pgi.clevertap.model.CleverTapEvtDataRequest;
import com.cricplay.pgi.clevertap.model.CleverTapUploadResponse;
import com.cricplay.pgi.component.CleverTapPayloadBuilder;
import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.BatchTransactionEntity;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.repository.BatchTransactionRepository;
import com.cricplay.pgi.services.BatchConfigurationService;
import com.cricplay.pgi.services.CleverTapEventUploadService;
import com.cricplay.pgi.services.TransactionRefundService;
import com.cricplay.pgi.util.CommonUtil;
import com.paytm.pg.merchant.CheckSumServiceHelper;

/**
 * PGRefundService is responsible to refund.
 * 
 * @author infinity labs
 *
 */
@Transactional
@Service
public class PGRefundService extends BatchService {

	private static final Logger logger = Logger.getLogger(PGRefundService.class);
	
	@Autowired
	private BatchConfigurationService batchConfigurationService;
	
	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private OrderDao orderDao;

	@Autowired
	private TransactionRefundService transactionRefundService;

	@Autowired
	private AppProperties appProperties;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private BatchTransactionRepository batchTransactionRepository;
	
	@Autowired
	private CleverTapEventUploadService cleverTapEventUploadService;
	
	@Autowired
	private CleverTapPayloadBuilder cleverTapPayloadBuilder;
	
	@Autowired
	private CommonUtil commonUtil;

/**
 * Trigger batch process for PGRefundService
 */
	@Override
	public void process() {
		BatchJobEntity batchJobEntity=null;

		try {
			//Step 1 : Get BatchConfigurationEntity object
			BatchConfigurationEntity batchConfigurationEntity = batchConfigurationService.findBatchConfigurationByType(AppConstant.JOB_TYPE.PGREFUND.getJobType());
			
			logger.info("\n Batch Configruation enity list data " + batchConfigurationEntity);
			//Step 2 : Trigger process if the current status is not in "Running"
			if (!RUNNING_STATUS.equalsIgnoreCase(batchConfigurationEntity.getCurrentStatus())) {

				batchJobEntity = batchConfigDataInitialize(RUNNING_STATUS, batchConfigurationEntity);
				
				
				//Step 5 : Get list of records from TransactionRefund table
				Set<TransactionRefundEntity> transactionRefundStatusList = transactionRefundService.findTransactionRefundByRefundStatus(INITIATED_STATUS,PG_BATCH_TRANSACTION_STATUS);

				//Step 6 : Start process each transaction from batch against records get from TransactionRefund table
				for (TransactionRefundEntity transactionRefundEntity : transactionRefundStatusList) {
					
					logger.info("\n Transaction Refund Entity :" + transactionRefundEntity);
					
					TransactionEntity transactionEntity = transactionDao.findTransByOrderIdAndPaymentType(transactionRefundEntity.getOrderId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());

					// batch transaction table : insert new record
					BatchTransactionEntity batchTransactionEntity= new BatchTransactionEntity();
					batchTransactionEntity.setCretedOn(new Date());
					batchTransactionEntity.setOrderId(Double.valueOf(transactionRefundEntity.getOrderId()));
					batchTransactionEntity.setTransactionId(transactionEntity.getTransId());
					batchTransactionEntity.setTransactionType(transactionRefundEntity.getTranscationType());
					batchTransactionEntity.setBatchJobId(Double.valueOf(batchJobEntity.getId()));
					batchTransactionRepository.save(batchTransactionEntity);
					
					Integer orderId = transactionRefundEntity.getOrderId();
					OrderEntity orderEntity=orderDao.findOrderById(orderId);
					
					//Step 7 : Generate new check sum 
					TreeMap<String, String> requestParams = buildPayloadPayTm(transactionRefundEntity,transactionEntity);

					//Step 8: Call 3rd party api to get refund request
					HttpEntity<String> payload = new HttpEntity<String>(new JSONObject(requestParams).toString());
					logger.info("REST API payload payTM :"+payload);
					ResponseEntity<String> responseRefund=null;
					if(AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {
						
						responseRefund = restTemplate.exchange(appProperties.getInternalRefundUrl(),HttpMethod.POST, payload, String.class);
					}
					else if(AppConstant.PG_VENDOR.SHAREIT.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {
						HttpHeaders headers = new HttpHeaders();
						headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
						
						ResponseEntity<String> responseToken=commonUtil.getShareitToken();
						
						JSONObject responseData = new JSONObject();
						responseData = new JSONObject(responseToken.getBody());
						
						headers.set("token", responseData.get("data").toString());
						
						MultiValueMap<String, String> reqParam=buildPayloadShareIt(transactionRefundEntity,transactionEntity);
						HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(reqParam, headers);
						logger.info("REST API payload shareIt :"+request);
						responseRefund = restTemplate.postForEntity(appProperties.getCricPlayShareItApiUrl(), request, String.class);
					}
					 
					JSONObject responseRefundBody = new JSONObject(responseRefund.getBody());
					
					logger.info("Response : "+responseRefundBody);

					// Step 9: REST Api returns Status then update record in TransactionRefund table
					if (responseRefundBody!=null) {

						PgRefundResponse pgRefundResponse=prepareResponse(responseRefundBody,transactionEntity);
						if(StringUtils.isNotEmpty(pgRefundResponse.getTransStatus())) {
						// update transaction refund table with status as Success
				
						transactionRefundEntity.setRefundStatus(pgRefundResponse.getTransStatus().toLowerCase());
						
						if(pgRefundResponse.getTransStatus().equals("TXN_SUCCESS")) {
							// trigger clever tap
							
							CleverTapEvtDataRequest evtDataRequest= new CleverTapEvtDataRequest();
							evtDataRequest.setStatus("REFUND_PG");
							evtDataRequest.setAmount(orderEntity.getPrice());
							evtDataRequest.setDesc(orderEntity.getCoins()+"coins");
							evtDataRequest.setPlanId(orderEntity.getPlanId());
							evtDataRequest.setPgAmount(Double.parseDouble(transactionRefundEntity.getRefundAmount()));
							evtDataRequest.setWinAmount(orderEntity.getPrice()-Double.parseDouble(transactionRefundEntity.getRefundAmount()));
							CleverTap evtData=cleverTapPayloadBuilder.buildCleverTapPayload(evtDataRequest, CommonUtil.generateRequestId(orderId));
							ResponseEntity<CleverTapUploadResponse> res=null;
							try {
								res=cleverTapEventUploadService.cleverTapUploadEvent(evtData);
								logger.debug("clever tap event trigger response ::"+res.getStatusCodeValue());
							}catch(Exception e) {
								logger.debug("Error while trigger clevertap");
								logger.debug("Exception Clevertap:::"+e.getCause());
							}
							// end clever tap
							
							// get RefundId
							String pgRefundId = pgRefundResponse.getRefundId();
							transactionRefundEntity.setRefundId(pgRefundId);
							transactionRefundEntity.setBankTxnId(pgRefundResponse.getTxnId());
							transactionRefundEntity.setPaymentMode(pgRefundResponse.getPaymentMode());
							transactionRefundEntity.setRespMsg(pgRefundResponse.getMessage());
							transactionRefundEntity.setRefundDate(pgRefundResponse.getRefundDate());
							transactionRefundEntity.setPgRefundTransId(pgRefundResponse.getRefundReceipt());
							//refundStatusObj.setRefundDate(responseRefundBody.get("REFUNDDATE"));todo: Need to convert string to Date object
							
						}
						
						if(pgRefundResponse.getTransStatus().equals("TXN_FAILURE")) {
							transactionRefundEntity.setRefundStatus("Failure");
							transactionRefundEntity.setComment("RESPMSG : "+pgRefundResponse.getMessage() +" , RESPCODE"+ pgRefundResponse.getRespCode());
							transactionRefundEntity.setRefundDate(new Date());
							transactionRefundEntity.setRespMsg(pgRefundResponse.getMessage());
						}
						
						if (pgRefundResponse.getTransStatus().equals("PENDING")) {

							//Step 9 : if 3rd Party API not returns TXN_SUCCESS
							
							// Updating transaction refund table with pending
							String pgRefundId = pgRefundResponse.getRefundId();
							transactionRefundEntity.setRefundId(pgRefundId);
							transactionRefundEntity.setPgRefundTransId(pgRefundResponse.getRefundReceipt());
							transactionRefundEntity.setRefundStatus("Pending");
							transactionRefundEntity.setComment("RESPMSG : "+pgRefundResponse.getMessage() +" , RESPCODE"+ pgRefundResponse.getRespCode());
							transactionRefundEntity.setRefundDate(new Date());

							transactionRefundEntity.setBankTxnId(pgRefundResponse.getTxnId());
							transactionRefundEntity.setPaymentMode(pgRefundResponse.getPaymentMode());

							transactionRefundEntity.setRespMsg(pgRefundResponse.getMessage());

						}
						
						transactionRefundEntity.setTransId(transactionEntity.getTransId());
						transactionDao.saveTransactionRefund(transactionRefundEntity);

						// Step 10 : Update transaction status into Transaction table
						
						

						if (!pgRefundResponse.getTransStatus().equals("PENDING")) {
							if(pgRefundResponse.getTransStatus().equals("TXN_SUCCESS")) {
								transactionEntity.setTransStatus(AppConstant.PG_TXN_STATUS.PG_SUCCESS.getValue());	
							}
							
							if(pgRefundResponse.getTransStatus().equals("TXN_FAILURE")) {
								transactionEntity.setTransStatus("TXN_REFUND_FAILURE");	
							}
							
							updateTransaction(transactionEntity);
							
						}
						

						// Step 11 : insert record into TransactionRefundHistory table.
						String transactionRefId=transactionRefundEntity.getTransactionRefId();
						// if transaction fail then pg_trans_ref_id is null into refund history table
						/*if(responseRefundBody.get("STATUS").equals("TXN_FAILURE")) {
							//txnId =null; TODO: need to change field as nullable
						}*/
						
						insertRecordTransactionRefundHistory(transactionRefundEntity, transactionRefId);
						
						// Step 12 : Update  PG_Order
						List<TransactionEntity> transList = transactionDao.findTransByOrderId(orderId);
						
						if(transList!=null && transList.isEmpty()) {
							for(TransactionEntity transactionEntityTemp : transList) {
								
								if(AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue().equals(transactionEntityTemp.getPaymentType())) {
									if(transactionEntityTemp.getTransStatus().equals(AppConstant.ORDER_STATUS.REFUND_REQUESTED.getValue())) {
										// order status success
										orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.REFUNDED.getValue(), new Date(),orderId);
									}
								}
								
							}
						}
						

						/*if (!transList.stream().filter(trans -> AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue().equals(trans.getTxnType()))
								.collect(Collectors.toList()).isEmpty()
								&& transList.stream()
										.filter(trans -> AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue().equals(trans.getTxnType()))
										.collect(Collectors.toList()).get(0).getTransStatus()
										.equalsIgnoreCase(AppConstant.TXN_STATUS.SUCCESS.getValue())) {

							// order status success
							orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.REFUND_REQUESTED.getValue(), new Date(),orderId);

						}*/

					}

				}
				}
				if(batchJobEntity!=null) {
					batchConfigStatusUpdate(batchJobEntity, transactionRefundStatusList.size(), batchConfigurationEntity);
				}
				

			} else {

				logger.info("Winning Batch process could not start, Because process is running mode");
			}

		} catch (Exception e) {
			logger.error("Exception occured while creating order::" + e.getMessage());
			e.printStackTrace();

		}
	}
	
	/**
	 * Build Payload for paytm rest api call
	 * @param refundStatusObj
	 * @param transactionEntity
	 * @return TreeMap<String, String>
	 */
	//@Override
	public TreeMap<String, String> buildPayloadPayTm(TransactionRefundEntity refundStatusObj, TransactionEntity transactionEntity) {
		Map<String,String> mechantInfoMap= appProperties.getMechantInfo(transactionEntity.getPgVendor());
		String merchantMid = mechantInfoMap.get("merchantId");
		Integer orderId = refundStatusObj.getOrderId();
		String merchantKey = mechantInfoMap.get("merchantKey");

		String transactionType = "REFUND";
		String refundAmount = refundStatusObj.getRefundAmount();
		String transactionId = refundStatusObj.getTransactionRefId();
		//String transactionId = String.valueOf(refundStatusObj.getId());
		
		String refId = String.valueOf(refundStatusObj.getId());

		TreeMap<String, String> requestParams = new TreeMap<String, String>();
		if(AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {
			requestParams.put("MID", merchantMid);
			requestParams.put("REFID", refId);
			requestParams.put("TXNID", transactionId);
			requestParams.put("ORDERID", orderId.toString());
			requestParams.put("REFUNDAMOUNT", refundAmount);
			requestParams.put("TXNTYPE", transactionType);
			try {
				requestParams.put("CHECKSUM", CheckSumServiceHelper.getCheckSumServiceHelper().genrateRefundCheckSum(merchantKey, requestParams));
			} catch (Exception ex) {
				logger.info("OrderId :" + orderId);
				logger.info("Internal TransactionId :" + transactionId);
				logger.info("Internal TransactionRefundId :" + refId);
				logger.info("Error Message " + ex.getMessage());
				ex.printStackTrace();
			}
		}

		return requestParams;
	}
	
	/**
	 * Build Payload for shareit refundApply rest api call
	 * @param refundStatusObj
	 * @param transactionEntity
	 * @return
	 */
	public MultiValueMap<String, String> buildPayloadShareIt(TransactionRefundEntity refundStatusObj, TransactionEntity transactionEntity){
		
		Map<String,String> mechantInfoMap= appProperties.getMechantInfo(transactionEntity.getPgVendor());
		String merchantMid = mechantInfoMap.get("merchantId");
		Integer orderId = refundStatusObj.getOrderId();
		SimpleDateFormat formatter= new SimpleDateFormat("yyyyMMddhhmmss");
		StringBuilder builder=new StringBuilder();
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();

		map.add("merchantId", merchantMid);
		map.add("bizType", "refundApply");
		map.add("timestamp", String.valueOf(Instant.now().getEpochSecond()));
		map.add("orderId", orderId.toString());
		map.add("version", appProperties.getShareItApiVersion());
		map.add("callbackUrl",appProperties.getShareItRefundApplyCallbackUrl());
		map.add("comments","refund from shareit");
		 
		map.add("refundId", String.valueOf(builder.append(formatter.format(new Date())).append(refundStatusObj.getId())));
		map.add("tradeNo", transactionEntity.getPgTxnId());
		map.add("amount", refundStatusObj.getRefundAmount());
		return map;
		
	}

	/**
	 * parsing response JSON Object to custom response object
	 * @param responseRefundBody
	 * @param transactionEntity
	 * @return	PgRefundResponse
	 */
	public PgRefundResponse prepareResponse(JSONObject responseRefundBody, TransactionEntity transactionEntity) {

		PgRefundResponse pgRefundResponse=new PgRefundResponse();

		if(AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {
			if(responseRefundBody.has("STATUS")) {
			pgRefundResponse.setTransStatus(responseRefundBody.get("STATUS").toString());
			}
			if(responseRefundBody.has("REFUNDID")) {
			pgRefundResponse.setRefundId(responseRefundBody.get("REFUNDID").toString());
			}
			if(responseRefundBody.has("RESPCODE")) {
			pgRefundResponse.setRespCode(responseRefundBody.get("RESPCODE").toString());
			}
			if(responseRefundBody.has("RESPMSG")) {
			pgRefundResponse.setMessage(responseRefundBody.get("RESPMSG").toString());
			}
			if(responseRefundBody.has("REFUNDDATE")) {
				try {
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss.0");
					pgRefundResponse.setRefundDate(formatter.parse(responseRefundBody.get("REFUNDDATE").toString()));
				} catch (Exception e) {
					logger.debug("Error while parsing REFUNDDATE");
				}
			}
			pgRefundResponse.setRefundDate(transactionEntity.getCreated_on());	
			
			pgRefundResponse.setPaymentMode(responseRefundBody.has("PAYMENTMODE")?responseRefundBody.get("PAYMENTMODE").toString():"");
			pgRefundResponse.setTxnId(responseRefundBody.has("BANKTXNID")?responseRefundBody.get("BANKTXNID").toString():"");
		}

		if(AppConstant.PG_VENDOR.SHAREIT.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {

			if(responseRefundBody.has("data")) {
				JSONObject refundDataJson=responseRefundBody.getJSONObject("data");
				if(responseRefundBody.has("bizCode")) {
					String bizCode=responseRefundBody.get("bizCode").toString();
					pgRefundResponse.setTransStatus(bizCode.equals("0000")?AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[0]:AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[2]);
				}
				
				if(refundDataJson.has("refundId")) {
				pgRefundResponse.setRefundId(refundDataJson.getString("refundId"));
				}
				pgRefundResponse.setRespCode("");
				if(refundDataJson.has("errorMsg")) {
				pgRefundResponse.setMessage(refundDataJson.getString("errorMsg"));
				}
				pgRefundResponse.setPaymentMode("");
				pgRefundResponse.setTxnId("");
				if(refundDataJson.has("refundReceipt")) {
				pgRefundResponse.setRefundReceipt(refundDataJson.get("refundReceipt").toString());
				}
			}
			

		}

		return pgRefundResponse;
	}

}

class PgRefundResponse{

	private String transStatus;
	private String respCode;
	private String txnId;
	private String paymentMode;
	private String refundId;
	private String message;
	private Date refundDate;
	private String refundReceipt;

	public String getTransStatus() {
		return transStatus;
	}

	public String getRefundId() {
		return refundId;
	}

	public void setRefundId(String refundId) {
		this.refundId = refundId;
	}

	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getRefundDate() {
		return refundDate;
	}

	public void setRefundDate(Date refundDate) {
		this.refundDate = refundDate;
	}

	public String getRefundReceipt() {
		return refundReceipt;
	}

	public void setRefundReceipt(String refundReceipt) {
		this.refundReceipt = refundReceipt;
	}
	
}

