package com.cricplay.pgi.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.services.GetOrderService;

@CrossOrigin
@RestController
@RequestMapping(value = "/cricplay/api/v1")
public class OrderStatusController {
//	@Autowired
//	CreateOrderService createOrderService;
//	@Autowired
//	OrderRepository orderRepository;
//	public static final Logger LOGGER = Logger.getLogger(OrderStatusController.class);
//	@RequestMapping(value="/orderStatus",method =RequestMethod.GET, headers = "Accept=application/json")
//	public @ResponseBody Optional<OrderEntity> getStatusOrder(@RequestParam(value="status")String status) throws Exception{
//		LOGGER.info("coin query param..." + status);
//		//return createOrderService.findOrderByStatus(status);
//		return orderRepository.findById(72);
//	}
	@Autowired
	GetOrderService getOrderService;

	public static final Logger LOGGER = Logger.getLogger(OrderStatusController.class);

	@RequestMapping(value = "/orderStatus", method = RequestMethod.GET, headers = "Accept=application/json")
	public @ResponseBody OrderEntity getOrderByStatus(@RequestParam(value = "status") String status) {
		LOGGER.info("getOrderByStatus start OrderStatusController.... " + status);
		return getOrderService.findOrderByStatus(status);
	}

	@RequestMapping(value = "/orderid", method = RequestMethod.GET, headers = "Accept=application/json")
	public @ResponseBody OrderEntity getOrderByID(@RequestParam(value = "id") Integer orderid) {
		LOGGER.info("getOrderByStatus start OrderStatusController.... " + orderid);
		return getOrderService.findOrderById(orderid);
	}
	
	
	
	
}
