package com.cricplay.pgi.sms;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.model.SmsRequest;

@Service
public class CricPlaySmsServiceImpl implements ICricPlaySmsService{
	
	public static final Logger LOGGER = Logger.getLogger(CricPlaySmsServiceImpl.class);
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	AppProperties appProperties;

	@Override
	public String pushSms(SmsRequest smsRequest) {
		LOGGER.info("pushSms service start...");
		
		JSONObject obj = new JSONObject(smsRequest);
		String strJson = obj.toString();
		LOGGER.debug("\n Payload for pushSms ::"+strJson);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> request = new HttpEntity<String>(strJson, headers);
		ResponseEntity<String> response=restTemplate.postForEntity(appProperties.getCricPlaySmsUrl(), request, String.class);
		LOGGER.info("\n Response from pushSms service ::"+response.getStatusCodeValue());
		LOGGER.info("pushSms service end...");
		return response.getBody().toString();
	}

}
