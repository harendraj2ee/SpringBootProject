package com.cricplay.pgi.model;

import java.io.Serializable;
import java.util.Date;

public class PGTransaction implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String status;
	String pgTxnId;
	String bankTxnId;
	String txnType;
	String gatewayName;
	String respCode;
	String respMsg;
	String bankName;
	String paymentMode;
	String refundAmount;
	String txnDate;
	
	
	
	public PGTransaction() {
		super();
	}
	
	
	public PGTransaction(String status, String pgTxnId, String bankTxnId, String txnType, String gatewayName,
			String respCode, String respMsg, String bankName, String paymentMode, String refundAmount, String txnDate) {
		super();
		this.status = status;
		this.pgTxnId = pgTxnId;
		this.bankTxnId = bankTxnId;
		this.txnType = txnType;
		this.gatewayName = gatewayName;
		this.respCode = respCode;
		this.respMsg = respMsg;
		this.bankName = bankName;
		this.paymentMode = paymentMode;
		this.refundAmount = refundAmount;
		this.txnDate = txnDate;
	}


	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getPgTxnId() {
		return pgTxnId;
	}
	public void setPgTxnId(String pgTxnId) {
		this.pgTxnId = pgTxnId;
	}
	
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public String getGatewayName() {
		return gatewayName;
	}
	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}
	public String getRespCode() {
		return respCode;
	}
	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}
	public String getRespMsg() {
		return respMsg;
	}
	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getRefundAmount() {
		return refundAmount;
	}
	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}
	public String getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}
	@Override
	public String toString() {
		return "PGTransaction [status=" + status + ", pgTxnId=" + pgTxnId + ", bankId=" + bankTxnId + ", txnType="
				+ txnType + ", gatewayName=" + gatewayName + ", respCode=" + respCode + ", respMsg=" + respMsg
				+ ", bankName=" + bankName + ", paymentMode=" + paymentMode + ", refundAmount=" + refundAmount
				+ ", txnDate=" + txnDate + "]";
	}


	public String getBankTxnId() {
		return bankTxnId;
	}


	public void setBankTxnId(String bankTxnId) {
		this.bankTxnId = bankTxnId;
	}

}
