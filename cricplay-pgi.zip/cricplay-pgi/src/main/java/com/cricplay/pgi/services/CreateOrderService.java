package com.cricplay.pgi.services;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.OrderStatusEntity;
import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.model.Checksum;
import com.cricplay.pgi.model.CoinCreditResponse;
import com.cricplay.pgi.model.DebitResponse;
import com.cricplay.pgi.model.Order;
import com.cricplay.pgi.model.OrderModel;
import com.cricplay.pgi.model.OrderResponse;
import com.cricplay.pgi.model.VerifyUserResponse;

public interface CreateOrderService {

	public Checksum buildChecksum(Order order,OrderEntity orderEntity,String userUniqueId, String txnAmount) throws Exception;
	
	public OrderResponse createOrder(Order order, String authToken,String language) throws Exception;
	
	public Double getWinningBalance(String userUniqueId) throws Exception;
	
	public ResponseEntity<DebitResponse> debitCreditUserWinning(String userId, PlanEntity planEntity, OrderEntity orderEntity,String eventType,Double winningBalance) throws Exception;
	
	public ResponseEntity<CoinCreditResponse> creditCoin(String userId, PlanEntity planEntity, OrderEntity orderEntity, String eventType) throws Exception;
	
	public  ResponseEntity<VerifyUserResponse> verifyUser(String authorizationToken) throws Exception;
	
	//public OrderEntity findOrderByStatus(String status)throws Exception; 
	public OrderEntity findOrderById(Integer id) throws Exception;
	
	public List<OrderStatusEntity> findOrderListByStatus(String Status) throws Exception;
}
