package com.cricplay.pgi.services;


import java.util.List;

import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.model.OrderModel;

public interface OrderSummaryService {
	
	public OrderModel getOrderSummary(Integer orderId,String userId) throws Exception;
	
	public OrderEntity getOrderById(Integer orderId) throws Exception;
	
	public List<OrderEntity> findOrderByStatus(String status);

}
