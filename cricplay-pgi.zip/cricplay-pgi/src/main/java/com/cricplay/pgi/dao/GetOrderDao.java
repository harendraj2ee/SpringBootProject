package com.cricplay.pgi.dao;

import com.cricplay.pgi.data.entity.OrderEntity;

public interface GetOrderDao {
	public OrderEntity findOrderByStatus(String status);
	public OrderEntity findOrderById(Integer orderid);
	
}
