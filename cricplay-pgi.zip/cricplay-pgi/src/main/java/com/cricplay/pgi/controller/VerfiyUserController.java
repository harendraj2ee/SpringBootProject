package com.cricplay.pgi.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping(value="/verify")
public class VerfiyUserController {
	
	
	@RequestMapping(value="/verifyUser",method =RequestMethod.GET, headers = "Accept=application/json")
    public String verifyUser(HttpServletRequest request) {
		String token=request.getHeader("Authorization");
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", token);
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        System.out.println("request >> "+request);
        RestTemplate restTemplate = new RestTemplate();
        String url="https://qaapi.cricplay.com/cric-auth/userdetails/verify";
        ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
        System.out.println("response >> "+response);
        return response.toString();
        
    }
	

}
