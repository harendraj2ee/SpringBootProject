package com.cricplay.pgi.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.data.entity.OrderStatusEntity;
import com.cricplay.pgi.data.repository.OrderStatusRepository;
import com.cricplay.pgi.model.Checksum;

//@CrossOrigin
@RestController
@RequestMapping(value = "/cricplay/api/v1")
public class OrderStatusControllers {

	public static final Logger LOGGER = Logger.getLogger(Checksum.class);

	@Autowired
	AppProperties appProperties;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	OrderStatusRepository orderStatusRepository;

	@RequestMapping(value = "/getOrderByStatus", method = RequestMethod.GET)
	public String getOrderByStatus(@RequestParam(value = "status") String status) {

		OrderStatusEntity objectEntity = new OrderStatusEntity();

		String batchType = "CoinCredit";
		Object configBatchType = orderStatusRepository.findByBatchType(batchType);
		System.out.println("configBatchType" + configBatchType);

		Integer batchCount = 0;

		List<OrderStatusEntity> orderListByStatus = new ArrayList<OrderStatusEntity>(
				orderStatusRepository.findOrderListByStatus(status));

		for (OrderStatusEntity orderModelEntity : orderListByStatus) {
			System.out.println("lsit data show" + orderModelEntity);
			// STAFF
			// service call for getting data credit coin is true or false
		}

		// MOCK CONDITION FOR EXTERNAL API
		JSONObject creditCoin = new JSONObject();
		creditCoin.put("creditCoin", true);

		JSONObject creditBetchStatus = new JSONObject();
		creditBetchStatus.put("status", "success");

		Integer orderId = 27;

//		System.out.println("creditCoin data show" + creditCoin);
		if (creditCoin.get("creditCoin").equals("true")) {

			System.out.println("creditCoin true" + creditCoin);
			// condition for job result success or faliure
			System.out.println("\n creditBetchStatus true " + creditBetchStatus.get("status"));
			if (creditBetchStatus.get("status").equals("success")) {

//				batchCount++;
				OrderStatusEntity batchJobUpdate = orderStatusRepository.findOrderById(batchCount, orderId);
				System.out.println("batchJobUpdate" + batchJobUpdate);

			}
		} else {
			System.out.println("creditCoin false" + creditCoin);
			// condition for job result success or faliure

			if (creditBetchStatus.get("status").equals("success")) {
				batchCount = batchCount + 1;
				System.out.println("batchSize + orderId - " + batchCount + orderId);
				OrderStatusEntity batchJobUpdate = orderStatusRepository.findOrderById(batchCount, orderId);
				System.out.println("orderId" + batchJobUpdate);
			}
		}

		return null;

	}

}
