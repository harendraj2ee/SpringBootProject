package com.cricplay.pgi.Jobs;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.BatchTransactionEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.repository.BatchTransactionRepository;
import com.cricplay.pgi.data.repository.TransactionRefundRepository;
import com.cricplay.pgi.services.BatchConfigurationService;
import com.cricplay.pgi.services.TransactionRefundService;
import com.cricplay.pgi.util.CommonUtil;
import com.paytm.pg.merchant.CheckSumServiceHelper;

/**
 * 
 * @author infinity labs
 *
 */
@Transactional
@Service
public class PGRefundStatusCheckService extends BatchService {

	private static final Logger logger = Logger.getLogger(PGRefundStatusCheckService.class);

	@Value("${cricplay.pgi.pgrefundstatuscheck.batch.rerty.threshold}")
	private Integer retryThreshold;

	@Autowired
	private BatchConfigurationService batchConfigurationService;

	@Autowired
	private TransactionRefundService transactionRefundService;

	@Autowired
	private AppProperties appProperties;

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private TransactionRefundRepository transactionRefundRepository;

	@Autowired
	private BatchTransactionRepository batchTransactionRepository;
	
	@Autowired
	private CommonUtil commonUtil;

	@Override
	public void process() {

		BatchJobEntity batchJobEntity = null;

		try {
			// Step 1 : Get BatchConfigurationEntity object
			BatchConfigurationEntity batchConfigurationEntity = batchConfigurationService
					.findBatchConfigurationByType(AppConstant.JOB_TYPE.PGREFUNDSTATUSCHECK.getJobType());

			logger.info("\n Batch Configruation enity list data " + batchConfigurationEntity);
			// Step 2 : Trigger process if the current status is not in "Running"
			if (!RUNNING_STATUS.equalsIgnoreCase(batchConfigurationEntity.getCurrentStatus())) {

				// Step 5 : Get list of records from TransactionRefund table
				Set<TransactionRefundEntity> transactionRefundStatusList = transactionRefundService
						.findTransactionRefundByRefundStatus(PENDING_STATUS, PG_BATCH_TRANSACTION_STATUS);

				// Step 6 : Start process each transaction from batch against records get from
				// TransactionRefund table
				if (transactionRefundStatusList.size() > 0) {
					batchJobEntity = batchConfigDataInitialize(RUNNING_STATUS, batchConfigurationEntity);

					for (TransactionRefundEntity transactionRefundEntity : transactionRefundStatusList) {

						logger.info("\n Transaction Refund Entity :" + transactionRefundEntity);

						TransactionEntity transactionEntity = transactionDao.findTransByOrderIdAndPaymentType(
								transactionRefundEntity.getOrderId(),
								AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());

						try {
							// batch transaction table : insert new record
							BatchTransactionEntity batchTransactionEntity = new BatchTransactionEntity();
							batchTransactionEntity.setCretedOn(new Date());
							batchTransactionEntity
									.setOrderId(Double.valueOf(transactionEntity.getOrder().getOrderId()));
							batchTransactionEntity.setTransactionId(transactionEntity.getTransId());
							batchTransactionEntity.setTransactionType(transactionEntity.getPaymentType());
							batchTransactionEntity.setBatchJobId(Double.valueOf(batchJobEntity.getId()));
							batchTransactionRepository.save(batchTransactionEntity);
							// end batch transaction table : insert

							callRestApi(transactionRefundEntity, transactionEntity);
						} catch (Exception e) {
							logger.debug("PG Refund Status Check Service exception message:::" + e.getMessage());
						}

					}

					if (batchJobEntity != null) {
						batchConfigStatusUpdate(batchJobEntity, transactionRefundStatusList.size(),
								batchConfigurationEntity);
					} else {
						logger.debug("batchJobEntity null...");
					}
				}
			}

			else {

				logger.info("pg status check Batch process could not start, Because process is running mode");
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

	private void callRestApi(TransactionRefundEntity transactionRefundEntity, TransactionEntity transactionEntity)
			throws JSONException, Exception {

		ResponseEntity<String> responseRefund = null;

		if (AppConstant.PG_VENDOR.SHAREIT.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

			ResponseEntity<String> responseToken=commonUtil.getShareitToken();
			
			JSONObject responseData = new JSONObject();
			responseData = new JSONObject(responseToken.getBody());
			
			headers.set("token", responseData.get("data").toString());

			MultiValueMap<String, String> reqParam = buildPayloadShareIt(transactionRefundEntity, transactionEntity);

			HttpEntity<MultiValueMap<String, String>> payload = new HttpEntity<MultiValueMap<String, String>>(reqParam,
					headers);
			logger.info("REST API payload shareIt :" + payload);
			responseRefund = restTemplate.postForEntity(appProperties.getCricPlayShareItApiUrl(), payload,
					String.class);

		} else if (AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {

			TreeMap<String, String> paytmParams = buildPayloadPayTm(transactionRefundEntity, transactionEntity);
			HttpEntity<String> payload = new HttpEntity<String>(new JSONObject(paytmParams).toString());

			logger.info("Payload : " + payload);

			responseRefund = restTemplate.exchange(appProperties.getInternalRefundStatusUrl(), HttpMethod.POST, payload,
					String.class);
		}

		JSONObject responseRefundBody = new JSONObject(responseRefund.getBody());
		logger.info("Response  : " + responseRefundBody);
		// Get response from API
		handleResponse(responseRefundBody, transactionRefundEntity, transactionEntity);
	}

	public TreeMap<String, String> buildPayloadPayTm(TransactionRefundEntity refundStatusObj,
			TransactionEntity transactionEntity) {
		Map<String, String> merchantInfoMap = appProperties.getMechantInfo(transactionEntity.getPgVendor());
		String merchantId = merchantInfoMap.get("merchantId");
		Integer orderId = refundStatusObj.getOrderId();
		String merchantKey = merchantInfoMap.get("merchantKey");

		TreeMap<String, String> requestParams = new TreeMap<String, String>();
		if (AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {
			requestParams.put("MID", merchantId);
			requestParams.put("ORDERID", String.valueOf(orderId));
			requestParams.put("REFID", String.valueOf(refundStatusObj.getId()));
			try {
				requestParams.put("CHECKSUM",
						CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(merchantKey, requestParams));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return requestParams;
	}

	public MultiValueMap<String, String> buildPayloadShareIt(TransactionRefundEntity refundStatusObj,
			TransactionEntity transactionEntity) {
		StringBuilder builder=new StringBuilder();
		SimpleDateFormat formatter= new SimpleDateFormat("yyyyMMddhhmmss");
		Map<String, String> mechantInfoMap = appProperties.getMechantInfo(transactionEntity.getPgVendor());
		String merchantMid = mechantInfoMap.get("merchantId");
		Integer orderId = transactionEntity.getOrder().getOrderId();

		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();

		map.add("merchantId", merchantMid);
		map.add("bizType", "refundQry");
		map.add("timestamp", String.valueOf(Instant.now().getEpochSecond()));
		map.add("orderId", orderId.toString());
		map.add("version", appProperties.getShareItApiVersion());
		map.add("refundId", refundStatusObj.getRefundId());
		map.add("tradeNo", transactionEntity.getPgTxnId());
		return map;

	}


	public void handleResponse(JSONObject responseRefundBody, TransactionRefundEntity transactionRefundEntity,
			TransactionEntity transactionEntity) throws Exception {

		if (AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {
			if (responseRefundBody != null) {
				if (!responseRefundBody.has("REFUND_LIST")) {
					logger.debug("responseRefund ::" + responseRefundBody);
				} else {
					JSONArray lineItems = responseRefundBody.getJSONArray("REFUND_LIST");
					for (Object o : lineItems) {
						JSONObject jsonLineItem = (JSONObject) o;
						String status = jsonLineItem.getString("STATUS");

						if (status != null && (status.equals("TXN_SUCCESS") || status.equals("TXN_FAILURE"))) {

							// Update statue into pg_transaction table
							transactionRefundEntity.setRefundStatus(status);
							transactionRefundEntity.setRefundDate(new Date());
							transactionRefundRepository.save(transactionRefundEntity);

							insertRecordTransactionRefundHistory(transactionRefundEntity,
									transactionRefundEntity.getTransactionRefId());

						}

						if (status != null && status.equals("PENDING")) {

							if (retryThreshold >= transactionRefundEntity.getRetryCounter()) {

								// TODO : Set all the attritbutes from API
								transactionRefundEntity.setRetryCounter(transactionRefundEntity.getRetryCounter() + 1);
								if (jsonLineItem.get("RESPCODE").equals("10")) {
									transactionRefundEntity.setPaymentMode(jsonLineItem.getString("PAYMENTMODE"));
									transactionRefundEntity.setRefundId(jsonLineItem.getString("REFUNDID"));
									transactionRefundEntity.setRefundDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0")
											.parse(jsonLineItem.getString("REFUNDDATE")));

								} else if (jsonLineItem.get("RESPCODE").equals("601")
										|| jsonLineItem.get("RESPCODE").equals("604")) {
									transactionRefundEntity.setRefundId(jsonLineItem.getString("REFUNDID"));
									transactionRefundEntity.setRefundDate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0")
											.parse(jsonLineItem.getString("REFUNDDATE")));
								}
								transactionRefundEntity.setRespMsg(jsonLineItem.getString("RESPMSG"));
								transactionRefundEntity.setRefundStatus(status);
								transactionRefundRepository.save(transactionRefundEntity);
								insertRecordTransactionRefundHistory(transactionRefundEntity,
										transactionRefundEntity.getTransactionRefId());
							} else {
								transactionRefundEntity.setRefundStatus("Failure");
								transactionRefundEntity.setRefundDate(new Date());
								transactionRefundRepository.save(transactionRefundEntity);

								insertRecordTransactionRefundHistory(transactionRefundEntity,
										transactionRefundEntity.getTransactionRefId());
							}

						}

					}
				}

			}
		}

		if (AppConstant.PG_VENDOR.SHAREIT.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {

			if (responseRefundBody != null) {
				if(responseRefundBody.has("data")){
				JSONObject refundDataJson = responseRefundBody.getJSONObject("data");

				String status = AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[refundDataJson.getInt("status")];

				if (status != null && (status.equals("TXN_SUCCESS") || status.equals("TXN_FAILURE"))) {

					// Update statue into pg_transaction table
					transactionRefundEntity.setRefundStatus(status);
					transactionRefundEntity.setRefundDate(new Date());
					transactionRefundRepository.save(transactionRefundEntity);

					insertRecordTransactionRefundHistory(transactionRefundEntity,
							transactionRefundEntity.getTransactionRefId());

				}

				if (status != null && status.equals("PENDING")) {

					if (retryThreshold >= transactionRefundEntity.getRetryCounter()) {

						transactionRefundEntity.setRetryCounter(transactionRefundEntity.getRetryCounter() + 1);
						transactionRefundEntity.setRefundId(refundDataJson.getString("refundId"));
						transactionRefundEntity.setRespMsg(refundDataJson.getString("errorMsg"));
						transactionRefundEntity.setRefundStatus(status);
						transactionRefundRepository.save(transactionRefundEntity);
						insertRecordTransactionRefundHistory(transactionRefundEntity,
								transactionRefundEntity.getTransactionRefId());
					} else {
						transactionRefundEntity.setRefundStatus("Failure");
						transactionRefundEntity.setRefundDate(new Date());
						transactionRefundRepository.save(transactionRefundEntity);

						insertRecordTransactionRefundHistory(transactionRefundEntity,
								transactionRefundEntity.getTransactionRefId());
					}

				}
			}
			}
		}

	}

}
