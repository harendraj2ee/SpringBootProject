package com.cricplay.pgi.services;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.clevertap.model.CleverTap;
import com.cricplay.pgi.clevertap.model.CleverTapUploadResponse;
import com.cricplay.pgi.config.AppProperties;

@Service
public class CleverTapEventUploadServiceImpl implements CleverTapEventUploadService{
	
	@Autowired
	AppProperties appProperties;
	
	@Autowired
	RestTemplate restTemplate;
	
	public static final Logger LOGGER = Logger.getLogger(CleverTapEventUploadServiceImpl.class);

	
	@Override
	public ResponseEntity<CleverTapUploadResponse> cleverTapUploadEvent(CleverTap cleverTapObj) {
		
		LOGGER.debug("\n cleverTapUploadEvent start...");
		
		JSONObject obj = new JSONObject(cleverTapObj);
		String payloadJson = obj.toString();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("X-CleverTap-Account-Id", appProperties.getCleverTapAccountId());
		headers.set("X-CleverTap-Passcode", appProperties.getCleverTapPasscode());
		LOGGER.debug("\n Payload for cleverTapUploadEvent ::"+payloadJson);
		
		HttpEntity<String> request = new HttpEntity<String>(payloadJson, headers);
		ResponseEntity<CleverTapUploadResponse> response=restTemplate.postForEntity(appProperties.getCleverTapUploadUrl(), request, CleverTapUploadResponse.class);
		LOGGER.info("\n Response from winningDebit service ::"+response.getStatusCodeValue());
		
		return response;
	}

}
