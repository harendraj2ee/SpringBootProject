package com.cricplay.pgi.model;

import java.util.Date;

public class PGTxnUpdateResponse {
	
	Integer statusCode;
	Integer TransactionId;
	Integer orderId;
	String PGTransactionId;
	Date orderCreationDate;
	String message;
	String orderStatus;
	Date orderModidyDate;
	
	public Integer getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}
	public Integer getTransactionId() {
		return TransactionId;
	}
	public void setTransactionId(Integer transactionId) {
		TransactionId = transactionId;
	}
	public String getPGTransactionId() {
		return PGTransactionId;
	}
	public void setPGTransactionId(String pGTransactionId) {
		PGTransactionId = pGTransactionId;
	}
	public Date getOrderCreationDate() {
		return orderCreationDate;
	}
	public void setOrderCreationDate(Date orderCreationDate) {
		this.orderCreationDate = orderCreationDate;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public Date getOrderModidyDate() {
		return orderModidyDate;
	}
	public void setOrderModidyDate(Date orderModidyDate) {
		this.orderModidyDate = orderModidyDate;
	}
	
}
