package com.cricplay.pgi.model;

public class CurrencyStatusCheckResponse {
	
	String status;
	String transId;
	
	public CurrencyStatusCheckResponse() {
		super();
	}
	
	public CurrencyStatusCheckResponse(String status, String transId) {
		this.status = status;
		this.transId = transId;
	}
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}

	@Override
	public String toString() {
		return "CurrencyStatusCheckResponse [status=" + status + ", transId=" + transId + "]";
	}
	
}
