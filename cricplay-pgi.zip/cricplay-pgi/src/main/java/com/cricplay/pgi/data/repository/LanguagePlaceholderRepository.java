package com.cricplay.pgi.data.repository;

import com.cricplay.pgi.data.entity.LanguagePlaceholderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface LanguagePlaceholderRepository extends JpaRepository<LanguagePlaceholderEntity, Integer> {


    @Query(value = "SELECT le FROM LanguagePlaceholderEntity le where le.key=?1 and le.languageEntity.alias=?2 and le.messageType=?3")
    LanguagePlaceholderEntity getPlaceholderByEventLangType(String event,String lang,String type);

}
