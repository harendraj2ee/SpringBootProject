package com.cricplay.pgi.services;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.model.CoinCreditResponse;
import com.cricplay.pgi.model.DebitCreditRequest;

@Service
public class CoinCreditServiceImpl implements CoinCreditService{

	public static final Logger LOGGER = Logger.getLogger(CoinCreditServiceImpl.class);
	
	@Autowired
	AppProperties appProperties;
	
	@Autowired
	RestTemplate restTemplate;
	
	@Override
	public ResponseEntity<CoinCreditResponse> creditCoin(DebitCreditRequest request) throws Exception{
		
		LOGGER.info("credit coin service start...");
		ResponseEntity<CoinCreditResponse> response=null;
		JSONObject obj = new JSONObject(request);
		String strJson = obj.toString();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<String> entity = new HttpEntity<String>(strJson, headers);
		try {
			response=restTemplate.postForEntity(appProperties.getCoinCreditUrl(), entity, CoinCreditResponse.class);
		}catch(Exception e) {
			LOGGER.debug("Error while credit coin.");
			LOGGER.debug("Exception :::"+e.getCause());
		}
		if(response!=null && response.getStatusCodeValue()==200) {
			LOGGER.debug("credit coin service response ::"+response.toString());
			return response;
		}
		return response;
		
	}

}
