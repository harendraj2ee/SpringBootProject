package com.cricplay.pgi.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.OrderEntity;

@Repository
public interface GetOrderRepository extends JpaRepository<OrderEntity, Integer> {

	@Query(value = "SELECT * FROM pg_order where status=?", nativeQuery = true)
	OrderEntity findOrderByStatus(String status);
	
	@Query(value="SELECT * FROM pg_order where order_id=?", nativeQuery = true)
	OrderEntity findOrderById(Integer orderid);
	
}
