package com.cricplay.pgi.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.dao.BatchTransactionDao;
import com.cricplay.pgi.data.entity.BatchTransactionEntity;

@Service
public class BatchTransactionServiceImpl implements BatchTransactionService {
	
	@Autowired
	BatchTransactionDao batchTransactionDao;

	@Override
	public BatchTransactionEntity findBatchTransactionByBatchJobId(String batchJobId) throws Exception {
		return batchTransactionDao.findBatchTransactionByBatchJobId(batchJobId);
	}

}
