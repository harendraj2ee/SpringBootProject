package com.cricplay.pgi.controller;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import com.cricplay.pgi.model.*;
import com.cricplay.pgi.util.MessageSelector;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;
import com.cricplay.pgi.services.CreateOrderService;
import com.cricplay.pgi.services.OrderSummaryService;
import com.cricplay.pgi.services.PlanService;
import com.cricplay.pgi.services.TransactionEntityService;
import com.cricplay.pgi.services.VerifyUserService;
import com.cricplay.pgi.util.CommonUtil;


/**
 * @author infinity labs
 */
@CrossOrigin
@RestController
@RequestMapping(value="/cricplay/api/v1")
public class OrderController {
	
	public static final Logger LOGGER = Logger.getLogger(OrderController.class);

	@Value("${node}")
	private String node;
	
	@Autowired
	CreateOrderService createOrderService;
	
	@Autowired
	VerifyUserService verifyUserService;
	
	@Autowired
	OrderSummaryService orderSummaryService;
	
	@Autowired
	PlanService planService;
	
	@Autowired
	TransactionEntityService transactionEntityService;

	@Autowired
	private MessageSelector messageSelector;
	
	/**
	 * for PG txn amoutn
	 */
	
	Map <String,String> amountMap=new HashMap<String,String>();
	
	
	/**
	 * 
	 * @param order
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/createOrder",method =RequestMethod.POST, headers = "Accept=application/json")
	public OrderResponse createOrder(@RequestBody Order order, HttpServletRequest request) throws Exception {
		OrderResponse orderResponse=null;
		if(StringUtils.isNotBlank(node) && node.equalsIgnoreCase(AppConstant.NODE.APP.getValue())) {
			LOGGER.info("createOrder start..."+order.toString());
			try {
				String authToken = request.getHeader("Authorization");
				String language= request.getHeader("language");
				LOGGER.debug("Authorization Token ::"+authToken);
				orderResponse = createOrderService.createOrder(order, authToken,language);
			}catch(Exception e) {
				LOGGER.error("Exception occured while creating order::"+e.getMessage());
				throw new Exception(e);
			}
		}
		return orderResponse;
	}

	/**
	 * 
	 * @param pgorderId
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/order", method = RequestMethod.GET, headers = "Accept=application/json")
	public OrderModel getOrderSummary(@RequestParam(value = "orderId") String pgorderId, HttpServletRequest request)
			throws Exception {
		LOGGER.info("get order summary start...");
		OrderModel response= new OrderModel();

		String userId = request.getHeader("userId");
		String language = request.getHeader("language");

		if (StringUtils.isEmpty(userId)) {
			response.setMessage("UserId can't be empty");
			return response;
		}

		String authorizationToken = request.getHeader("Authorization");

		if (StringUtils.isEmpty(authorizationToken)) {
			response.setMessage("Authorization Token can't be empty.");
			return response;
		}

		ResponseEntity<VerifyUserResponse> verifyUserResponse = verifyUserService.verifyUser(authorizationToken);

		if (verifyUserResponse != null && verifyUserResponse.getStatusCodeValue() == 200) {
			
			Integer orderId=Integer.parseInt(StringUtils.remove(pgorderId, "PG"));
			
			OrderEntity order= orderSummaryService.getOrderById(orderId);
			
			PlanEntity plan=planService.getPlanById(order.getPlanId());
			
			List<TransactionEntitySinglton> transactionList=transactionEntityService.findTransactionByOrderId(orderId);
			
			response.setOrderId(CommonUtil.appendOrderPrefix(orderId));
			
			if(plan!=null) {
				response.setPlanId(plan.getPlanId());
				response.setPlanName(plan.getPlanName());
			}
			
			Date dateCeatedOn=order.getCreatedOn();
			Date dateModifiedOn=order.getModifiedOn();

			Format formatter = new SimpleDateFormat("dd MMM, yyyy HH:mm:ss");
			String dateCreated = formatter.format(dateCeatedOn);
			String dateModified =formatter.format(dateModifiedOn);
			if(order.getStatus().equalsIgnoreCase(AppConstant.ORDER_STATUS.REFUNDED.getValue())) {
				response.setOrderStatus(AppConstant.ORDER_STATUS.REFUND_INITIATED.getValue());
			}else if(order.getStatus().equalsIgnoreCase(AppConstant.ORDER_STATUS.COIN_CREDIT_PENDING.getValue())){
				response.setOrderStatus(AppConstant.ORDER_STATUS.INITIATED.getValue());
			}
			else {
				response.setOrderStatus(order.getStatus());
			}
			response.setCreatedOn(dateCreated);
			response.setModifiedOn(dateModified);
			response.setAmountPaid(order.getPrice());
			if(order.getCoins()!=null) {
				response.setCoins(order.getCoins().intValue());
			}


			String pgStatus="01";
			String winningStatus="SUCCESS";

			if(order.getOrderType().equals(AppConstant.ORDER_TYPE.PG_ONLY.getValue())){
				winningStatus="NA";
			}

			for(TransactionEntitySinglton transaction: transactionList) {
				
				if(transaction.getPaymentType().equalsIgnoreCase(AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue())) {
					amountMap.put("amount", transaction.getAmount().toString());
					response.setWinningBalanceUsed(transaction.getAmount());
					winningStatus=transaction.getTransStatus().toUpperCase();
					
				}
				
				else if(transaction.getPaymentType().equalsIgnoreCase(AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue())) {
					amountMap.put("amount", transaction.getAmount().toString());
					response.setAmountPaidByPG(transaction.getAmount());
					if(!transaction.getPgVendor().equalsIgnoreCase("shareit")) {
					pgStatus=(StringUtils.isEmpty(transaction.getRespCode())?"TXN_FAILURE":transaction.getRespCode());
					}else {
						if(transaction.getTransStatus().equalsIgnoreCase("TXN_FAILURE")||transaction.getTransStatus().equalsIgnoreCase("initiated")) {
							pgStatus="334";
						}
						else {
							pgStatus="01";
						}
					}
				}
				
			}
			
			response.setMessage(prepareResponseMessage(pgStatus,winningStatus,order,language));
			amountMap.clear();

		}
		LOGGER.debug("order summary response ::"+response);
		return response;

	}


	private String prepareResponseMessage(String pgStatus, String winningStatus,OrderEntity order,String language){
		String event="";
		Map<String,String> variablesMap=new HashMap<>();
		if(amountMap.containsKey("amount")) {
			variablesMap.put("amount",amountMap.get("amount"));
		}
		if ("SUCCESS".equals(winningStatus) && ("01".equals(pgStatus))
				&& (order.getStatus().equals(AppConstant.ORDER_STATUS.REFUND_INITIATED.getValue())
						|| order.getStatus().equals(AppConstant.ORDER_STATUS.REFUNDED.getValue())
						|| order.getStatus().equals(AppConstant.ORDER_STATUS.COIN_CREDIT_PENDING.getValue()))) {
			event = "EVENT_LABEL_ORDER_COINS_CREDIT_FAILED";

		}else

		 if("SUCCESS".equals(winningStatus) && "01".equals(pgStatus)){
			event="EVENT_LABEL_ORDER_SUCCESS";

		}else

		if("SUCCESS".equals(winningStatus) && ("227".equals(pgStatus) || "401".equals(pgStatus) )){
			event= "EVENT_LABEL_ORDER_PG_FAILED_227";

		}else

		if("SUCCESS".equals(winningStatus) && ("334".equals(pgStatus) || "810".equals(pgStatus) )){
			event="EVENT_LABEL_ORDER_PG_FAILED_334";

		}else

		if("NA".equals(winningStatus) && ("227".equals(pgStatus) || "401".equals(pgStatus) )){
			event= "EVENT_LABEL_ORDER_PG_ONLY_FAILED_227";

		}else

		if("NA".equals(winningStatus) && ("334".equals(pgStatus) || "810".equals(pgStatus) )){
			event="EVENT_LABEL_ORDER_PG_ONLY_FAILED_334";

		}else
		
		if("NA".equals(winningStatus) && "01".equals(pgStatus)){
			event="EVENT_LABEL_ORDER_SUCCESS";

		}
		else

		if("FAILED".equals(winningStatus) && "01".equals(pgStatus)){
			event= "EVENT_LABEL_ORDER_WINNING_FAILED";

		}else

		if("PENDING".equals(winningStatus) && "01".equals(pgStatus)){
			event= "EVENT_LABEL_ORDER_WINNING_PENDING";

		}else

		if("SUCCESS".equals(winningStatus) && ("400".equals(pgStatus) || "402".equals(pgStatus) )){
			event= "EVENT_LABEL_ORDER_PG_PENDING";

		}else

		if("SUCCESS".equals(winningStatus) && ("01".equals(pgStatus)) && order.getStatus().equals(AppConstant.ORDER_STATUS.COIN_CREDIT_PENDING.getValue())){
			event="EVENT_LABEL_ORDER_COIN_CREDIT_PENDING";

		}
		
		if(("SUCCESS".equals(winningStatus) || "NA".equals(winningStatus)) && ("TXN_FAILURE".equals(pgStatus))){
			event="EVENT_LABEL_ORDER_PG_FAILED";

		}

		LOGGER.info("event selected for response:::"+event);

		try {
			return messageSelector.getMessageLabel(event, language, variablesMap);
		}catch(Exception e){
			LOGGER.error("Error while fetching the message content from db.",e);
		}

		return "";
	}
	
}//End of OrderController
