package com.cricplay.pgi.model;

public class PGTxnUpdate {
	
	Integer orderId;
	PGTransaction pgTransaction; 
	
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	
	public PGTransaction getPgTransaction() {
		return pgTransaction;
	}
	public void setPgTransaction(PGTransaction pgTransaction) {
		this.pgTransaction = pgTransaction;
	}
	@Override
	public String toString() {
		return "PGTxnUpdate [orderId=" + orderId + ", pgTransaction=" + pgTransaction + "]";
	}
	
}
