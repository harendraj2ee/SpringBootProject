package com.cricplay.pgi.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.BatchConfigurationEntity;

@Repository
public interface BatchConfigurationRepository extends JpaRepository<BatchConfigurationEntity, Integer>{

	@Query(value = "SELECT * FROM pg_batch_configuration where batch_type=?", nativeQuery = true)
	BatchConfigurationEntity findBatchConfigurationByType(String batchType);
	
	@Query(value = "UPDATE pg_batch_configuration SET current_status = ? , batch_status = ? where id=?", nativeQuery = true)
	BatchConfigurationEntity UpdateBatchConfigurationById(String currentStatus, String batchStatus, Integer Id);

}
