package com.cricplay.pgi.model;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.security.MessageDigest;
import java.util.TreeMap;

import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;

import com.cricplay.pgi.util.StringUtils;
import com.paytm.pg.merchant.CheckSumServiceHelper;

public class Checksum  implements Serializable{
	


private static final long serialVersionUID = 1L;


	public static final Logger LOGGER = Logger.getLogger(Checksum.class);
	
	private String mid;
	private String orderId;
	private String custId;
	private String channelId;
	private String txnAmount;
	private String website;
	private String industryTypeId;
	private String callBackUrl;
	private String checkSumHash;
	


	public Checksum(String mid, String orderId, String custId, String channelId, String txnAmount, String website,
			String industryTypeId, String callBackUrl, String checkSumHash) {
		super();
		this.mid = mid;
		this.orderId = orderId;
		this.custId = custId;
		this.channelId = channelId;
		this.txnAmount = txnAmount;
		this.website = website;
		this.industryTypeId = industryTypeId;
		this.callBackUrl = callBackUrl;
		this.checkSumHash = checkSumHash;
	}

	public Checksum() {
		super();
	}

	public String generateChecksum() {

		ByteArrayOutputStream baos = null;
		ObjectOutputStream oos = null;
		String checksum="";
		try {
			baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			oos.writeObject(this);
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			byte[] thedigest = md.digest(baos.toByteArray());
			checksum=DatatypeConverter.printHexBinary(thedigest);
		} catch(Exception e){
			LOGGER.error("Exception occured during generating checksum ::"+e.getMessage());
		}finally {
			try {
				oos.close();
				baos.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return checksum;
	}
	@Override
	public String toString() {
		return StringUtils.toJson(this);
	}

	
	
	public String getChecksumHash(String merchantKey) {
		
		TreeMap<String,String> paramMap = new TreeMap<String,String>();
		paramMap.put("MID" , this.mid);
		paramMap.put("ORDER_ID" , this.orderId);
		paramMap.put("CUST_ID" , this.custId);
		paramMap.put("INDUSTRY_TYPE_ID" , this.industryTypeId);
		paramMap.put("CHANNEL_ID" , this.channelId);
		paramMap.put("TXN_AMOUNT" , this.txnAmount);
		paramMap.put("WEBSITE" , this.website);
		paramMap.put("CALLBACK_URL" , this.callBackUrl);

		String checkSum="";
		try {
			checkSum = CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(merchantKey, paramMap);
		} catch (Exception e) {
			LOGGER.error("Exception occured during getting checksum hash::"+e.getMessage());
		}
		
		return checkSum;
	}

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getTxnAmount() {
		return txnAmount;
	}

	public void setTxnAmount(String txnAmount) {
		this.txnAmount = txnAmount;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getIndustryTypeId() {
		return industryTypeId;
	}

	public void setIndustryTypeId(String industryTypeId) {
		this.industryTypeId = industryTypeId;
	}

	public String getCallBackUrl() {
		return callBackUrl;
	}

	public void setCallBackUrl(String callBackUrl) {
		this.callBackUrl = callBackUrl;
	}

	public String getCheckSumHash() {
		return checkSumHash;
	}

	public void setCheckSumHash(String checkSumHash) {
		this.checkSumHash = checkSumHash;
	}

	
}