package com.cricplay.pgi.model;

import java.io.Serializable;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import com.paytm.pg.merchant.CheckSumServiceHelper;

public class PatytmTransactionStatus implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final Logger LOGGER = Logger.getLogger(Checksum.class);

	private String mid;
	private String orderId;
	private String refundAmount;

	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public PatytmTransactionStatus() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	public PatytmTransactionStatus(String mid, String orderId, String refundAmount) {
		this.mid = mid;
		this.orderId = orderId;
		this.refundAmount = refundAmount;
	}
	

	@Override
	public String toString() {
		return "PatytmTransactionStatus [mid=" + mid + ", orderId=" + orderId + ", refundAmount=" + refundAmount + "]";
	}

	
}
