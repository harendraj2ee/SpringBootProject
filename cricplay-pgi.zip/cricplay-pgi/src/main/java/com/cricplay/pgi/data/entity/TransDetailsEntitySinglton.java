package com.cricplay.pgi.data.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.cricplay.pgi.util.StringUtils;

@Entity
@Table(name = "pg_transdetails")
public class TransDetailsEntitySinglton {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "trandtl_id", updatable = false, nullable = false)
	private Integer trandtlID;
	
	@Column(name="trans_id")
	private Integer transId;
	
	@Column(name = "user_id")
	private String  userId;
	
	@Column(name = "payment_type")
	private String paymentType;
	
	@Column(name = "created_on")
	private Date createdOn;
	
	@Column(name = "modified_on")
	private Date modifiedOn;
	
	@Column(name = "status")
	private String status; 
	
	@Column(name ="description")
	private String description;
	
	@Column(name ="request_id")
	private String requestId;
	
	@Column(name ="event_type",columnDefinition="default ' ' ")
	private String eventType;
	
	

	public Integer getTrandtlID() {
		return trandtlID;
	}

	public void setTrandtlID(Integer trandtlID) {
		this.trandtlID = trandtlID;
	}

	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}
	
	@Override
	public String toString() {
		return StringUtils.toJson(this);
	}

	public Integer getTransId() {
		return transId;
	}

	public void setTransId(Integer transId) {
		this.transId = transId;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Date modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

}
