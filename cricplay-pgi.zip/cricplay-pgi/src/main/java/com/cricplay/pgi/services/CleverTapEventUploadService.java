package com.cricplay.pgi.services;

import org.springframework.http.ResponseEntity;

import com.cricplay.pgi.clevertap.model.CleverTap;
import com.cricplay.pgi.clevertap.model.CleverTapUploadResponse;

public interface CleverTapEventUploadService {

	public ResponseEntity<CleverTapUploadResponse> cleverTapUploadEvent(CleverTap cleverTapObj);
}
