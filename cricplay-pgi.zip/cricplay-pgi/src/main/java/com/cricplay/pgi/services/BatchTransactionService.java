package com.cricplay.pgi.services;

import com.cricplay.pgi.data.entity.BatchTransactionEntity;

public interface BatchTransactionService {
	public BatchTransactionEntity findBatchTransactionByBatchJobId(String batchJobId) throws Exception;
}
