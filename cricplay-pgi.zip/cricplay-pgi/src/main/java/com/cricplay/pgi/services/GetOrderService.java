package com.cricplay.pgi.services;

import com.cricplay.pgi.data.entity.OrderEntity;

public interface GetOrderService {
	public OrderEntity findOrderByStatus(String status);
	public OrderEntity findOrderById(Integer orderid);
	
}
