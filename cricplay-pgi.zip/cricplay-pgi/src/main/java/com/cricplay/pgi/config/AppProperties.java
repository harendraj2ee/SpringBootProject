package com.cricplay.pgi.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.util.StringUtils;

@Component
//@PropertySource(value= {"file:${property.path}/application-${spring.profiles.active}.properties"})
//@PropertySource(value= {"classpath:application-${spring.profiles.active}.properties"})
public class AppProperties {

	@Value("${cricplay.pgi.winning.debit.url}")
	String winningDebitUrl;

	@Value("${cricplay.pgi.verify.user.url}")
	String verifyUserUrl;

	@Value("${cricplay.pgi.wallet.balance.url}")
	String walletBalanceUrl;

	@Value("${cricplay.pgi.coin.credit.url}")
	String coinCreditUrl;

	@Value("${cricplay.pgi.paytm.website}")
	String website;

	@Value("${cricplay.pgi.paytm.callback.url}")
	String callbackUrl;

	@Value("${cricplay.pgi.paytm.merchant.key}")
	public String merchantKey;

	@Value("${cricplay.pgi.internal.refund.url}")
	String internalRefundUrl;

	@Value("${cricplay.pgi.internal.refundstatus.url}")
	String internalRefundStatusUrl;

	@Value("${cricplay.pgi.merchant.id}")
	String merchantId;
	
	@Value("${cricplay.pgi.internal.transactionStatus.url}")
	String transactionStatusUrl;

	@Value("${cricplay.pgi.paytm.appcallback.url}")
	String appCallbackUrl;

	@Value("${cricplay.pgi.paytm.appwebsite}")
	String appWebsite;

	@Value("${cricplay.pgi.wallet.currency.status.check}")
	String currencyCheckUrl;

	@Value("${cricplay.pgi.paytm.transactionstatus.url}")
	String paytmTransactionStatusUrl;
	
	@Value("${cricplay.pgi.clevertap.upload.url}")
	String cleverTapUploadUrl;

	@Value("${cricplay.pgi.clevertap.accountid}")
	String cleverTapAccountId;

	@Value("${cricplay.pgi.clevertap.passcode}")
	String cleverTapPasscode;

	@Value("${cricplay.pgi.sms.url}")
	String cricPlaySmsUrl;

	@Value("${circplay.pgi.shareit.api.url}")
	String cricPlayShareItApiUrl;

	@Value("${circplay.pgi.shareit.api.merchantId}")
	String shareItMerchantId;

	@Value("${circplay.pgi.shareit.api.secretKey}")
	String shareItSecretKey;

	@Value("${circplay.pgi.shareit.api.version}")
	String shareItApiVersion;
	
	@Value("${cricplay.pgi.batch.initiation.time.min}")
	Integer initiationStatustimeBefore;

	@Value("${cricplay.pgi.shareit.callback.url}")
	String shareItCallBackUrl;
	
	@Value("${cricplay.pgi.shareit.currency}")
	String shareItCurrency;
	
	@Value("${cricplay.pgi.shareit.refund.apply.callback.url}")
	String shareItRefundApplyCallbackUrl;
	
	@Value("${cricplay.pgi.shareit.transaction.update.url}")
	String shareitTransactionUpdateUrl;
	
	@Value("${cricplay.pgi.base.url}")
	String baseUrl;

	public String getTransactionStatusUrl() {
		return transactionStatusUrl;
	}

	public void setTransactionStatusUrl(String transactionStatusUrl) {
		this.transactionStatusUrl = transactionStatusUrl;

	}

	
	public String getAppCallbackUrl() {
		return appCallbackUrl;
	}

	public void setAppCallbackUrl(String appCallbackUrl) {
		this.appCallbackUrl = appCallbackUrl;
	}

	public String getAppWebsite() {
		return appWebsite;
	}

	public void setAppWebsite(String appWebsite) {
		this.appWebsite = appWebsite;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getInternalRefundStatusUrl() {
		return internalRefundStatusUrl;
	}

	public void setInternalRefundStatusUrl(String internalRefundStatusUrl) {
		this.internalRefundStatusUrl = internalRefundStatusUrl;
	}


	public String getWinningDebitUrl() {
		return winningDebitUrl;
	}

	public void setWinningDebitUrl(String winningDebitUrl) {
		this.winningDebitUrl = winningDebitUrl;
	}

	public String getVerifyUserUrl() {
		return verifyUserUrl;
	}

	public void setVerifyUserUrl(String verifyUserUrl) {
		this.verifyUserUrl = verifyUserUrl;
	}

	public String getWalletBalanceUrl() {
		return walletBalanceUrl;
	}

	public void setWalletBalanceUrl(String walletBalanceUrl) {
		this.walletBalanceUrl = walletBalanceUrl;
	}

	public String getCoinCreditUrl() {
		return coinCreditUrl;
	}

	public void setCoinCreditUrl(String coinCreditUrl) {
		this.coinCreditUrl = coinCreditUrl;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public String getMerchantKey() {
		return merchantKey;
	}

	public void setMerchantKey(String merchantKey) {
		this.merchantKey = merchantKey;
	}
	
	public String getInternalRefundUrl() {
		return internalRefundUrl;
	}

	public void setInternalRefundUrl(String internalRefundUrl) {
		this.internalRefundUrl = internalRefundUrl;
	}


	public String getCurrencyCheckUrl() {
		return currencyCheckUrl;
	}

	public void setCurrencyCheckUrl(String currencyCheckUrl) {
		this.currencyCheckUrl = currencyCheckUrl;
	}


	public String getPaytmTransactionStatusUrl() {
		return paytmTransactionStatusUrl;
	}

	public void setPaytmTransactionStatusUrl(String paytmTransactionStatus) {
		this.paytmTransactionStatusUrl = paytmTransactionStatus;
	}
	

	public String getCleverTapUploadUrl() {
		return cleverTapUploadUrl;
	}

	public void setCleverTapUploadUrl(String cleverTapUploadUrl) {
		this.cleverTapUploadUrl = cleverTapUploadUrl;
	}

	public String getCleverTapAccountId() {
		return cleverTapAccountId;
	}

	public void setCleverTapAccountId(String cleverTapAccountId) {
		this.cleverTapAccountId = cleverTapAccountId;
	}

	public String getCleverTapPasscode() {
		return cleverTapPasscode;
	}

	public void setCleverTapPasscode(String cleverTapPasscode) {
		this.cleverTapPasscode = cleverTapPasscode;
	}
	
	public String getCricPlaySmsUrl() {
		return cricPlaySmsUrl;
	}

	public void setCricPlaySmsUrl(String cricPlaySmsUrl) {
		this.cricPlaySmsUrl = cricPlaySmsUrl;
	}
	

	public String getCricPlayShareItApiUrl() {
		return cricPlayShareItApiUrl;
	}

	public void setCricPlayShareItApiUrl(String cricPlayShareItApiUrl) {
		this.cricPlayShareItApiUrl = cricPlayShareItApiUrl;
	}
	
	

	public String getShareItMerchantId() {
		return shareItMerchantId;
	}

	public void setShareItMerchantId(String shareItMerchantId) {
		this.shareItMerchantId = shareItMerchantId;
	}

	public String getShareItSecretKey() {
		return shareItSecretKey;
	}

	public void setShareItSecretKey(String shareItSecretKey) {
		this.shareItSecretKey = shareItSecretKey;
	}

	public String getShareItApiVersion() {
		return shareItApiVersion;
	}

	public void setShareItApiVersion(String shareItApiVersion) {
		this.shareItApiVersion = shareItApiVersion;
	}

	public Integer getInitiationStatustimeBefore() {
		return initiationStatustimeBefore;
	}

	public void setInitiationStatustimeBefore(Integer initiationStatustimeBefore) {
		this.initiationStatustimeBefore = initiationStatustimeBefore;
	}

	public String getShareItCallBackUrl() {
		return shareItCallBackUrl;
	}

	public void setShareItCallBackUrl(String shareItCallBackUrl) {
		this.shareItCallBackUrl = shareItCallBackUrl;
	}

	public String getShareItCurrency() {
		return shareItCurrency;
	}

	public void setShareItCurrency(String shareItCurrency) {
		this.shareItCurrency = shareItCurrency;
	}
	
	public String getShareItRefundApplyCallbackUrl() {
		return shareItRefundApplyCallbackUrl;
	}

	public void setShareItRefundApplyCallbackUrl(String shareItRefundApplyCallbackUrl) {
		this.shareItRefundApplyCallbackUrl = shareItRefundApplyCallbackUrl;
	}

	public String getShareitTransactionUpdateUrl() {
		return shareitTransactionUpdateUrl;
	}

	public void setShareitTransactionUpdateUrl(String shareitTransactionUpdateUrl) {
		this.shareitTransactionUpdateUrl = shareitTransactionUpdateUrl;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	@Override

    public String toString() {
        return StringUtils.toJson(this);
    }

	public Map<String,String> getMechantInfo(String pgVendor) {
		Map<String,String> mechantInfoMap=new HashMap<>();
		if(AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(pgVendor)){
			mechantInfoMap.put("merchantId", getMerchantId());
			mechantInfoMap.put("merchantKey", getMerchantKey());
		}
		if(AppConstant.PG_VENDOR.SHAREIT.getValue().equalsIgnoreCase(pgVendor)){
			mechantInfoMap.put("merchantId", getShareItMerchantId());
			mechantInfoMap.put("merchantKey", getShareItSecretKey());
		}
		return mechantInfoMap;
	}
}