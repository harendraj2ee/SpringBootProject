package com.cricplay.pgi.data.entity;

import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import com.cricplay.pgi.util.StringUtils;

@Entity
@Table(name = "pg_transaction")
public class TransactionEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "trans_id", updatable = false, nullable = false)
	private Integer transId;
	
	@ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="order_id")
	private OrderEntity order;
	
	/*@Column(name="order_id", insertable=false, updatable=false)
	private Integer orderId;*/
	
	 @Column(name = "user_id")
	 private String userId;
	 
	 @Column(name ="payment_type")
	 String paymentType;
	 
	 @Column(name ="price")
	 Double price;
	 
	 @Column(name ="amount")
	 Double amount;
	 
	 @Column(name ="valuation")
	 Integer valuation;
	 
	 @Column(name ="event_type")
	 String eventType;
	 
	 @Column(name ="created_on")
	 Date created_on;
	 
	 @Column(name ="modified_on")
	 Date modified_on;
	 
	 @Column(name="trans_status")
	 String transStatus;
	 
	 @Column(name="description")
	 String description;
	 
	 @Column(name="pg_txnid")
	 String pgTxnId;
	 
	 @Column(name="bank_txnid")
	 String bankTxnId;
	 
	 @Column(name="txn_type")
	 String txnType;
	 
	 @Column(name="gateway_name")
	 String gatewayName;
	 
	 @Column(name="respcode")
	 String respCode;
	 
	 @Column(name="respmsg")
	 String respmsg;
	 
	 @Column(name="bank_name")
	 String bankName;
	 
	 @Column(name="payment_mode")
	 String paymentMode;
	 
	 @Column(name="refund_amt")
	 String refundAmount;
	 
	 @Column(name="txn_date")
	 String txnDate;
	 
	 @Column(name="pg_vendor")
	 String pgVendor;
	 
	 @Column(name="winning_debit_request")
	 String winningDebitRequest;
	 
	 @Column(name="winning_credit_request")
	 String winningCreditRequest;
	 
	 @Column(name="retry_counter")
	 Integer retryCounter;
	 
	 @Column(name="sign")
	 String sign;
	 
	 @Column(name="transaction_time")
	 Date transactionTime;
	 
	 @Column(name="country_code")
	 String countryCode;
	 
	 @Column(name="currency_code")
	 String currencyCode;
	 
	 public Integer getRetryCounter() {
		return retryCounter;
	}

	public void setRetryCounter(Integer retryCounter) {
		this.retryCounter = retryCounter;
	}

	@OneToMany(mappedBy="transaction")
	 private Set<TransDetailsEntity> transDetailsEntity;
	 

	public Integer getTransId() {
		return transId;
	}

	public void setTransId(Integer transId) {
		this.transId = transId;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}


	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Integer getValuation() {
		return valuation;
	}

	public void setValuation(Integer valuation) {
		this.valuation = valuation;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}


	public String getTransStatus() {
		return transStatus;
	}

	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	
	@PrePersist
	private void onPersist() {
		//this.setOrderId(order.getOrderId());
	}

	public Set<TransDetailsEntity> getTransDetailsEntity() {
		return transDetailsEntity;
	}

	public void setTransDetailsEntity(Set<TransDetailsEntity> transDetailsEntity) {
		this.transDetailsEntity = transDetailsEntity;
	}
	
	@Override
	public String toString() {
		return StringUtils.toJson(this);
	}

	public OrderEntity getOrder() {
		return order;
	}

	public void setOrder(OrderEntity order) {
		this.order = order;
	}

	public String getPgTxnId() {
		return pgTxnId;
	}

	public void setPgTxnId(String pgTxnId) {
		this.pgTxnId = pgTxnId;
	}

	public String getBankTxnId() {
		return bankTxnId;
	}

	public void setBankTxnId(String bankTxnId) {
		this.bankTxnId = bankTxnId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getGatewayName() {
		return gatewayName;
	}

	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}

	public String getRespCode() {
		return respCode;
	}

	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}

	public String getRespmsg() {
		return respmsg;
	}

	public void setRespmsg(String respmsg) {
		this.respmsg = respmsg;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public Date getModified_on() {
		return modified_on;
	}

	public void setModified_on(Date modified_on) {
		this.modified_on = modified_on;
	}

	public String getPgVendor() {
		return pgVendor;
	}

	public void setPgVendor(String pgVendor) {
		this.pgVendor = pgVendor;
	}

	public String getWinningDebitRequest() {
		return winningDebitRequest;
	}

	public void setWinningDebitRequest(String winningDebitRequest) {
		this.winningDebitRequest = winningDebitRequest;
	}

	public String getWinningCreditRequest() {
		return winningCreditRequest;
	}

	public void setWinningCreditRequest(String winningCreditRequest) {
		this.winningCreditRequest = winningCreditRequest;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public Date getTransactionTime() {
		return transactionTime;
	}

	public void setTransactionTime(Date transactionTime) {
		this.transactionTime = transactionTime;
	}

	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

}
