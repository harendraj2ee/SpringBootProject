package com.cricplay.pgi.dao;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.BatchTransactionEntity;
import com.cricplay.pgi.data.repository.BatchTransactionRepository;;

@Repository
public class BatchTransactionDaoImpl implements BatchTransactionDao {
	
private static final Logger LOGGER = Logger.getLogger(BatchTransactionDaoImpl.class);
	
	@Autowired
	BatchTransactionRepository batchTransactionRepository;
	
	@Override
	public BatchTransactionEntity findBatchTransactionByBatchJobId(String batchJobId) throws Exception {
		return batchTransactionRepository.findBatchTransactionByBatchJobId(batchJobId);
		
	}
}
