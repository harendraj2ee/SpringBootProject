package com.cricplay.pgi.services;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.dao.BatchJobDao;
import com.cricplay.pgi.data.entity.BatchJobEntity;

@Service
public class BatchJobServiceImpl implements BatchJobService {
	
	@Autowired
	BatchJobDao batchJobDao;

	@Override
	public BatchJobEntity findBatchJobByBatchTypeId(Integer batchTypeId) throws Exception {
		return batchJobDao.findBatchJobByBatchTypeId(batchTypeId);
	}

	@Override
	public BatchJobEntity insertBatchJobByRow(Integer batchTypeId, String batchType, Date startedOn, Date completedOn, String batchSize) throws Exception {
		return batchJobDao.InsertBatchJobByRow(batchTypeId, batchType, startedOn, completedOn, batchSize);
	}

	@Override
	public BatchJobEntity updateBatchJobByRow(Integer batchSize, Integer id) throws Exception {
		return batchJobDao.updateBatchJobByRow( batchSize , id);
	}

}
