package com.cricplay.pgi.dao;

import com.cricplay.pgi.data.entity.BatchConfigurationEntity;

public interface BatchConfigurationDao {
	
	public BatchConfigurationEntity findBatchConfigurationByType(String batchType) throws Exception;
	
	public BatchConfigurationEntity UpdateBatchConfigurationById(String currentStatus,String batchStatus, Integer  Id) throws Exception;


	
}
