package com.cricplay.pgi.dao;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.common.BaseDaoResponse;
import com.cricplay.pgi.common.DaoMessages;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.OrderStatusEntity;
import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.entity.TransDetailsEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.repository.OrderRepository;
import com.cricplay.pgi.data.repository.OrderStatusRepository;
import com.cricplay.pgi.data.repository.PlanRepository;
import com.cricplay.pgi.data.repository.TransDetailsRepository;
import com.cricplay.pgi.data.repository.TransactionRepository;
import com.cricplay.pgi.model.OrderModel;
import com.cricplay.pgi.util.CommonUtil;

@Repository
public class OrderDaoImpl implements OrderDao{

	public static final Logger LOGGER = Logger.getLogger(OrderDaoImpl.class);
	
	@Autowired
	OrderRepository orderRepository;
	
	@Autowired
	OrderStatusRepository orderStatusRepository;
	
	@Autowired
	PlanRepository PlanRepository;
	
	@Autowired
	TransactionRepository transactionRepository;
	
	@Autowired
	TransDetailsRepository transDetailsRepository;
	
	@Autowired
	EntityManager em;


	/**
	 *
	 * @param plan
	 * @param userId
	 * @param winningBalance
	 * @param orderType
	 * @param pgVendor
	 * @return
	 * @throws Exception
	 */
	@Override
	public OrderEntity buildOrder(PlanEntity plan,String userId,Double winningBalance,String orderType,String pgVendor) throws Exception{
		OrderEntity orderEntity=new OrderEntity();
		orderEntity.setPlanId(plan.getPlanId());
		orderEntity.setUserId(userId);
		orderEntity.setPrice(plan.getAmount());
		orderEntity.setCoins(plan.getCoins().doubleValue());
		orderEntity.setOrderType(orderType);
		orderEntity.setCreatedOn(new Date());
		orderEntity.setModifiedOn(new Date());
		orderEntity.setRetryCounter(0);
		orderEntity.setStatus(AppConstant.ORDER_STATUS.INITIATED.getValue());

		LOGGER.debug("Order Entity :: " +orderEntity.toString());
		orderEntity = orderRepository.save(orderEntity);
		String requestId=CommonUtil.generateRequestId(orderEntity.getOrderId());
		orderEntity.setTransactions(buildTransaction(orderEntity,userId,winningBalance,orderType,pgVendor,requestId));
		
		LOGGER.debug("Order Entity Post Setting Transactions:: " +orderEntity.toString());
		return orderEntity;
	}
	
	
	/**
	 * 
	 * @param order
	 * @return
	 */
	@Override
	public Set<TransactionEntity> buildTransaction(OrderEntity order,String userId,Double winningBalance, String orderType,String pgVendor,String requestId) throws Exception{
		Set<TransactionEntity> transactionEntitySet = new HashSet<>();
		if (orderType.equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNINGS_ONLY.getValue())) {
			TransactionEntity transactionEntity = new TransactionEntity();
			transactionEntity.setOrder(order);
			transactionEntity.setPaymentType(AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
			transactionEntity.setAmount(order.getPrice());
			//transactionEntity.setEventType(AppConstant.EVENT_TYPE.PRO_WINNING_DEBIT.getValue());
			transactionEntity.setEventType("");
			transactionEntity.setUserId(userId);
			transactionEntity.setPrice(order.getPrice());
			transactionEntity.setRetryCounter(0);
			transactionEntity.setCreated_on(new Date());
			transactionEntity.setModified_on(new Date());
			transactionEntity.setValuation(order.getPrice().intValue());
			transactionEntity.setTransStatus(AppConstant.TXN_STATUS.INITIATED.getValue());
			transactionEntity.setDescription(AppConstant.TRANS_DESCRIPTION.INPROGRESS.getValue());
			transactionEntity.setWinningDebitRequest(requestId);
			transactionEntitySet.add(transactionEntity);
		
		}else if(orderType.equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue())){
			TransactionEntity transactionEntity1 = new TransactionEntity();
			transactionEntity1.setOrder(order);
			transactionEntity1.setPaymentType(AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
			transactionEntity1.setPgVendor(pgVendor);
			transactionEntity1.setAmount(order.getPrice()-winningBalance);
			//transactionEntity1.setEventType(AppConstant.EVENT_TYPE.PRO_WINNING_DEBIT.getValue());
			transactionEntity1.setEventType("");
			transactionEntity1.setUserId(userId);
			transactionEntity1.setPrice(order.getPrice());
			transactionEntity1.setRetryCounter(0);
			transactionEntity1.setValuation(order.getPrice().intValue());
			transactionEntity1.setCreated_on(new Date());
			transactionEntity1.setModified_on(new Date());
			transactionEntity1.setTransStatus(AppConstant.TXN_STATUS.INITIATED.getValue());
			transactionEntity1.setDescription("");

			TransactionEntity transactionEntity2 = new TransactionEntity();
			transactionEntity2.setOrder(order);
			transactionEntity2.setPaymentType(AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
			transactionEntity2.setAmount(winningBalance);
			//transactionEntity2.setEventType(AppConstant.EVENT_TYPE.PRO_WINNING_DEBIT.getValue());
			transactionEntity2.setEventType("");
			transactionEntity2.setUserId(userId);
			transactionEntity2.setPrice(order.getPrice());
			transactionEntity2.setRetryCounter(0);
			transactionEntity2.setCreated_on(new Date());
			transactionEntity2.setModified_on(new Date());
			transactionEntity2.setValuation(order.getPrice().intValue());
			transactionEntity2.setTransStatus("Initiated");
			transactionEntity2.setWinningDebitRequest(requestId);
			transactionEntity2.setDescription(AppConstant.TRANS_DESCRIPTION.INPROGRESS.getValue());
			transactionEntitySet.add(transactionEntity1);
			transactionEntitySet.add(transactionEntity2);

		}
		else if(orderType.equalsIgnoreCase(AppConstant.ORDER_TYPE.PG_ONLY.getValue())){
			TransactionEntity transactionEntity1 = new TransactionEntity();
			transactionEntity1.setOrder(order);
			transactionEntity1.setPaymentType(AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
			transactionEntity1.setPgVendor(pgVendor);
			transactionEntity1.setAmount(order.getPrice());
			//transactionEntity1.setEventType(AppConstant.EVENT_TYPE.PRO_WINNING_DEBIT.getValue());
			transactionEntity1.setEventType("");
			transactionEntity1.setUserId(userId);
			transactionEntity1.setPrice(order.getPrice());
			transactionEntity1.setRetryCounter(0);
			transactionEntity1.setValuation(order.getPrice().intValue());
			transactionEntity1.setCreated_on(new Date());
			transactionEntity1.setModified_on(new Date());
			transactionEntity1.setTransStatus(AppConstant.TXN_STATUS.INITIATED.getValue());
			transactionEntity1.setDescription("");
			transactionEntitySet.add(transactionEntity1);
		}
		return transactionEntitySet;
	}
	
	
	/**
	 * 
	 * @param transactionEntity
	 * @return
	 */
	@Override
	public TransDetailsEntity buildTransDetails(TransactionEntity transactionEntity) throws Exception{
		TransDetailsEntity transDetailsEntity=new TransDetailsEntity();
		transDetailsEntity.setUserId(transactionEntity.getUserId());
		transDetailsEntity.setTransaction(transactionEntity);
		transDetailsEntity.setPaymentType(transactionEntity.getPaymentType());
		transDetailsEntity.setCreatedOn(new Date());
		transDetailsEntity.setModifiedOn(new Date());
		transDetailsEntity.setStatus(transactionEntity.getTransStatus());
		transDetailsEntity.setDescription(transactionEntity.getDescription());
		if(transactionEntity.getPaymentType().equalsIgnoreCase(AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue())) {
			transDetailsEntity.setEventType(AppConstant.EVENT_TYPE.PRO_WINNING_DEBIT.getValue());
			transDetailsEntity.setRequestId(transactionEntity.getWinningDebitRequest());
			
		}
		else {
			transDetailsEntity.setEventType("");
		}
		//	LOGGER.debug("TransDetailsEntity :: " +transDetailsEntity.toString());
		return transDetailsEntity;
		
	}


	@Override
	@Transactional
	public OrderEntity persistTransaction(PlanEntity planEntity,String userId,Double winningBalance,String orderType,String pgVendor) throws Exception{
		LOGGER.debug("calling persist...");
		OrderEntity orderEntity=buildOrder(planEntity, userId,winningBalance,orderType,pgVendor);
		
		transactionRepository.saveAll(orderEntity.getTransactions());
		
		for(TransactionEntity transactionEntity:orderEntity.getTransactions()) {
			LOGGER.debug("transactionEntity:::"+transactionEntity);
			transDetailsRepository.save(buildTransDetails(transactionEntity));
		}
		
		LOGGER.debug("persist done.");
		return orderEntity;
	}


	@Override
	public PlanEntity findPlanById(Integer planId) throws Exception{
		LOGGER.debug("getting plan by id start...");
		PlanEntity planEntity=null;
		try {
			 planEntity= PlanRepository.findPlanById(planId);
			 LOGGER.info("Plan Entitiy ::"+planEntity.toString());
		}catch(Exception e) {
			LOGGER.debug("Error while getting plan");
		}
		return planEntity;
	}
	
	
	@Override
	public int updateTransactionStatusById(String txnStatus, String description, Date date, Integer txnId) throws Exception{
		int count=transactionRepository.updateTransactionStatusById(txnStatus,description,date,txnId);
		return count;
	}


	@Override
	public Integer updateOrderStatusById(String OrderStatus, Date date, Integer orderId) throws Exception{
		Integer count=orderRepository.updateOrderStatusById(OrderStatus,date,orderId);
		return count;
	}


//	@Override
//	public OrderEntity findOrderByStatus(String status) throws Exception {
//		LOGGER.debug("getting Order table by status start...");
//		return orderRepository.findOrderByStatus(status);
//	}
		
	public OrderEntity findOrderById(Integer id) throws Exception {
		OrderEntity orderEntity=orderRepository.findOrderById(id);
		return orderEntity;
	}


	@Override
	public List<OrderStatusEntity> findOrderListByStatus(String Status) throws Exception {
		List<OrderStatusEntity> orderEntity=orderStatusRepository.findOrderListByStatus(Status);
		return orderEntity;
	}


	@Override
	public Integer updateOrder(String requestId, Date date,Integer orderId) throws Exception {
		
		return orderRepository.updateOrder(requestId, date, orderId);
	}


	@Override
	public OrderEntity getOrderSummary(Integer orderId) throws Exception {
		
		return orderRepository.findOrderById(orderId);
		
	}


	@Override
	public BaseDaoResponse getOrderSummary(Integer orderId,String userId) throws Exception {
		
		BaseDaoResponse response= new BaseDaoResponse();
		Object obj=null;
		try {
			obj= orderRepository.getOrderStatus(orderId,userId);
			response.setCode(DaoMessages.FIND_SUCCESS.getCode());
			response.setMessage(DaoMessages.FIND_SUCCESS.getMessage());
			response.setResponse(obj);
		}
		catch(Exception e) {
			LOGGER.error(e.toString(),e);
			response.setCode(DaoMessages.FIND_ERROR.getCode());
			response.setMessage(DaoMessages.FIND_ERROR.getMessage());
		}
		return response;
	}


	@Override
	public List<OrderEntity> findOrderEntityListByStatus(String status) {
		return orderRepository.findOrderByStatus(status);
	}


	@Override
	@Transactional
	public boolean updateTransactionAndDtl(TransactionEntity transactionEntity ) throws Exception{
		LOGGER.info("updateTransactionAndDtl start...");
		transactionRepository.save(transactionEntity);
		
		TransDetailsEntity transDetailsEntity=new TransDetailsEntity();
		transDetailsEntity.setTransaction(transactionEntity);
		transDetailsEntity.setStatus(transactionEntity.getTransStatus());
		transDetailsEntity.setUserId(transactionEntity.getUserId());
		transDetailsEntity.setPaymentType(transactionEntity.getPaymentType());
		if(transactionEntity.getEventType()!=null) {
		transDetailsEntity.setEventType(transactionEntity.getEventType());
		}else {
			transDetailsEntity.setEventType("");
		}
		transDetailsEntity.setDescription("");
		
		//transDetailsEntity.setRequestId(transactionEntity.getwi());
		transDetailsEntity=transDetailsRepository.save(transDetailsEntity);
		LOGGER.info("updateTransactionAndDtl end");
		return true;
	}

}
