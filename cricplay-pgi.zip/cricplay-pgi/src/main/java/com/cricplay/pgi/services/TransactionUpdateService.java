package com.cricplay.pgi.services;



import java.util.Date;
import java.util.List;

import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;
import com.cricplay.pgi.model.PGTxnUpdate;

public interface TransactionUpdateService {
	
	Integer findTransactionIdByOrderId(Integer orderId) throws Exception;
	
	Integer findTransactionIdByOrderIdAndPaymentType(Integer orderId,String paymentType) throws Exception;
	
	Integer updatePgTransaction(PGTxnUpdate pgTxnUpdate, TransactionEntity transactionEntity,Integer orderId,String paymentType) throws Exception;
	
	int updateTransactionStatusById(String status, String description,Date date,Integer transId) throws Exception;
	
	public List<TransactionEntitySinglton> findTransactionBytransStatus(String transStatus)throws Exception;
	
	public List<TransactionEntitySinglton> findTransacitionByOrderId(Integer orderId) throws Exception;
	
	public boolean isWinningCreditExist(Integer transactionId);

	public boolean updateTransactionAndDtlStatusById(TransactionEntity transactionEntity) throws Exception;

	public TransactionEntity findTransactionByOrderIdAndPaymentType(Integer orderId,String paymentType) throws Exception;


}
