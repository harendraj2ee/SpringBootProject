package com.cricplay.pgi.model;

import java.io.Serializable;
import java.util.TreeMap;

import org.apache.log4j.Logger;

import com.paytm.pg.merchant.CheckSumServiceHelper;

public class TransactionRefund implements Serializable{
	
	private static final long serialVersionUID = 1L;
	public static final Logger LOGGER = Logger.getLogger(Checksum.class);
	
	private String mid;
	private String orderId;
	private String refundAmount;
	private String txnId;
	private String refId;
	private String txnType;
	
	public String getMid() {
		return mid;
	}

	public void setMid(String mid) {
		this.mid = mid;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getRefId() {
		return refId;
	}

	public void setRefId(String refId) {
		this.refId = refId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}


	public TransactionRefund() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public TransactionRefund(String refundAmount, String mid, String orderId, String txnId, String refId, String txnType) {
		super();
			this.mid = mid;
			this.orderId = orderId;
			this.txnId = txnId;
			this.refId = refId;
			this.txnType = txnType;
			this.refundAmount = refundAmount;			
	}

	@Override
	public String toString() {
		return "TransactionRefund [mid=" + mid + ", orderId=" + orderId + ", refundAmount=" + refundAmount + ", txnId="
				+ txnId + ", refId=" + refId + ", txnType=" + txnType + "]";
	}
	
public String getChecksumHash(String merchantKey) {
		
		TreeMap<String,String> paramMap = new TreeMap<String,String>();
		paramMap.put("MID" , this.mid);
		paramMap.put("REFID", this.refId);
		paramMap.put("TXNID", this.txnId);
		paramMap.put("ORDERID", this.orderId);
		paramMap.put("REFUNDAMOUNT", this.refundAmount);
		paramMap.put("TXNTYPE", this.txnType);
		

		String checkSum="";
		try {
			checkSum = CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(merchantKey, paramMap);
		} catch (Exception e) {
			LOGGER.error("Exception occured during getting checksum hash::"+e.getMessage());
		}
		
		return checkSum;
	}

	

}
