package com.cricplay.pgi.clevertap.model;

public class CleverTapUploadResponse {
	
	private String status;
	private Integer processed;
	private Object[] unprocessed;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Integer getProcessed() {
		return processed;
	}
	public void setProcessed(Integer processed) {
		this.processed = processed;
	}
	public Object[] getUnprocessed() {
		return unprocessed;
	}
	public void setUnprocessed(Object[] unprocessed) {
		this.unprocessed = unprocessed;
	}
	
}
