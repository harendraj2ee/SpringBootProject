package com.cricplay.pgi.notification;

import org.springframework.stereotype.Component;

@Component
public interface Notifier {

    /**
     * send notification to user
     * @param notificationRequest
     * @return
     */
    public boolean notify(NotificationRequest notificationRequest) throws Exception;

}
