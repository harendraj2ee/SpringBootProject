package com.cricplay.pgi.model;

import java.util.Date;

public class TransactionStatusResponse {
	
	private String MID;
	private String TXNID;
	private String ORDERID;
	private String BANKTXNID;
	private String TXNAMOUNT;
	private String STATUS;
	private String RESPCODE;
	private String RESPMSG;
	private Date TXNDATE;
	private String GATEWAYNAME;
	private String BANKNAME;
	private String PAYMENTMODE;
	private String TXNTYPE;
	private String REFUNDAMT;
	
	//private String CHECKSUMHASH; ///extra added
	public TransactionStatusResponse() {
		super();
	}
	
	public TransactionStatusResponse(String mID, String tXNID, String oRDERID, String bANKTXNID, String tXNAMOUNT,
			String sTATUS, String rESPCODE, String rESPMSG, Date tXNDATE, String gATEWAYNAME, String bANKNAME,
			String pAYMENTMODE, String tXNTYPE, String rEFUNDAMT) {
		MID = mID;
		TXNID = tXNID;
		ORDERID = oRDERID;
		BANKTXNID = bANKTXNID;
		TXNAMOUNT = tXNAMOUNT;
		STATUS = sTATUS;
		RESPCODE = rESPCODE;
		RESPMSG = rESPMSG;
		TXNDATE = tXNDATE;
		GATEWAYNAME = gATEWAYNAME;
		BANKNAME = bANKNAME;
		PAYMENTMODE = pAYMENTMODE;
		TXNTYPE = tXNTYPE;
		REFUNDAMT = rEFUNDAMT;
	}


	public String getMID() {
		return MID;
	}
	public void setMID(String mID) {
		MID = mID;
	}
	public String getTXNID() {
		return TXNID;
	}
	public void setTXNID(String tXNID) {
		TXNID = tXNID;
	}
	public String getORDERID() {
		return ORDERID;
	}
	public void setORDERID(String oRDERID) {
		ORDERID = oRDERID;
	}
	public String getBANKTXNID() {
		return BANKTXNID;
	}
	public void setBANKTXNID(String bANKTXNID) {
		BANKTXNID = bANKTXNID;
	}
	public String getTXNAMOUNT() {
		return TXNAMOUNT;
	}
	public void setTXNAMOUNT(String tXNAMOUNT) {
		TXNAMOUNT = tXNAMOUNT;
	}
	public String getSTATUS() {
		return STATUS;
	}
	public void setSTATUS(String sTATUS) {
		STATUS = sTATUS;
	}
	public String getRESPCODE() {
		return RESPCODE;
	}
	public void setRESPCODE(String rESPCODE) {
		RESPCODE = rESPCODE;
	}
	public String getRESPMSG() {
		return RESPMSG;
	}
	public void setRESPMSG(String rESPMSG) {
		RESPMSG = rESPMSG;
	}
	public Date getTXNDATE() {
		return TXNDATE;
	}
	public void setTXNDATE(Date tXNDATE) {
		TXNDATE = tXNDATE;
	}
	public String getGATEWAYNAME() {
		return GATEWAYNAME;
	}
	public void setGATEWAYNAME(String gATEWAYNAME) {
		GATEWAYNAME = gATEWAYNAME;
	}
	public String getBANKNAME() {
		return BANKNAME;
	}
	public void setBANKNAME(String bANKNAME) {
		BANKNAME = bANKNAME;
	}
	public String getPAYMENTMODE() {
		return PAYMENTMODE;
	}
	public void setPAYMENTMODE(String pAYMENTMODE) {
		PAYMENTMODE = pAYMENTMODE;
	}
	public String getTXNTYPE() {
		return TXNTYPE;
	}
	public void setTXNTYPE(String tXNTYPE) {
		TXNTYPE = tXNTYPE;
	}
	public String getREFUNDAMT() {
		return REFUNDAMT;
	}
	public void setREFUNDAMT(String rEFUNDAMT) {
		REFUNDAMT = rEFUNDAMT;
	}
	
	
	@Override
	public String toString() {
		return "TransactionStatusResponse [MID=" + MID + ", TXNID=" + TXNID + ", ORDERID=" + ORDERID + ", BANKTXNID="
				+ BANKTXNID + ", TXNAMOUNT=" + TXNAMOUNT + ", STATUS=" + STATUS + ", RESPCODE=" + RESPCODE
				+ ", RESPMSG=" + RESPMSG + ", TXNDATE=" + TXNDATE + ", GATEWAYNAME=" + GATEWAYNAME + ", BANKNAME="
				+ BANKNAME + ", PAYMENTMODE=" + PAYMENTMODE + ", TXNTYPE=" + TXNTYPE + ", REFUNDAMT=" + REFUNDAMT + "]";
	}

}
