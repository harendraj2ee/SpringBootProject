package com.cricplay.pgi.services;

import org.springframework.http.ResponseEntity;

import com.cricplay.pgi.model.VerifyUserResponse;

public interface VerifyUserService {

		public ResponseEntity<VerifyUserResponse> verifyUser(String auth) throws Exception;
}
