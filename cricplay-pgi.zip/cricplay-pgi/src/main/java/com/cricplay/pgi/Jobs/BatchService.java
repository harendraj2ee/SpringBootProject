/**
 * 
 */
package com.cricplay.pgi.Jobs;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.dao.TransactionRefundDao;
import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.entity.TransactionRefundHistory;
import com.cricplay.pgi.data.repository.BatchConfigurationRepository;
import com.cricplay.pgi.data.repository.BatchJobRepository;
import com.cricplay.pgi.data.repository.TransactionSingletonRepository;
import com.cricplay.pgi.services.BatchJobService;

/**
 * @author infinity
 *
 */
@Service
public abstract class BatchService {

	private static final Logger logger = Logger.getLogger(BatchService.class);
	
	public static final String INITIATED_STATUS = "initiated";
	public static final String PG_BATCH_TRANSACTION_STATUS = "PG";
	public static final String WINNING_BATCH_TRANSACTION_STATUS = "Winnings";
	public static final String RUNNING_STATUS="Running";
	public static final String IDEAL_STATUS = "Ideal";
	public static final String ACTIVE_STATUS = "Active";
	public static final String COIN_CREDIT_PENDING_STATUS = "coin credit pending";
	public static final String PENDING_STATUS = "Pending";

	@Autowired
	private BatchJobService batchJobService;
	
	@Autowired
	private TransactionRefundDao transactionRefundDao;
	
	@Autowired
	private TransactionDao transactionDao;
	
	@Autowired
	private BatchJobRepository batchJobRepository;
	
	@Autowired
	private BatchConfigurationRepository batchConfigurationRepository;
	
	@Autowired
	private TransactionSingletonRepository transactionSingletonRepository;


	/**
	 * Business logic
	 * 
	 * Step 1 : Update pg_batch_job table
	 * 			Columns : batch_size
	 * Step 2 : Update pg_batch_configuration table
	 * 			Columns : current_status
	 * 
	 * @param batchJobEntity
	 * @param transactionRefundStatusList
	 * @param batchConfigurationEntity
	 */
	public void batchConfigStatusUpdate(BatchJobEntity batchJobEntity, Integer batchSize,
			BatchConfigurationEntity batchConfigurationEntity) {

		try {
			// Step 1 : Update BatchJob table with transactionList size with orderId
			if (batchSize != null && batchSize>0) {
				logger.info("Current Row id from Batch job table" + batchJobEntity.getId());
				//batchJobEntity = batchJobService.updateBatchJobByRow(transactionRefundStatusList.size(),batchJobEntity.getId());

				//Do update operation if id is exist in BatchJobEntity object
				batchJobEntity.setCompletedOn(new Date());
				batchJobEntity.setBatchSize(String.valueOf(batchSize));
				
				batchJobRepository.save(batchJobEntity);
				
				logger.info("Batch Job Entity update with batch_size"+ batchJobEntity);
			}

			// Step 2: After complete the batch process Status updated with "Ideal" into
			//BatchConfigurationEntity updatedBatchConfigurationEntity = batchConfigurationService.updateBatchConfigurationById(IDEAL_STATUS, ACTIVE_STATUS,	batchConfigurationEntity.getId());
				
				//Do update operation if id is exist in BatchConfigurationEntity object
				batchConfigurationEntity.setModifyDate(new Date());
				batchConfigurationEntity.setCurrentStatus(IDEAL_STATUS);
				
				batchConfigurationRepository.save(batchConfigurationEntity);
				logger.info("Batch Configration Entity update after Batch Transaction cron type"+ batchConfigurationEntity);
				
				logger.info("\n Status has been updated with Ideal. BatchConfigurationEntity :" + batchConfigurationEntity);
		} catch (Exception ex) {
			logger.info("There is exception to process batchConfigStatusUpdate()");
			ex.printStackTrace();
		}

	}
	
	/**
	 * Business logic
	 * Step 1 : update pg_batch_configuration table
	 * 			Columns : current_status
	 * Step 2 : insert new record into pg_batch_job table
	 * @param currentStatus
	 * @param batchConfigurationEntity
	 */
	public BatchJobEntity batchConfigDataInitialize(String currentStatus,BatchConfigurationEntity batchConfigurationEntity) {
		BatchJobEntity batchJobEntity=null;
		try {
			
			//Step 1 : insert data into batch table if batchConfigurationEntity's status is Running
			// Do update operation only
			batchConfigurationEntity.setCurrentStatus(currentStatus);
			batchConfigurationEntity.setModifyDate(new Date());
			batchConfigurationRepository.save(batchConfigurationEntity);
			
			logger.info("\n start batch job with new status() "+batchConfigurationEntity);
			
			
			//Step 2 : update start time of job
			batchJobEntity = batchJobService.insertBatchJobByRow(batchConfigurationEntity.getId(),batchConfigurationEntity.getBatchType(), new Date(), null, null);
			logger.info("\n Batch Job inserted data in Batch Table by Batchtype Id" + batchJobEntity);
			
			
			logger.info("\n Batch Configuration data initialization has been completed, BatchJob :" + batchJobEntity);
		}
		catch(Exception ex) {
			logger.info("There is exception to process batchConfigDataInitialize()");
			ex.printStackTrace();
		}
		
		return batchJobEntity;
	}
	
	/**
	 * Insert new record into pg_transaction_refund_history table
	 * @param transactionRefundEntity
	 * @param txnId
	 * @param transactionEntityId
	 */
	
	public void insertRecordTransactionRefundHistory(TransactionRefundEntity transactionRefundEntity,String transactionEntityId) {
		TransactionRefundHistory transactionRefundHistory = new TransactionRefundHistory();
		transactionRefundHistory.setBankTxnId(transactionRefundEntity.getBankTxnId());
		transactionRefundHistory.setComment(transactionRefundEntity.getComment());
		transactionRefundHistory.setOrderId(transactionRefundEntity.getOrderId());
		transactionRefundHistory.setPgRefundTransId(transactionRefundEntity.getPgRefundTransId());///
		transactionRefundHistory.setRefundDate(new Date());
		transactionRefundHistory.setRefundStatus(transactionRefundEntity.getRefundStatus());
		if(transactionRefundEntity.getRefundAmount()!=null) {
			transactionRefundHistory.setRefundAmount(transactionRefundEntity.getRefundAmount());
		}
		else {
			transactionRefundHistory.setRefundAmount("0");
		}
		
		transactionRefundHistory.setTranscationType(transactionRefundEntity.getTranscationType());
		if(transactionRefundEntity.getTotalRefundAmount()!=null) {
			transactionRefundHistory.setTotalRefundAmount(transactionRefundEntity.getTotalRefundAmount());	
		}
		else {
			transactionRefundHistory.setTotalRefundAmount("0");
		}
		
		transactionRefundHistory.setTransactionRefId(transactionEntityId);
		transactionRefundHistory.setPaymentMode(transactionRefundEntity.getPaymentMode());
		transactionRefundHistory.setRespMsg(transactionRefundEntity.getRespMsg());
		transactionRefundHistory.setRefundId(transactionRefundEntity.getRefundId());
		transactionRefundHistory.setTransId(transactionRefundEntity.getTransId());
	

		try {
			transactionRefundDao.saveTransactionRefundHistory(transactionRefundHistory);
			logger.info("OrderId : "+transactionRefundHistory.getOrderId());
			logger.info("PgRefundTransId : "+transactionRefundHistory.getPgRefundTransId());
		} catch (Exception e) {
			logger.info("Error to insert record TransactionRefundHistory table");
			e.printStackTrace();
		}
	}
	
	/**
	 * Update data into pg_transaction table
	 * @param transactionEntity
	 */
	public void updateTransaction(TransactionEntity transactionEntity) {
		try {
			transactionDao.updateTransaction(transactionEntity);
		}
		catch(Exception ex) {
			logger.info("Error to update record into TransactionEntity table");
			ex.printStackTrace();
		}
	}
	
	public void updateTransaction(TransactionEntitySinglton transactionEntity) {
		try {
			transactionSingletonRepository.save(transactionEntity);
		}
		catch(Exception ex) {
			logger.info("Error to update record into TransactionEntity table");
			ex.printStackTrace();
		}
	}
	
	/**
	 * Build Payload against each REST API Call
	 * @param refundStatusObj
	 * @return TreeMap<String, String>
	 */
	//public abstract TreeMap<String, String> buildPayload(TransactionRefundEntity refundStatusObj);
	
	/**
	 * This method must be implemented by BatchService
	 */
	public abstract void process();

}
