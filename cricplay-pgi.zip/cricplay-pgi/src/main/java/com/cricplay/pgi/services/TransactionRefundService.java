package com.cricplay.pgi.services;

import java.util.List;
import java.util.Set;

import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.model.PGTxnUpdate;

public interface TransactionRefundService {

//	public TransactionRefundEntity createTransactionRefund(PGTxnUpdate pgTxnUpdate) throws Exception;

	public List<TransactionRefundEntity> findTransactionRefundByTransType(String transcationType, String refundStatus)
			throws Exception;

	public TransactionRefundEntity createTransactionRefund(PGTxnUpdate pgTxnUpdate,String orderType)throws Exception;
	
	public int saveTransactionRefund(TransactionEntity transactionEntity,String refundStatus) throws Exception;

//	public int saveTransactionRefund(TransactionEntitySinglton transactionEntity) throws Exception;

	public Set<TransactionRefundEntity> findTransactionRefundByRefundStatus(String refundStatus, String transactionType) throws Exception;
	
	
	public List<TransactionRefundEntity> findTransactionRefundByOderId(Integer orderId,String refundStatus);
	
	public int saveTransactionRefundHistory (TransactionEntity transactionEntity,String refundStatus) throws Exception;
}



