package com.cricplay.pgi.controller;

import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.model.Checksum;
import com.cricplay.pgi.model.TransactionRefund;
import com.paytm.pg.merchant.CheckSumServiceHelper;

@CrossOrigin
@RestController
@RequestMapping(value = "/cricplay/api/v1")
public class RefundController {

	public static final Logger LOGGER = Logger.getLogger(Checksum.class);

	@Autowired
	AppProperties appProperties;

	@Autowired
	RestTemplate restTemplate;

	@RequestMapping(value = "/refund-initiate", method = RequestMethod.POST, headers = "content-type=application/json")
	public String transactionRefund(HttpServletRequest request, @RequestBody TransactionRefund transactionRefund) {
		JSONObject responseData = new JSONObject();

		if (request.getHeader("Authorization") != null) {

			String transactionURL = "https://securegw-stage.paytm.in/refund/HANDLER_INTERNAL/REFUND";
			String merchantMid = transactionRefund.getMid();
			String orderId = transactionRefund.getOrderId();
			String merchantKey = appProperties.getMerchantKey();
			String transactionType = transactionRefund.getTxnType();
			String refundAmount = transactionRefund.getRefundAmount();
			String transactionId = transactionRefund.getTxnId();
			String refId = transactionRefund.getRefId();
//			String comment = "comment string optional";

			TreeMap<String, String> paytmParams = new TreeMap<String, String>();

			paytmParams.put("MID", merchantMid);
			paytmParams.put("REFID", refId);
			paytmParams.put("TXNID", transactionId);
			paytmParams.put("ORDERID", orderId);
			paytmParams.put("REFUNDAMOUNT", refundAmount);
			paytmParams.put("TXNTYPE", transactionType);
//			paytmParams.put("COMMENTS", comment);

			System.out.println("user paytm param \n" + paytmParams);
			try {
				String paytmChecksum = CheckSumServiceHelper.getCheckSumServiceHelper()
						.genrateRefundCheckSum(merchantKey, paytmParams);

				paytmParams.put("CHECKSUM", paytmChecksum);
				JSONObject responseObj = new JSONObject(paytmParams);
				String postData = responseObj.toString();
				System.out.append("Requested Json = " + postData + " ");

//		       HttpURLConnection connection = (HttpURLConnection) transactionURL.openConnection();

//			      URL url =  
//			               new URL(transactionURL);
//			                  HttpURLConnection connection =
//			                          (HttpURLConnection) url.openConnection();
//			                 
//			      connection.setRequestMethod("POST");
//			      connection.setRequestProperty("contentType", "application/json");
//			      connection.setUseCaches(false);
//			      connection.setDoOutput(true);
//
//			      DataOutputStream requestWriter = new DataOutputStream(connection.getOutputStream());
//			      requestWriter.writeBytes( postData);
//			      requestWriter.close();
//			      String responseData1 = "";
//			      InputStream is = connection.getInputStream();
//			      BufferedReader responseReader = new BufferedReader(new InputStreamReader(is));
//			      if((responseData1 = responseReader.readLine()) != null) {
//			          System.out.append("Response Data from paytm = " + responseData1);
//			      }
//			      responseReader.close();
//			      return responseData1;
//			   
				HttpEntity<String> payload = new HttpEntity<String>(postData);
				RestTemplate restTemplate = new RestTemplate();

				System.out.println("\n payload request " + payload);

				JSONObject responseRefund = new JSONObject();
				ResponseEntity<String> response = restTemplate.exchange(appProperties.getInternalRefundUrl(),
						HttpMethod.POST, payload, String.class);
				responseRefund = new JSONObject(response.getBody());
				System.out.println("\n status " + responseRefund);

				if (responseRefund.get("STATUS").equals("TXN_SUCCESS")) {
					responseData.put("status", responseRefund.get("STATUS"));
					responseData.put("message", "refund initiated successfully");
					responseData.put("response", responseRefund);
					responseData.put("statusCode", responseRefund.get("RESPCODE"));
				} else {
					responseData.put("status", responseRefund.get("STATUS"));
					responseData.put("message", responseRefund.get("RESPMSG"));
					responseData.put("response", responseRefund);
					responseData.put("statusCode", responseRefund.get("RESPCODE"));
				}

			} catch (Exception exception) {
				exception.printStackTrace();
			}

		} else {
			responseData.put("status", "FAILURE");
			responseData.put("message", "order doesn't exist");
			responseData.put("statusCode", 501);
		}
		return responseData.toString();

	}

	@RequestMapping(value = "/refund-status", method = RequestMethod.POST, headers = "content-type=application/json")
	public String transactionRefundStatus(HttpServletRequest request,
			@RequestBody TransactionRefund transactionRefund) {
		JSONObject responseData = new JSONObject();

		if (request.getHeader("Authorization") != null) {

			// String transactionStatusURL =
			// "https://securegw-stage.paytm.in/refund/HANDLER_INTERNAL/getRefundStatus";
			String merchantMid = transactionRefund.getMid();
			String orderId = transactionRefund.getMid();
			String merchantKey = appProperties.getMerchantKey();
			String refId = transactionRefund.getRefId();

			TreeMap<String, String> paytmParams = new TreeMap<String, String>();

			paytmParams.put("MID", merchantMid);
			paytmParams.put("REFID", refId);
			paytmParams.put("ORDERID", orderId);

			try {
				String paytmChecksum = CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(merchantKey,
						paytmParams);
				paytmParams.put("CHECKSUM", paytmChecksum);

				JSONObject responseObj = new JSONObject(paytmParams);

				String postData = "JsonData=" + responseObj.toString();
				System.out.append("Requested Json = " + postData + " ");

				HttpEntity<String> payload = new HttpEntity<String>(postData);
				RestTemplate restTemplate = new RestTemplate();

				JSONObject responseRefund = new JSONObject();

				ResponseEntity<String> response = restTemplate.exchange(appProperties.getInternalRefundStatusUrl(),
						HttpMethod.POST, payload, String.class);

				responseRefund = new JSONObject(response.getBody());
				System.out.println("\n status - " + responseRefund);

				if (responseRefund.get("ErrorCode").equals("331")) {
					responseData.put("status", "FAILURE");
					responseData.put("message", "refund status not fetched");
					responseData.put("response", responseRefund);
					responseData.put("statusCode", responseRefund.get("ErrorCode"));
				} else {
					responseData.put("status", "SUCCESS");
					responseData.put("message", "refund status fetched successfully");
					responseData.put("response", responseRefund);
					responseData.put("statusCode", responseRefund.get("status"));
				}

			} catch (Exception exception) {
				exception.printStackTrace();
			}

		} else {
			responseData.put("status", "FAILURE");
			responseData.put("message", "order doesn't exist");
			responseData.put("statusCode", 501);
		}
		return responseData.toString();

	}
	

}
