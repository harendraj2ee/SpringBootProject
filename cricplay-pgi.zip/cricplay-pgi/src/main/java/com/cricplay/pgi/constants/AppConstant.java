package com.cricplay.pgi.constants;

public class AppConstant {

	//public static final String merchantKey="1T0DOXgmyKRvSR2B";
	
//	public static final String merchantId="CRICTI63889900710694";
	
	public static final int INTERNAL_SERVER_ERROR = 500;
	
	public static final String CURRENCY_TYPE = "coin";
	
	public static final String INDUSTRY_TYPE = "Retail";


	public static final String countryCode = "IN";


	public enum NODE{
		
		APP("app"), BATCH("batch");
		
		private final String node;
		
		public String getValue() {
			return this.node;
		}
		
		private NODE(String node) {
			this.node = node;
		}
	}
	

	public enum EVENT_TYPE{
			
		PRO_WINNING_DEBIT("PRO_WINNING_DEBIT"), PRO_WINNING_REFUND("PRO_WINNING_REFUND"), PRO_COIN_CREDIT("PRO_COIN_CREDIT");
		
		private final String eventType;
		
		public String getValue() {
			return this.eventType;
		}
		
		private EVENT_TYPE(String eventType) {
			this.eventType = eventType;
		}
	}


	public enum TXN_STATUS{
		
		INITIATED("initiated"), SUCCESS("success"), FAIL("fail"), PENDING("pending");
		
		private final String transactionStatus;
		
		public String getValue() {
			return this.transactionStatus;
		}
		
		private TXN_STATUS(String transactionStatus) {
			this.transactionStatus = transactionStatus;
		}
	}				
	
	public enum TRANS_DESCRIPTION{
		INPROGRESS("Transaction in progress"), PENDING("Transaction in pending"),SUCCESS("Winnings is debited successfully"),FAIL("Transaction Failed");
		
		private final String description;
		
		public String getValue() {
			return this.description;
		}
		
		private TRANS_DESCRIPTION(String description) {
			this.description=description;
		}
	}
			
	public enum ORDER_STATUS{
		
		INITIATED("initiated"), SUCCESS("success"), FAIL("fail"),
		COIN_CREDIT_PENDING("coin credit pending"),REFUND_INITIATED("refund initiated"),
		REFUND_REQUESTED("RefundRequested"),REFUNDED("Refunded");
//		INITIATED("initiated"), SUCCESS("success"), FAIL("fail"), REFUND_REQUESTED("RefundRequested"), REFUNDED("Refunded");
		
		private final String orderStatus;
		
		public String getValue() {
			return this.orderStatus;
		}
		
		private ORDER_STATUS(String orderStatus) {
			this.orderStatus = orderStatus;
		}
	}	
	
	public enum JOB_TYPE{
		
		PGREFUND("PGREFUND"), PGREFUNDSTATUSCHECK("PGREFUNDSTATUSCHECK"), PGSTATUSCHECK("PGSTATUSCHECK"),
		WINNINGCREDIT("WINNINGCREDIT"), RECONCILECREDITPOINT("RECONCILECREDITPOINT");
		
		private final String jobType;
		
		public String getJobType() {
			return this.jobType;
		}
		
		private JOB_TYPE(String jobType) {
			this.jobType = jobType;
		}
	}	
			
	
	public enum ORDER_TYPE{
		
		WINNINGS_ONLY("WinningsOnly"), WINNING_AND_PG("WinningAndPG"), PG_ONLY("PgOnly");
		
		private final String orderType;
		
		public String getValue() {
			return this.orderType;
		}
		
		private ORDER_TYPE(String orderType) {
			this.orderType = orderType;
		}
	}
	
	public enum PAYMENT_TYPE{
		
		PG_PAYMENT_TYPE("PG"), WINNINGS_PAYMENT_TYPE("Winnings");
		
		private final String paymentType;
		
		private PAYMENT_TYPE(String paymentType) {
			this.paymentType=paymentType;
		}
		
		public String getValue() {
			return this.paymentType;
		}
	}
	
	public enum PG_TXN_STATUS{
		PG_SUCCESS("TXN_SUCCESS"), FAIL("TXN_FAILURE"), PENDING("PENDING");
		
		private final String pgTxnStatus;
		
		public String getValue() {
			return this.pgTxnStatus;
		}
		
		private PG_TXN_STATUS(String pgTxnStatus) {
			this.pgTxnStatus = pgTxnStatus;
		}
	}
	
	public enum PG_REFUND_STATUS{
		PG_REFUND_INITIATED("Initiated"), PG_REFUND_FAIL("Faild"), PG_REFUND_PENDING("Pending"), PG_REFUND_SUCCESS("Success"),WINNING_REFUND_INITIATED("Initiated");
		
		private final String pgRefundStatus;
		
		public String getValue() {
			return this.pgRefundStatus;
		}
		
		private PG_REFUND_STATUS(String pgRefundStatus) {
			this.pgRefundStatus = pgRefundStatus;
		}
	}
	
	public enum CLEVERTAP_EVENT{
		EVENT("event"),  EVENT_NAME("Purchase");
		
		private final String cleverTapEvent;

		public String getEventName() {
			return cleverTapEvent;
		}
		
		private CLEVERTAP_EVENT(String cleverTapEvent) {
			this.cleverTapEvent = cleverTapEvent;
		}
	}

	public enum PG_VENDOR{

		PAYTM("PAYTM"), SHAREIT("SHAREIT");

		private final String pgVendor;

		private PG_VENDOR(String pgVendor) {
			this.pgVendor=pgVendor;
		}

		public String getValue() {
			return this.pgVendor;
		}
	}

	public static String [] SHAREIT_CHECK_STATUS_RESPONSE_CODE={"PENDING","TXN_SUCCESS","TXN_FAILURE"};
}
