package com.cricplay.pgi.data.repository;

import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.TransDetailsEntity;

@Repository
public interface TransDetailsRepository extends JpaRepository<TransDetailsEntity, Integer>{

	@Transactional
	@Modifying()
	@Query(value ="INSERT INTO pg_transdetails(trandtl_id, trans_id, user_id, payment_type, created_on, modified_on, status, description,request_id,event_type) VALUES(?,?,?,?,?,?,?,?,?,?);", nativeQuery = true)
	int createPgTransDetails(Integer trandtlId,String transId,String userId,String paymentType,Date createdDate,Date modifiedDate,String status, String description,String requestId,String eventType);
	
}
