package com.cricplay.pgi.model;

import java.io.Serializable;

public class DebitCreditRequest implements Serializable{
	
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String requestId ;
	 String event;
	 String userId;
	 Double amount;
	 MetaData metadata;
	 
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public MetaData getMetadata() {
		return metadata;
	}
	public void setMetadata(MetaData metadata) {
		this.metadata = metadata;
	}
	
	@Override
	public String toString() {
		return "DebitCreditRequest [requestId=" + requestId + ", event=" + event + ", userId=" + userId + ", amount="
				+ amount + ", metadata=" + metadata + "]";
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}

}
