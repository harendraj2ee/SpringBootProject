package com.cricplay.pgi.util;
import java.io.ByteArrayOutputStream;

import java.util.Map;
import java.util.Set;


import com.fasterxml.jackson.databind.ObjectMapper;
public class StringUtils {
	public static String toJson(Object object) {
		ObjectMapper mapper = new ObjectMapper();
	    ByteArrayOutputStream bos=new ByteArrayOutputStream();
		try {
			mapper.writeValue(bos, object);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new String(bos.toByteArray());
	}


	public static String populateVariables(String str, Map<String,String> variablesMap) {

		Set<String> variablesMapKey=variablesMap.keySet();

		for (String key: variablesMapKey) {
			str=str.replace("$"+key,variablesMap.get(key));
		}

		return str;
	}

}
