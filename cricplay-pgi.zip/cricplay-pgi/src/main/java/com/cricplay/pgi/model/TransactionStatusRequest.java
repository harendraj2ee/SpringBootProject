package com.cricplay.pgi.model;

public class TransactionStatusRequest {
	
	private String MID;
	private String ORDERID;
	private String CHECKSUMHASH;
	
	public TransactionStatusRequest() {
		super();
	}
	
	public TransactionStatusRequest(String mID, String oRDERID, String cHECKSUMHASH) {
		MID = mID;
		ORDERID = oRDERID;
		CHECKSUMHASH = cHECKSUMHASH;
	}
	
	public String getMID() {
		return MID;
	}
	public void setMID(String mID) {
		MID = mID;
	}
	public String getORDERID() {
		return ORDERID;
	}
	public void setORDERID(String oRDERID) {
		ORDERID = oRDERID;
	}
	public String getCHECKSUMHASH() {
		return CHECKSUMHASH;
	}
	public void setCHECKSUMHASH(String cHECKSUMHASH) {
		CHECKSUMHASH = cHECKSUMHASH;
	}
	
	@Override
	public String toString() {
		return "TransactionStatusRequest [MID=" + MID + ", ORDERID=" + ORDERID + ", CHECKSUMHASH=" + CHECKSUMHASH + "]";
	}
	
	
	
}
