package com.cricplay.pgi.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.repository.PlanRepository;

@Repository
public class PlanDaoImpl implements PlanDao{
	
	@Autowired
	PlanRepository planRepository;

	@Override
	public PlanEntity getPlanById(Integer id) {
		
		PlanEntity planEntity=planRepository.getOne(id);
		
		return planEntity;
	}

}
