package com.cricplay.pgi.data.repository;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.OrderStatusEntity;
import com.cricplay.pgi.model.OrderModel;


@Repository
public interface OrderRepository extends JpaRepository<OrderEntity, Integer>{

	@Query(value = "SELECT * FROM pg_order where order_id=?", nativeQuery = true)
	OrderEntity findOrderById(Integer orderId);
	
	@Query(value = "SELECT * FROM pg_order where status=?", nativeQuery = true)
	List<OrderStatusEntity> findOrderListByStatus(String  status);
	
/*	@Transactional
	@Modifying()
	@Query(value ="update pg_order set status=? where order_id=?", nativeQuery = true)
<<<<<<< HEAD
	int updateOrderStatusById(String status,Integer orderId);
	
//	@Query(value = "SELECT * FROM pg_order where status=?", nativeQuery = true)
//	OrderEntity findOrderByStatus(String status);	
	
	
=======
	int updateOrderStatusById(String status,Integer orderId);*/
	
	@Transactional
	@Modifying()
	@Query(value ="update pg_order set status=?, modified_on=? where order_id=?", nativeQuery = true)
	Integer updateOrderStatusById(String status,Date date,Integer orderId);
	
	@Transactional
	@Modifying()
	@Query(value ="update pg_order set credit_coin_request_id=?, modified_on=? where order_id=?", nativeQuery = true)
	Integer updateOrder(String coinCreditReqId, Date date,Integer orderId);

	
	@Query(value = "select ord.order_id,ord.plan_id,p.plan_name,ord.status,ord.created_on,ord.modified_on,ord.price,ord.coins,  (select amount from cricplay.pg_transaction where order_id=ord.order_id and payment_type='PG' ) as amountPaidByPG, (select amount from cricplay.pg_transaction where order_id=ord.order_id and payment_type='Winnings' ) as winningBalanceUsed from cricplay.pg_order ord join cricplay.pg_plan p on ord.plan_id=p.plan_id where ord.order_id=?  and ord.user_id=?", nativeQuery = true)
	Object getOrderStatus(Integer orderId,String userId);
	
	@Query(value = "SELECT * FROM pg_order where status=?", nativeQuery = true)
	List<OrderEntity> findOrderByStatus(String status);
}
