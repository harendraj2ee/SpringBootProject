package com.cricplay.pgi.notification;

import com.cricplay.pgi.util.StringUtils;

import java.io.Serializable;
import java.util.Map;

public class NotificationRequest implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String event;
    private String userId;
    private String language;
    private Integer orderId;

    private Map<String,String> variablesMap;

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public Map<String, String> getVariablesMap() {
        return variablesMap;
    }

    public void setVariablesMap(Map<String, String> variablesMap) {
        this.variablesMap = variablesMap;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    @Override
    public String toString() {
        return StringUtils.toJson(this);
    }
}
