package com.cricplay.pgi.component;

import java.time.Instant;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;

import com.cricplay.pgi.clevertap.model.CleverTap;
import com.cricplay.pgi.clevertap.model.CleverTapEvtDataRequest;
import com.cricplay.pgi.clevertap.model.CleverTapRootObject;
import com.cricplay.pgi.clevertap.model.EvtData;
import com.cricplay.pgi.constants.AppConstant;

@Component
public class CleverTapPayloadBuilder {
	
	public static final Logger LOGGER = Logger.getLogger(CleverTapPayloadBuilder.class);
	
	/**
	 * 
	 * @param evtDataRequest
	 * @param userUniqueId
	 * @return payload for clever tap event upload
	 */
	public CleverTap buildCleverTapPayload(CleverTapEvtDataRequest evtDataRequest,String uniqueUserId) {
		LOGGER.info("build payload for buildCleverTapPayload start...");


		EvtData evtdata= new EvtData();
		evtdata.setStatus(evtDataRequest.getStatus());
		evtdata.setAmount(evtDataRequest.getAmount());
		evtdata.setDesc(evtDataRequest.getDesc());
		evtdata.setPlanId(evtDataRequest.getPlanId());
		evtdata.setPgAmount(evtDataRequest.getPgAmount());
		evtdata.setWinAmount(evtDataRequest.getWinAmount());
		
		CleverTap data= new CleverTap();
		CleverTapRootObject obj=new CleverTapRootObject();
		obj.setFBID(uniqueUserId);
		obj.setTs(Instant.now().getEpochSecond());
		obj.setType(AppConstant.CLEVERTAP_EVENT.EVENT.getEventName());
		obj.setEvtName(AppConstant.CLEVERTAP_EVENT.EVENT_NAME.getEventName());
		obj.setEvtData(evtdata);
		ArrayList<CleverTapRootObject> list= new ArrayList<CleverTapRootObject>();
		list.add(obj);
		data.setD(list);
		
		LOGGER.debug("Payload for CleverTapUpload ::"+data);
		return data;

	}
	
}
