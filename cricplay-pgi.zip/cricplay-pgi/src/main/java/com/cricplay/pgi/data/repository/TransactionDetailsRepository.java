package com.cricplay.pgi.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cricplay.pgi.data.entity.TransDetailsEntitySinglton;

public interface TransactionDetailsRepository extends JpaRepository<TransDetailsEntitySinglton, Integer>{

}
