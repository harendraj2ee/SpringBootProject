package com.cricplay.pgi.dao;

import java.util.Date;

import com.cricplay.pgi.data.entity.BatchJobEntity;

public interface BatchJobDao {
	
	public BatchJobEntity findBatchJobByBatchTypeId(Integer batchTypeId) throws Exception;
	
	public BatchJobEntity InsertBatchJobByRow(Integer batchTypeId, String batchType, Date startedOn, Date completedOn, String batchSize) throws Exception;
	
	public BatchJobEntity updateBatchJobByRow(Integer batchSize, Integer id) throws Exception;

}
