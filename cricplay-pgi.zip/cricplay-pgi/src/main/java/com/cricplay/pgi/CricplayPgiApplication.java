package com.cricplay.pgi;

import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricplayPgiApplication {

	public static final Logger LOGGER = Logger.getLogger(CricplayPgiApplication.class);
	public static void main(String[] args) {
		
		LOGGER.info("Rolling the pitch...");
		SpringApplication.run(CricplayPgiApplication.class, args);
	}

}
