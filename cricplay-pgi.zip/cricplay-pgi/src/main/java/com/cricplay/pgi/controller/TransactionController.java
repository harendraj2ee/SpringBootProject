package com.cricplay.pgi.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cricplay.pgi.common.DaoMessages;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;
import com.cricplay.pgi.model.PGTxnUpdate;
import com.cricplay.pgi.model.PGTxnUpdateResponse;
import com.cricplay.pgi.notification.NotificationRequest;
import com.cricplay.pgi.notification.Notifier;
import com.cricplay.pgi.services.CoinCreditProcess;
import com.cricplay.pgi.services.CreateOrderService;
import com.cricplay.pgi.services.CreateTransDetailService;
import com.cricplay.pgi.services.TransactionRefundService;
import com.cricplay.pgi.services.TransactionUpdateService;
import com.cricplay.pgi.util.CommonUtil;

/**
 * 
 * @author infinity labs
 *
 */
@CrossOrigin
@RestController
@RequestMapping(value = "/cricplay/api/v1")
public class TransactionController {

	public static final Logger LOGGER = Logger.getLogger(TransactionController.class);

	@Value("${node}")
	private String node;

	@Autowired
	TransactionUpdateService transactionUpdateService;

	@Autowired
	CreateTransDetailService createTransDetailService;

	@Autowired
	CreateOrderService createOrderService;

	@Autowired
	TransactionRefundService transactionRefundService;
	
	
	@Autowired
	CoinCreditProcess coinCreditProcess;
	
    @Autowired
    TransactionDao transactionDao;
    
    @Autowired
    OrderDao orderDao;
    
	@Autowired
	Notifier smsNotifier;
	

	/**
	 * 
	 * @param pgTxnUpdate
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/transaction-update", method = RequestMethod.PUT, headers = "Accept=application/json")
	public @ResponseBody PGTxnUpdateResponse updatePgTransaciton(@RequestBody PGTxnUpdate pgTxnUpdate,HttpServletRequest request)
			throws Exception {

		LOGGER.info("\n updatePgTransaciton start...");
		String language= request.getHeader("language");
		
		PGTxnUpdateResponse response = new PGTxnUpdateResponse();

		if (StringUtils.isNotBlank(node) && node.equalsIgnoreCase(AppConstant.NODE.APP.getValue())) {
			
			OrderEntity orderEntity = createOrderService.findOrderById(pgTxnUpdate.getOrderId());
			
			//shareit transaction handling.(pgVender constant value will be in AppConstant)
			Integer pgTransId = transactionUpdateService.findTransactionIdByOrderIdAndPaymentType(pgTxnUpdate.getOrderId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
			Integer winningTransId =transactionUpdateService.findTransactionIdByOrderIdAndPaymentType(pgTxnUpdate.getOrderId(),AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
			TransactionEntity transactionEntity=transactionUpdateService.findTransactionByOrderIdAndPaymentType(pgTxnUpdate.getOrderId(), AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
			
			String requestId=CommonUtil.generateRequestId(orderEntity.getOrderId());
			
			// new entry in transaction detail table
			//createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),requestId,AppConstant.EVENT_TYPE.PRO_COIN_CREDIT.getValue());
			// PRO CREDIT is required when refund is needed.
			//createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),null,null);
			//update pg_transaction table according to order_id and payment_type as PG
			Integer count = transactionUpdateService.updatePgTransaction(pgTxnUpdate, transactionEntity,pgTxnUpdate.getOrderId(),
					AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
			if (count == 1) {
				if(orderEntity.getStatus().equalsIgnoreCase("initiated")) {
					if (pgTxnUpdate.getPgTransaction().getStatus().equalsIgnoreCase("TXN_SUCCESS")) {

					int respCode=0;
					
					// build payload for coin credit cricplay api	
					// DebitCreditRequest debitCreditRequest=buildDebitCreditRequest(orderEntity, requestId);
					
					// call coin credit process
					 respCode=coinCreditProcess.initiateCoinCreditProcess(orderEntity,language);
					 
					 //steps for making transaction update response
					 //fetch orderEntity
					 OrderEntity orderEnityUpdated= createOrderService.findOrderById(orderEntity.getOrderId());
					 
					 if(respCode==200) { // insert new entry in pg_transdetails and success response for transaction update api
						 
						 	//createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),requestId,AppConstant.EVENT_TYPE.PRO_COIN_CREDIT.getValue());
						 	transactionUpdateService.updateTransactionStatusById(AppConstant.TXN_STATUS.SUCCESS.getValue(),AppConstant.TRANS_DESCRIPTION.SUCCESS.getValue(),
									new Date(), winningTransId);

						 	if(orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue()) || orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.PG_ONLY.getValue())){
								createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),null,null);
							}
						 	/*if(orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue()) || orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNINGS_ONLY.getValue())) {
								createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(), AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue(), null, null);
							}*/

							PGTxnUpdateResponse pgUpdateResp = new PGTxnUpdateResponse();
							pgUpdateResp.setStatusCode(DaoMessages.FIND_SUCCESS.getCode());
							pgUpdateResp.setOrderCreationDate(orderEnityUpdated.getCreatedOn());
							pgUpdateResp.setTransactionId(pgTransId);
							pgUpdateResp.setOrderStatus(AppConstant.ORDER_STATUS.SUCCESS.getValue());
							pgUpdateResp.setOrderId(pgTxnUpdate.getOrderId());
							pgUpdateResp.setMessage("Order Success");// procure customize message from database
							pgUpdateResp.setOrderModidyDate(new Date());
							return pgUpdateResp;
						 
					 }
					 else {//other than success response for transaction update api
					 // if respCode is not 200 then .... proper handling needed.
						 pgTxnUpdate.getPgTransaction().setStatus(AppConstant.ORDER_STATUS.COIN_CREDIT_PENDING.getValue());
						 //update order table with status coin credit pending.
						 orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.COIN_CREDIT_PENDING.getValue(), new Date(), orderEnityUpdated.getOrderId());
						 // insert new entry in transaction details table for status coin credit pending
						// createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),requestId,AppConstant.EVENT_TYPE.PRO_COIN_CREDIT.getValue());
						 	createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),null,null);
						 // build response and return
						 	PGTxnUpdateResponse pgUpdateResp = new PGTxnUpdateResponse();
						 	pgUpdateResp.setTransactionId(pgTransId);
							pgUpdateResp.setOrderStatus(AppConstant.ORDER_STATUS.COIN_CREDIT_PENDING.getValue());
							pgUpdateResp.setStatusCode(DaoMessages.FIND_SUCCESS.getCode());
							pgUpdateResp.setOrderId(pgTxnUpdate.getOrderId());
							pgUpdateResp.setMessage("Coin credit pending");// procure customize message from database
							pgUpdateResp.setOrderModidyDate(new Date());
							return pgUpdateResp;
					 }

				} 
				// if transaction status is failed.
				else if (pgTxnUpdate.getPgTransaction().getStatus().equalsIgnoreCase("TXN_FAILURE")) {
					
					// insert entry in transdetails table.
				 	if(orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue()) || orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.PG_ONLY.getValue())){
						createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),null,null);
					}
/*				 	if(orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue()) || orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNINGS_ONLY.getValue())) {
						createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(), AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue(), null, null);
					}*/

					/**
					 * IF(OrderType=="Winning & PG") { Insert into TransactionRefund Table for
					 * WinningCredit } Return to Order Summary
					 * 
					 */
					/*TransactionRefundEntity transactionEntity = transactionRefundService
							.createTransactionRefund(pgTxnUpdate);*/
					
					if(orderEntity.getOrderType().equalsIgnoreCase(AppConstant.ORDER_TYPE.PG_ONLY.getValue())) {
						
						// update order status to fail.
						orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.FAIL.getValue(), new Date(), pgTxnUpdate.getOrderId());
						
						createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),null,null);
						// response according to order status fail.
						PGTxnUpdateResponse pgUpdateResp = new PGTxnUpdateResponse();
						pgUpdateResp.setTransactionId(pgTransId);
						pgUpdateResp.setOrderStatus(AppConstant.ORDER_STATUS.FAIL.getValue());
						pgUpdateResp.setOrderId(pgTxnUpdate.getOrderId());
						pgUpdateResp.setMessage("Order Fail(To be customized)");
						pgUpdateResp.setOrderModidyDate(new Date());
						
						return pgUpdateResp;
						
					}
					
					TransactionEntity transactionWinning=transactionDao.findTransByOrderIdAndPaymentType(orderEntity.getOrderId(), AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
					int saveCount=0;
						saveCount=transactionRefundService.saveTransactionRefund(transactionWinning,AppConstant.PG_REFUND_STATUS.PG_REFUND_INITIATED.getValue());
								  transactionRefundService.saveTransactionRefundHistory(transactionWinning,AppConstant.PG_REFUND_STATUS.PG_REFUND_INITIATED.getValue());
						// update order status as refund initiated.
						orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.REFUND_INITIATED.getValue(), new Date(), pgTxnUpdate.getOrderId());
						sendSms(orderEntity.getUserId(),language,orderEntity.getOrderId());
						if(saveCount==1) {
							// successfully inserted record in pg_transaction_refund table with refund status Initiated
							PGTxnUpdateResponse pgUpdateResp = new PGTxnUpdateResponse();
							pgUpdateResp.setTransactionId(pgTransId);
							pgUpdateResp.setOrderStatus(AppConstant.ORDER_STATUS.REFUND_INITIATED.getValue());
							pgUpdateResp.setOrderId(pgTxnUpdate.getOrderId());
							pgUpdateResp.setMessage("Order refund initiated)");//TODO need the message from db.
							pgUpdateResp.setOrderModidyDate(new Date());
							
							return pgUpdateResp;
							
						}
						else {
							LOGGER.info("\n update transaction failed.");
							PGTxnUpdateResponse pgUpdateResponse = new PGTxnUpdateResponse();
							pgUpdateResponse.setMessage("update transaciton failed.");//TODO need the message from db.
							pgUpdateResponse.setStatusCode(500);
							return pgUpdateResponse;
							
						}
				
					
				} 
				// if transaction status is pending.
				else if (pgTxnUpdate.getPgTransaction().getStatus()
						.equalsIgnoreCase(AppConstant.PG_TXN_STATUS.PENDING.getValue())) {
					/**
					 * Update Transaction Status=Pending Return to Order Summary
					 */
					transactionUpdateService.updateTransactionStatusById(AppConstant.PG_TXN_STATUS.PENDING.getValue(),AppConstant.TRANS_DESCRIPTION.PENDING.getValue(),
							new Date(), pgTransId);
					
				 	if(orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue()) || orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.PG_ONLY.getValue())){
						createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(),AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(),null,null);
					}
				 	/*if(orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue()) || orderEntity.getOrderType().equals(AppConstant.ORDER_TYPE.WINNINGS_ONLY.getValue())) {
						createTransDetailService.createTransDetail(pgTxnUpdate, orderEntity.getUserId(), AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue(), null, null);
					}*/

					PGTxnUpdateResponse pgUpdateResponse = new PGTxnUpdateResponse();
					pgUpdateResponse.setTransactionId(pgTransId);
					pgUpdateResponse.setOrderStatus(AppConstant.PG_TXN_STATUS.PENDING.getValue());
					pgUpdateResponse.setOrderId(pgTxnUpdate.getOrderId());
					pgUpdateResponse.setOrderCreationDate(orderEntity.getCreatedOn());
					pgUpdateResponse.setMessage("Order Pending on PG");//TODO need the message from db.
					pgUpdateResponse.setOrderModidyDate(new Date());

					return pgUpdateResponse;
				}

			}
			}
			else if (count == 0) {

				// logging the error
				// return order summary response with error code and customize error msg
				LOGGER.info("\n update transaction failed.");
				PGTxnUpdateResponse pgUpdateResponse = new PGTxnUpdateResponse();
				pgUpdateResponse.setMessage("update transaciton failed.");//TODO need the message from db.
				pgUpdateResponse.setStatusCode(500);
				return pgUpdateResponse;
			}

		}
		return response;
	}
	
	/**
	 * 
	 * @param userId
	 * @param language
	 * @param orderId
	 * @throws Exception
	 */
	public void sendSms(String userId,String language,Integer orderId) throws Exception{
		
		NotificationRequest notificationRequest=new NotificationRequest();
		notificationRequest.setEvent("EVENT_SMS_ORDER_PG_FAILED");
		notificationRequest.setUserId(userId);
		notificationRequest.setLanguage(language);
		notificationRequest.setOrderId(orderId);
		Map<String,String> variablesMap=new HashMap<>();

		notificationRequest.setVariablesMap(variablesMap);

		smsNotifier.notify(notificationRequest);
	}

}
