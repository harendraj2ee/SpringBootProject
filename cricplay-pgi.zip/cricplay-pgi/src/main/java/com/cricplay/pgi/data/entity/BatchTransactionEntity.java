package com.cricplay.pgi.data.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.cricplay.pgi.util.StringUtils;

@Entity
@Table(name="pg_batch_transaction")
public class BatchTransactionEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", updatable = false, nullable = false)
	private Integer id;
	
	@Column(name="batch_job_id")
	private Double batchJobId;
	
	@Column(name="order_id")
	private Double orderId;
	
	@Column(name="transaction_id")
	private Integer transactionId;
	
	@Column(name="transaction_type")
	private String transactionType;
	
	@Column(name="created_on")
	private Date cretedOn;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Double getBatchJobId() {
		return batchJobId;
	}

	public void setBatchJobId(Double batchJobId) {
		this.batchJobId = batchJobId;
	}

	public Double getOrderId() {
		return orderId;
	}

	public void setOrderId(Double orderId) {
		this.orderId = orderId;
	}

	public Integer getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Integer transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getCretedOn() {
		return cretedOn;
	}

	public void setCretedOn(Date cretedOn) {
		this.cretedOn = cretedOn;
	}
	
	@Override
	public String toString() {
		return StringUtils.toJson(this);
	}
}
