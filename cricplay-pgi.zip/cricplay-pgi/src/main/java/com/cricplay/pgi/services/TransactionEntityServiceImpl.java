package com.cricplay.pgi.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;

@Service
public class TransactionEntityServiceImpl implements TransactionEntityService{
	
	
	@Autowired
	TransactionDao transactionDao;
	

	@Override
	public List<TransactionEntitySinglton> findTransactionByOrderId(Integer orderId) {
		
		return transactionDao.findTransactionByOrderId(orderId);
	}

}
