package com.cricplay.pgi.common;

public enum DaoMessages {
	
	COULD_NOT_FIND(5001,"Could not find"),
	FIND_SUCCESS(200,"Find success"),
	FIND_ERROR(5002,"Error while fetching record"),
	BAD_REQUEST(400, "Bad Request");
	
	
	int code;
	String message;
	
	private DaoMessages(int code,String message) {
		this.code=code;
		this.message=message;
	}

	public int getCode() {
		return code;
	}

	public String getMessage() {
		return message;
	}

}
