package com.cricplay.pgi.sms;

import com.cricplay.pgi.model.SmsRequest;

public interface ICricPlaySmsService {
	
	public String pushSms(SmsRequest request);

}
