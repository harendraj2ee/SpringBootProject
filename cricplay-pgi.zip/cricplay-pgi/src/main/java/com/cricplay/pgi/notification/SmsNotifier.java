package com.cricplay.pgi.notification;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.data.entity.LanguagePlaceholderEntity;
import com.cricplay.pgi.data.entity.SmsSentEntity;
import com.cricplay.pgi.data.repository.LanguagePlaceholderRepository;
import com.cricplay.pgi.data.repository.SmsSentRepository;
import com.cricplay.pgi.model.SmsRequest;
import com.cricplay.pgi.util.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.nio.charset.Charset;

@Component
public class SmsNotifier implements Notifier {

    public static final Logger LOGGER = Logger.getLogger(SmsNotifier.class);
    private static final String SUCCESS = "SUCCESS";
    private static final String FAILURE = "FAILURE";
    @Autowired
    RestTemplate restTemplate;
    @Autowired
    AppProperties appProperties;
    @Autowired
    LanguagePlaceholderRepository languagePlaceholderRepository;
    @Autowired
    SmsSentRepository smsSentRepository;

    /**
     * get the sms content based on user language, send sms notification and save the response in db.
     *
     * @param notificationRequest
     * @return
     */
    @Override
    public boolean notify(NotificationRequest notificationRequest) throws Exception {

        LOGGER.info("Sms notification request received ::" + notificationRequest);
        try {
            //1.fetch the sms content form db.
            if(org.springframework.util.StringUtils.isEmpty(notificationRequest.getLanguage())){
                notificationRequest.setLanguage("en");
            }
            LanguagePlaceholderEntity languagePlaceholderEntity = languagePlaceholderRepository.getPlaceholderByEventLangType(
                    notificationRequest.getEvent(), notificationRequest.getLanguage(), "SMS");

            if (languagePlaceholderEntity == null) {
                LOGGER.error("No placeholder found for ::" + notificationRequest);
                throw new Exception("No placeholder found for ::" + notificationRequest);
            }
            String message = StringUtils.populateVariables(languagePlaceholderEntity.getMessage(), notificationRequest.getVariablesMap());

            //2.call api to push sms
            SmsRequest smsRequest = new SmsRequest(notificationRequest.getUserId(), message);

            String response = "";
            SmsSentEntity smsSentEntity = new SmsSentEntity();
            try {
                response = pushSms(smsRequest);

                smsSentEntity.setSmsResponse(response);
                smsSentEntity.setStatus(SUCCESS);

            } catch (Exception e) {
                LOGGER.error("Sms api returns failure ::", e);
                smsSentEntity.setStatus(FAILURE);
            }

            //3.dump the response in db.

            smsSentEntity.setEvent(notificationRequest.getEvent());
            smsSentEntity.setUserId(notificationRequest.getUserId());
            smsSentEntity.setLanguage(notificationRequest.getLanguage());
            smsSentEntity.setOrderId(notificationRequest.getOrderId());
            smsSentRepository.save(smsSentEntity);

        } catch (Exception e) {
            LOGGER.error("Sms notification failed ::", e);
            return false;
        }
        return true;

    }


    /**
     * send request to sms api
     *
     * @param smsRequest
     * @return
     * @throws Exception
     */
    private String pushSms(SmsRequest smsRequest) throws Exception {
        LOGGER.info("pushSms service start...");

        JSONObject obj = new JSONObject(smsRequest);
        String strJson = obj.toString();
        LOGGER.debug("\n Payload for pushSms ::" + strJson);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(new MediaType("application","json", Charset.forName("UTF-8")));

        HttpEntity<String> request = new HttpEntity<String>(strJson, headers);
        ResponseEntity<String> response = restTemplate.postForEntity(appProperties.getCricPlaySmsUrl(), request, String.class);
        LOGGER.info("Response from pushSms service ::" + response.getStatusCodeValue() + "::" + response.getStatusCode());
        return response.getBody().toString();
    }

}
