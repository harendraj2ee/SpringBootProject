/**
 * Copyright @2018 By JavaHubLive.com
 *
 * All rights reserved. The source code is proprietary of JavaHubLive.com. 
 * The source code may not be reproduced or modify to any persons or third party entities
 * without prior notice to JavaHubLive.com.
 *
 * Created on 10-Mar-2019
 *
 * Last edited by:      Ganesh Kumar
 *             on:      10-Mar-2019 : 12:25:37 am
 *       Filename:      ReconcileCreditPointService.java
 * 
 */

package com.cricplay.pgi.Jobs;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.constants.AppConstant.ORDER_STATUS;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.repository.OrderRepository;
import com.cricplay.pgi.data.repository.TransactionRefundRepository;
import com.cricplay.pgi.model.CoinCreditResponse;
import com.cricplay.pgi.model.CurrencyStatusCheckResponse;
import com.cricplay.pgi.model.DebitCreditRequest;
import com.cricplay.pgi.notification.NotificationRequest;
import com.cricplay.pgi.notification.Notifier;
import com.cricplay.pgi.services.BatchConfigurationService;
import com.cricplay.pgi.services.CoinCreditProcess;
import com.cricplay.pgi.services.CoinCreditService;
import com.cricplay.pgi.services.CurrencyCheckSevice;
import com.cricplay.pgi.services.OrderSummaryService;
import com.cricplay.pgi.util.CommonUtil;

@Transactional
@Service
public class ReconcileCreditPointService extends BatchService {

	private static final Logger logger = Logger.getLogger(ReconcileCreditPointService.class);

	@Value("${cricplay.pgi.credit.coin.batch.rerty.threshold}")
	private Integer batchRetryThreshold;

	@Autowired
	private BatchConfigurationService batchConfigurationService;

	@Autowired
	private CoinCreditService coinCreditService;

	@Autowired
	private CoinCreditProcess coinCreditProcess;

	@Autowired
	private OrderSummaryService orderService;

	@Autowired
	private OrderDao orderDao;

	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private CurrencyCheckSevice currencyCheckService;

	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private TransactionRefundRepository transactionRefundRepository;

	@Autowired
	Notifier smsNotifier;

	@Override
	public void process() {

		BatchJobEntity batchJobEntity = null;

		// Step 1: Get active batch for ReconcileCreditPoint (CoinCredit)
		try {
			// TODO : Check with anuj value => CoinCredit or RECONCILECREDITPOINT
			BatchConfigurationEntity batchConfigurationEntity = batchConfigurationService
					.findBatchConfigurationByType(AppConstant.JOB_TYPE.RECONCILECREDITPOINT.getJobType());

			logger.info("\n Batch Configruation enity list data " + batchConfigurationEntity);
			// Step 2 : Trigger process if the current status is not in "Running"
			if (!RUNNING_STATUS.equalsIgnoreCase(batchConfigurationEntity.getCurrentStatus())) {

				// batchJobEntity = batchConfigDataInitialize(RUNNING_STATUS,
				// batchConfigurationEntity);

				// Step 3: Get list of Pg_Order table records if
				// PG_Order.status=CoinCreditPending
				List<OrderEntity> pgOrderList = orderService
						.findOrderByStatus(AppConstant.ORDER_STATUS.COIN_CREDIT_PENDING.getValue());

				if (pgOrderList.size() > 0) {
					batchJobEntity = batchConfigDataInitialize(RUNNING_STATUS, batchConfigurationEntity);

					// Step 4 : Iterate each order Entity and Credit points
					for (OrderEntity orderEntity : pgOrderList) {
						// Step 5: Call Rest API
						String requestIdFromOrder = orderEntity.getCreditCoinReqId();
						logger.info("ger request id " + requestIdFromOrder);
						if (!StringUtils.isEmpty(requestIdFromOrder)) {
					
							ResponseEntity<CurrencyStatusCheckResponse> currencyCheckResponse = currencyCheckService
									.currencyStatusCheck(requestIdFromOrder);
							// checking if requestId exist in previous coin credit request
							if (currencyCheckResponse != null && currencyCheckResponse.getStatusCodeValue() == 200) {
								orderEntity.setStatus(ORDER_STATUS.SUCCESS.getValue());
								orderEntity.setModifiedOn(new Date());
								orderRepository.save(orderEntity);

								// TODO: SMS needs to trigger here
								sendSms(orderEntity.getUserId(), "en", orderEntity);
							}
							
							if (batchRetryThreshold >= orderEntity.getRetryCounter()) {
								orderEntity.setRetryCounter(orderEntity.getRetryCounter() + 1);
								orderEntity.setModifiedOn(new Date());
								orderRepository.save(orderEntity);
							}
							else {
								// Insert new record into transactionRefunt table and update status into order
								// table.
								if (orderEntity.getOrderType()
										.equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNINGS_ONLY.getValue())) {

									List<TransactionEntity> transactionList = transactionDao.findTransactionEntity(
											orderEntity.getOrderId(),
											AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
									if (!transactionList.isEmpty()) {
										processRefundInitiated(orderEntity, transactionList.get(0));
									}

								} // refund entry with winning case end.

								// refund entry with PG case start --->
								else if (orderEntity.getOrderType()
										.equalsIgnoreCase(AppConstant.ORDER_TYPE.PG_ONLY.getValue())) {

									List<TransactionEntity> transactionList = transactionDao.findTransactionEntity(
											orderEntity.getOrderId(),
											AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
									if (!transactionList.isEmpty()) {
										processRefundInitiated(orderEntity, transactionList.get(0));
									}

								} // refund entry with PG case end.

								// refund entry with winning and pg case start--->
								else if (orderEntity.getOrderType()
										.equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue())) {

									List<TransactionEntity> pgtransactionList = transactionDao
											.findTransactionEntity(orderEntity.getOrderId(),
													AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
									if (!pgtransactionList.isEmpty()) {
										processRefundInitiated(orderEntity, pgtransactionList.get(0));
									}
								}

								List<TransactionEntity> winningtransactionList = transactionDao
										.findTransactionEntity(orderEntity.getOrderId(),
												AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
								if (!winningtransactionList.isEmpty()) {
									processRefundInitiated(orderEntity, winningtransactionList.get(0));
								}
							}

						}
						// Create new requestId if not exists
						else {
							String requestId = CommonUtil.generateRequestId(orderEntity.getOrderId());
							orderEntity.setCreditCoinReqId(requestId);
							orderEntity.setModifiedOn(new Date());
							orderRepository.save(orderEntity);

							DebitCreditRequest request = coinCreditProcess.buildDebitCreditRequest(orderEntity,
									requestId);

							ResponseEntity<CoinCreditResponse> response = coinCreditService.creditCoin(request);

							// update pg_order status="sucess" with modified date.
							if (response != null && response.getStatusCodeValue() == 200) {
								orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.SUCCESS.getValue(), new Date(),
										orderEntity.getOrderId());

								// TODO: SMS needs to trigger here

								sendSms(orderEntity.getUserId(), "en", orderEntity);

							} else {

								if (batchRetryThreshold >= orderEntity.getRetryCounter()) {
									orderEntity.setRetryCounter(orderEntity.getRetryCounter() + 1);
								} else {

									// Insert new record into transactionRefunt table and update status into order
									// table.
									if (orderEntity.getOrderType()
											.equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNINGS_ONLY.getValue())) {

										List<TransactionEntity> transactionList = transactionDao.findTransactionEntity(
												orderEntity.getOrderId(),
												AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
										if (!transactionList.isEmpty()) {
											processRefundInitiated(orderEntity, transactionList.get(0));
										}

									} // refund entry with winning case end.

									// refund entry with PG case start --->
									else if (orderEntity.getOrderType()
											.equalsIgnoreCase(AppConstant.ORDER_TYPE.PG_ONLY.getValue())) {

										List<TransactionEntity> transactionList = transactionDao.findTransactionEntity(
												orderEntity.getOrderId(),
												AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
										if (!transactionList.isEmpty()) {
											processRefundInitiated(orderEntity, transactionList.get(0));
										}

									} // refund entry with PG case end.

									// refund entry with winning and pg case start--->
									else if (orderEntity.getOrderType()
											.equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue())) {

										List<TransactionEntity> pgtransactionList = transactionDao
												.findTransactionEntity(orderEntity.getOrderId(),
														AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
										if (!pgtransactionList.isEmpty()) {
											processRefundInitiated(orderEntity, pgtransactionList.get(0));
										}
									}

									List<TransactionEntity> winningtransactionList = transactionDao
											.findTransactionEntity(orderEntity.getOrderId(),
													AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
									if (!winningtransactionList.isEmpty()) {
										processRefundInitiated(orderEntity, winningtransactionList.get(0));
									}
								} // refund entry with winning and pg case end.

							}
						}

					}

					if (batchJobEntity != null) {
						batchConfigStatusUpdate(batchJobEntity, pgOrderList.size(), batchConfigurationEntity);
					} else {
						logger.debug("batchJobEntity null...");
					}
				}

			}

			else {

				logger.info("ReconcileCredit check Batch process could not start, Because process is running mode");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void processRefundInitiated(OrderEntity orderEntity, TransactionEntity transaction) throws Exception {
		transaction.setTransStatus(AppConstant.PG_REFUND_STATUS.PG_REFUND_INITIATED.getValue());
		TransactionRefundEntity transactionRefundEntity = populateTransactionRefundEntity(transaction);
		transactionRefundRepository.save(transactionRefundEntity);
		// update history table
		insertRecordTransactionRefundHistory(transactionRefundEntity, transaction.getPgTxnId());

		orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.REFUND_INITIATED.getValue(), new Date(),
				orderEntity.getOrderId());
	}

	private TransactionRefundEntity populateTransactionRefundEntity(TransactionEntity transactionEntity) {
		TransactionRefundEntity transactionRefundEntity = new TransactionRefundEntity();

		if (transactionEntity.getOrder().getOrderId() != null) {
			transactionRefundEntity.setOrderId(transactionEntity.getOrder().getOrderId());
		}

		if (transactionEntity.getBankTxnId() != null) {
			transactionRefundEntity.setBankTxnId(transactionEntity.getBankTxnId());
		}

		if (transactionEntity.getRefundAmount() != null) {
			transactionRefundEntity.setRefundAmount(transactionEntity.getRefundAmount());
		} else {
			transactionRefundEntity.setRefundAmount("0");
		}

		if (transactionEntity.getAmount() != null) {
			transactionRefundEntity.setTotalRefundAmount(transactionEntity.getAmount().toString());
		} else {
			transactionRefundEntity.setTotalRefundAmount("0");
		}

		if (transactionEntity.getTransStatus() != null) {
			transactionRefundEntity.setRefundStatus(transactionEntity.getTransStatus());
		}

		transactionRefundEntity.setRefundDate(null);
		transactionRefundEntity.setComment("");

		if (transactionEntity.getPgTxnId() != null) {
			transactionRefundEntity.setTransactionRefId(transactionEntity.getPgTxnId());
		}

		transactionRefundEntity.setPgRefundTransId(null);

		if (transactionEntity.getPaymentType() != null) {
			transactionRefundEntity.setTranscationType(transactionEntity.getPaymentType());
		}
		
		if (transactionEntity.getRetryCounter() != null) {
			transactionRefundEntity.setRetryCounter(transactionEntity.getRetryCounter());
		}
		else {
			transactionRefundEntity.setRetryCounter(0);
		}
		
		if (transactionEntity.getTransId() != null) {
			transactionRefundEntity.setTransId(transactionEntity.getTransId());
		}
		else {
			transactionRefundEntity.setTransId(0);
		}

		transactionRefundEntity.setTransactionRefId("8687687");// TODO: make sure data is not null
		return transactionRefundEntity;
	}

	public void sendSms(String userId, String language, OrderEntity order) throws Exception {

		NotificationRequest notificationRequest = new NotificationRequest();
		notificationRequest.setEvent("EVENT_SMS_ORDER_SUCCESS_COINS_CREDIT");
		notificationRequest.setUserId(userId);
		notificationRequest.setLanguage(language);
		notificationRequest.setOrderId(order.getOrderId());
		Map<String, String> variablesMap = new HashMap<>();
		variablesMap.put("coins", order.getCoins().toString());

		notificationRequest.setVariablesMap(variablesMap);

		smsNotifier.notify(notificationRequest);
	}
}
