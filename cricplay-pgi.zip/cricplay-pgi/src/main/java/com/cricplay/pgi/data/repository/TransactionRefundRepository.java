package com.cricplay.pgi.data.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cricplay.pgi.data.entity.TransactionRefundEntity;

public interface TransactionRefundRepository extends JpaRepository<TransactionRefundEntity, Integer>{
	
	
	@Query(value = "SELECT * FROM pg_transaction_refund where transcation_type=? and refund_status= ?", nativeQuery = true)
	List<TransactionRefundEntity> findTransactionRefundByTransType(String transcationType, String refundStatus);
	
	
	@Query(value = "SELECT * FROM pg_transaction_refund where refund_status= ? and transcation_type = ?", nativeQuery = true)
	Set<TransactionRefundEntity> findTransactionRefundByRefundStatus(String refundStatus, String transcation_type);
	
	@Query(value = "SELECT * FROM pg_transaction_refund where order_id=? and refund_status= ?", nativeQuery = true)
	List<TransactionRefundEntity> findTransactionRefundByOderId(Integer orderId,String refundStatus);

	@Query(value = "SELECT count(*) FROM pg_transaction_refund where trans_id=?", nativeQuery = true)
	Long findTransactionRefundEntityCountByTransId(Integer transId);

}


