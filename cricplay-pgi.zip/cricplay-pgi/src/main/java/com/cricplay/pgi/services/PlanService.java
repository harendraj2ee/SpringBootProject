package com.cricplay.pgi.services;

import com.cricplay.pgi.data.entity.PlanEntity;

public interface PlanService {
	
	public PlanEntity getPlanById(Integer id);

}
