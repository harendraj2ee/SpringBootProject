package com.cricplay.pgi.data.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "pg_batch_configuration")
public class BatchConfigurationEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "batch_name")
	private String batchName;
	 
	@Column(name = "batch_type")
	String batchType;
	 
	@Column(name = "execution_expression")
	String executionExpression;
	 
	@Column(name = "batch_status")
	String batchStatus;
	 
//	@Column(name = "valuation")
//	Integer valuation;

	@Column(name = "creation_date")
	Date creationDate;
	 
	@Column(name = "modify_date")
	Date modifyDate;
	 
	@Column(name = "current_status")
	String currentStatus;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getBatchName() {
		return batchName;
	}

	public void setBatchName(String batchName) {
		this.batchName = batchName;
	}

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	public String getExecutionExpression() {
		return executionExpression;
	}

	public void setExecutionExpression(String executionExpression) {
		this.executionExpression = executionExpression;
	}


//	public Integer getValuation() {
//		return valuation;
//	}
//
//	public void setValuation(Integer valuation) {
//		this.valuation = valuation;
//	}

	public String getBatchStatus() {
		return batchStatus;
	}

	public void setBatchStatus(String batchStatus) {
		this.batchStatus = batchStatus;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public Date getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getCurrentStatus() {
		return currentStatus;
	}

	public void setCurrentStatus(String currentStatus) {
		this.currentStatus = currentStatus;
	}

	 public BatchConfigurationEntity() {
		 super();
	}
	

	public BatchConfigurationEntity(Integer id, String batchName, String batchType, String executionExpression,
			String batchStatus, Date creationDate, Date modifyDate, String currentStatus) {
		this.id = id;
		this.batchName = batchName;
		this.batchType = batchType;
		this.executionExpression = executionExpression;
		this.batchStatus = batchStatus;
		this.creationDate = creationDate;
		this.modifyDate = modifyDate;
		this.currentStatus = currentStatus;
	}

	@Override
	public String toString() {
		return "BatchConfigurationEntity [id=" + id + ", batchName=" + batchName + ", batchType=" + batchType
				+ ", executionExpression=" + executionExpression + ", batchStatus=" + batchStatus + ", creationDate="
				+ creationDate + ", modifyDate=" + modifyDate + ", currentStatus=" + currentStatus + "]";
	}

	

	
}
