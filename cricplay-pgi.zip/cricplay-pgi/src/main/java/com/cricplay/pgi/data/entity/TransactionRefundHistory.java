package com.cricplay.pgi.data.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.cricplay.pgi.util.StringUtils;

@Entity
@Table(name="pg_transaction_refund_history")
public class TransactionRefundHistory {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	Integer id;
	
	@Column(name = "order_id")
	Integer orderId;
	
	@Column(name = "transaction_ref_id")
	String transactionRefId;
	
	@Column(name = "transcation_type")
	String transcationType;
	
	@Column(name = "refund_amount")
	String refundAmount;
	
	@Column(name = "total_refund_amount")
	String totalRefundAmount;
	
	@Column(name = "refund_status")
	String refundStatus;
	
	@Column(name = "refund_date")
	Date refundDate;
	
	@Column(name = "comment")
	String comment;
	
	@Column(name = "pg_refund_trans_id")
	String pgRefundTransId;
	
	@Column(name = "bank_txn_id")
	String bankTxnId;
	
	
	@Column(name="trans_id")
	Integer transId;
	
	@Column(name="respmsg")
	String respMsg;
	
	@Column(name="payment_mode")
	String paymentMode;
	
	@Column(name="refund_id")
	String refundId;
	
	@Column(name="created_on")
	Date createdOn;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	

	public String getTransactionRefId() {
		return transactionRefId;
	}

	public void setTransactionRefId(String transactionRefId) {
		this.transactionRefId = transactionRefId;
	}

	public String getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}


	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getTotalRefundAmount() {
		return totalRefundAmount;
	}

	public void setTotalRefundAmount(String totalRefundAmount) {
		this.totalRefundAmount = totalRefundAmount;
	}

	public String getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

	public Date getRefundDate() {
		return refundDate;
	}

	public void setRefundDate(Date refundDate) {
		this.refundDate = refundDate;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}


	public String getPgRefundTransId() {
		return pgRefundTransId;
	}

	public void setPgRefundTransId(String pgRefundTransId) {
		this.pgRefundTransId = pgRefundTransId;
	}

	public String getBankTxnId() {
		return bankTxnId;
	}

	public void setBankTxnId(String bankTxnId) {
		this.bankTxnId = bankTxnId;
	}    
	
	

	public Integer getTransId() {
		return transId;
	}

	public void setTransId(Integer transId) {
		this.transId = transId;
	}

	public String getRespMsg() {
		return respMsg;
	}

	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getRefundId() {
		return refundId;
	}

	public void setRefundId(String refundId) {
		this.refundId = refundId;
	}
	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	@Override
	public String toString() {
		return StringUtils.toJson(this);
	}

}
