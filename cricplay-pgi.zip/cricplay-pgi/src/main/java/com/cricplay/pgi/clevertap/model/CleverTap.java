package com.cricplay.pgi.clevertap.model;

import java.util.ArrayList;

public class  CleverTap{

	ArrayList < CleverTapRootObject > d = new ArrayList < CleverTapRootObject > ();

	public ArrayList<CleverTapRootObject> getD() {
		return d;
	}

	public void setD(ArrayList<CleverTapRootObject> d) {
		this.d = d;
	}

}
