package com.cricplay.pgi.data.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pg_plan")
public class PlanEntity {

	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="plan_id")
	public Integer planId;
	
	@Column(name="plan_name")
	public String planName;
	
	@Column(name="coins")
	public Integer coins;
	
	@Column(name="bonus_coins")
	public Integer bonusCoins;
	
	@Column(name="amount")
	public Double amount; 
	
	@Column(name="extra")
	public Integer extra;
	
	@Column(name="sort_order")
	public Integer sortOrder;
	
	@Column(name="best_value")
	public String bestValue;
	
	@Column(name="is_deleted")
	public String isDeleted;
	
	@Column(name="image")
	public String image;
	
	@Column(name="created_on")
	public Timestamp createdOn;
	
	@Column(name="modified_on")
	public Timestamp modifiedOn;
	

	public PlanEntity(Integer planId, String planName, Integer coins, Integer bonusCoins, Double amount,
			Integer extra, Integer sortOrder, String bestValue, String isDeleted, String image, Timestamp createdOn,
			Timestamp modifiedOn) {
		super();
		this.planId = planId;
		this.planName = planName;
		this.coins = coins;
		this.bonusCoins = bonusCoins;
		this.amount = amount;
		this.extra = extra;
		this.sortOrder = sortOrder;
		this.bestValue = bestValue;
		this.isDeleted = isDeleted;
		this.image = image;
		this.createdOn = createdOn;
		this.modifiedOn = modifiedOn;
	}


	public PlanEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}


	public Integer getCoins() {
		return coins;
	}

	public void setCoins(Integer coins) {
		this.coins = coins;
	}


	public Integer getBonusCoins() {
		return bonusCoins;
	}


	public void setBonusCoins(Integer bonusCoins) {
		this.bonusCoins = bonusCoins;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public Integer getExtra() {
		return extra;
	}


	public void setExtra(Integer extra) {
		this.extra = extra;
	}


	public Integer getSortOrder() {
		return sortOrder;
	}


	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}


	public String getBestValue() {
		return bestValue;
	}


	public void setBestValue(String bestValue) {
		this.bestValue = bestValue;
	}


	public String getIsDeleted() {
		return isDeleted;
	}


	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public Timestamp getCreatedOn() {
		return createdOn;
	}


	public void setCreatedOn(Timestamp createdOn) {
		this.createdOn = createdOn;
	}


	public Timestamp getModifiedOn() {
		return modifiedOn;
	}


	public void setModifiedOn(Timestamp modifiedOn) {
		this.modifiedOn = modifiedOn;
	}


	@Override
	public String toString() {
		return "PlanEntity [planId=" + planId + ", planName=" + planName + ", coins=" + coins + ", bonusCoins="
				+ bonusCoins + ", amount=" + amount + ", extra=" + extra + ", sortOrder=" + sortOrder + ", bestValue="
				+ bestValue + ", isDeleted=" + isDeleted + ", image=" + image + ", createdOn=" + createdOn
				+ ", modifiedOn=" + modifiedOn + "]";
	}


}

