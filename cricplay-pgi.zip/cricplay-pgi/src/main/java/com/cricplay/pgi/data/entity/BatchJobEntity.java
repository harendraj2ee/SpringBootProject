package com.cricplay.pgi.data.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="pg_batch_job")
public class BatchJobEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "batch_type_Id")
	private Integer batchTypeId;
	 
	@Column(name = "batch_type")
	String batchType;	 
	
	@Column(name = "started_on")
	Date startedOn;
	 
	@Column(name = "completed_on")
	Date completedOn;
	 
	@Column(name = "batch_size")
	String batchSize;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	

	public Integer getBatchTypeId() {
		return batchTypeId;
	}

	public void setBatchTypeId(Integer batchTypeId) {
		this.batchTypeId = batchTypeId;
	}

	public String getBatchType() {
		return batchType;
	}

	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}

	public Date getStartedOn() {
		return startedOn;
	}

	public void setStartedOn(Date startedOn) {
		this.startedOn = startedOn;
	}

	public Date getCompletedOn() {
		return completedOn;
	}

	public void setCompletedOn(Date completedOn) {
		this.completedOn = completedOn;
	}

	public String getBatchSize() {
		return batchSize;
	}

	public void setBatchSize(String batchSize) {
		this.batchSize = batchSize;
	}
	
	public BatchJobEntity() {
		super();
	}

	public BatchJobEntity(Integer id, Integer batchTypeId, String batchType, Date startedOn, Date completedOn,
			String batchSize) {
		this.id = id;
		this.batchTypeId = batchTypeId;
		this.batchType = batchType;
		this.startedOn = startedOn;
		this.completedOn = completedOn;
		this.batchSize = batchSize;
	}

	@Override
	public String toString() {
		return "BatchJobEntity [id=" + id + ", batchTypeId=" + batchTypeId + ", batchType=" + batchType + ", startedOn="
				+ startedOn + ", completedOn=" + completedOn + ", batchSize=" + batchSize + "]";
	}
	
	

}
