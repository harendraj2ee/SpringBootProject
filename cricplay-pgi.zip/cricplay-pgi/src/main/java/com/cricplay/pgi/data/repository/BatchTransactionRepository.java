package com.cricplay.pgi.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cricplay.pgi.data.entity.BatchTransactionEntity;


public interface BatchTransactionRepository extends JpaRepository<BatchTransactionEntity, Integer> {

	@Query(value = "SELECT * FROM pg_batch_transaction where batch_job_id=?", nativeQuery = true)
	BatchTransactionEntity findBatchTransactionByBatchJobId(String batchJobId);
}
