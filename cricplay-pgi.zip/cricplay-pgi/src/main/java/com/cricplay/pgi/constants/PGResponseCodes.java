package com.cricplay.pgi.constants;

import java.util.HashMap;
import java.util.Map;

public class PGResponseCodes {

	public static final Map<Integer, String> PG_RESPONSE_CODE_DESCRIPTION = new HashMap<Integer, String>()
	{
	    {
	    	put(200, "Success");
	        put(400, "Bad Request");
	        put(401, "UnAuthorized Access");
	        put(409, "Conflict");
	        put(424, "Failed Dependency");
	        put(500, "Internal server error");
	        put(1,"Failure");
	    };
	};


	public static final Map<Integer, String> PG_RESPONSE_CODE_COMMENT = new HashMap<Integer, String>()
	{
	    {
	    	put(200, "Transaction Successful");
	        put(400, "Syntatical error or data validation failed");
	        put(401, "Invalid User/Access");
	        put(409, "RequestId already exists");
	        put(424, "Insufficent winnings (case: PRO_WINNING_DEBIT)");
	        put(500, "Internal server error");
	    };
	};

}
