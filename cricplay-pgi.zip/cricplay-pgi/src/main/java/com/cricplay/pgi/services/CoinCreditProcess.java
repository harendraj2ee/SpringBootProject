package com.cricplay.pgi.services;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.model.CoinCreditResponse;
import com.cricplay.pgi.model.CurrencyStatusCheckResponse;
import com.cricplay.pgi.model.DebitCreditRequest;
import com.cricplay.pgi.model.MetaData;
import com.cricplay.pgi.notification.NotificationRequest;
import com.cricplay.pgi.notification.Notifier;
import com.cricplay.pgi.util.CommonUtil;


@Service
public class CoinCreditProcess {
	
	public static final Logger LOGGER = Logger.getLogger(CoinCreditProcess.class);
	
	@Value("${node}")
	private String node;
	
	@Value("${cricplay.pgi.credit.coin.api.retry.threshold}")
	private Integer apiRetryThreshold;
	
	@Value("${cricplay.pgi.credit.coin.batch.rerty.threshold}")
	private Integer batchRetryThreshold;
	
	@Autowired
	CoinCreditService coinCreditService;
	
	@Autowired
	TransactionRefundService transactionRefundService;
	
	@Autowired
	OrderDao orderDao;
	
	@Autowired
	TransactionDao transactionDao;
	
	@Autowired
	PlanService planService;
	
	@Autowired
	CurrencyCheckSevice currencyCheckService;
	
	@Autowired
	Notifier smsNotifier;
	
	public int initiateCoinCreditProcess(OrderEntity order,String language) throws Exception {
		LOGGER.info("initiate coin credit process start...");
		ResponseEntity<CoinCreditResponse> response=null;
		
		boolean isResponseSucess=false;
		// for App node
		if(StringUtils.isNotBlank(node) && node.equalsIgnoreCase(AppConstant.NODE.APP.getValue()))
		{
			String requestId=CommonUtil.generateRequestId(order.getOrderId());
			LOGGER.debug("request id: "+requestId);
			DebitCreditRequest request=buildDebitCreditRequest(order,requestId);
			
			for (int retry = 0; retry < apiRetryThreshold; retry++) {
				// check credit_coin_request_id in order exist credit coin api

				if (order.getCreditCoinReqId()!=null && !order.getCreditCoinReqId().isEmpty()) {
					
					ResponseEntity<CurrencyStatusCheckResponse> currencyCheckResponse=currencyCheckService.currencyStatusCheck(order.getCreditCoinReqId());
					//checking if requestId exist in previous coin credit request
					if(currencyCheckResponse!=null && currencyCheckResponse.getStatusCodeValue()==200) {
						LOGGER.debug("currency check response status code ::"+currencyCheckResponse.getStatusCodeValue());
						isResponseSucess=true;
						break;
					}
					
				}
				else // else of check credit_coin_request_id 
				{
					// updating new request id against which credit coin api will be called
					 Integer rowCount=orderDao.updateOrder(requestId, new Date(), order.getOrderId());
					 if(rowCount==1) {
						// making an api call to credit the coin
							response = coinCreditService.creditCoin(request);
							if (response != null && response.getStatusCodeValue() == 200) {
								LOGGER.debug("coin credit response code ::"+response.getStatusCodeValue());
								isResponseSucess = true;
								break;
							}// end of response check of coin credit call
					 }// updating new request id against which credit coin api will be called
				}//end of "else of check credit_coin_request_id"
			}// end of retry for loop
			// 
			if(isResponseSucess) {
				LOGGER.debug("isResponseSucess ::"+isResponseSucess+ "=>"+"updating pg_order status success with current modified date");
				// update pg_order status="success" with modified date.
				orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.SUCCESS.getValue(), new Date(), order.getOrderId());

				// trigger sms
				sendSms(String.valueOf(order.getCoins().intValue()), order.getUserId(), language,order.getOrderId());
					return 200;
			}
			
			else {
				// entry in pg_transaction_refund(winning/pg/winning+pg)
				//order status refund initiated with modified date.
				// refund entry with winning case start--->
				LOGGER.debug("Coin credit Failed :::"+order.getOrderId());
				if(order.getOrderType().equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNINGS_ONLY.getValue())) {
					LOGGER.debug("Refund entry for Winning only...");
					TransactionEntity transactionWin=transactionDao.findTransByOrderIdAndPaymentType(order.getOrderId(), AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
						int saveCount=transactionRefundService.saveTransactionRefund(transactionWin,AppConstant.PG_REFUND_STATUS.PG_REFUND_INITIATED.getValue());
						if(saveCount==1) {
							// update order table with status refund initiated
							orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.REFUND_INITIATED.getValue(), new Date(), order.getOrderId());
							LOGGER.debug("return code WINNINGS_ONLY :::" + saveCount);
							return saveCount;
						}
					
				}// refund entry with winning case end.
				
				// refund entry with PG case start --->
				else if(order.getOrderType().equalsIgnoreCase(AppConstant.ORDER_TYPE.PG_ONLY.getValue())) {
					LOGGER.debug("Refund entry for PG only...");
					TransactionEntity transaction=transactionDao.findTransByOrderIdAndPaymentType(order.getOrderId(), AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
						int saveCount=transactionRefundService.saveTransactionRefund(transaction,AppConstant.PG_REFUND_STATUS.PG_REFUND_INITIATED.getValue());
						if(saveCount==1) {
							orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.REFUND_INITIATED.getValue(), new Date(), order.getOrderId());
							LOGGER.debug("return code PG_ONLY :::" + saveCount);
							return saveCount;
						}
					}// refund entry with PG case end.
					
				
				// refund entry with winning and pg case start--->
				else if(order.getOrderType().equalsIgnoreCase(AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue())) {
					LOGGER.debug("Refund entry for Winning and PG...");
					
					TransactionEntity pgtransaction=transactionDao.findTransByOrderIdAndPaymentType(order.getOrderId(), AppConstant.PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());
					TransactionEntity winningtransaction=transactionDao.findTransByOrderIdAndPaymentType(order.getOrderId(), AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
					
					transactionRefundService.saveTransactionRefund(winningtransaction,AppConstant.PG_REFUND_STATUS.PG_REFUND_INITIATED.getValue());
					transactionRefundService.saveTransactionRefund(pgtransaction,AppConstant.PG_REFUND_STATUS.PG_REFUND_INITIATED.getValue());
					orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.REFUND_INITIATED.getValue(), new Date(), order.getOrderId());
					return 1;
					}
				}// refund entry with winning and pg case end.
				
			}
			//return response.getStatusCodeValue();
		LOGGER.debug("return code :::"+"0");	
		return 0;
		
	}
	
	/**
	 * build payload for coin credit api hit
	 * @param order
	 * @param requestId
	 * @return
	 */
	public DebitCreditRequest buildDebitCreditRequest(OrderEntity order, String requestId) {
		//hit pg_plan table for plan name
		LOGGER.info("build payload for coin credit start...");
		PlanEntity plan = planService.getPlanById(order.getPlanId());

		MetaData metadata = new MetaData();
		metadata.setOrderId("PG".concat(order.getOrderId().toString()));
		metadata.setPlanName(plan.getPlanName());

		DebitCreditRequest debitCreditRequest = new DebitCreditRequest();
		debitCreditRequest.setUserId(order.getUserId());
		if(order.getCoins()!=null) {
		debitCreditRequest.setAmount(order.getCoins());
		}
		else {
			debitCreditRequest.setAmount(0.0);
		}
		debitCreditRequest.setEvent(AppConstant.EVENT_TYPE.PRO_COIN_CREDIT.getValue());
		debitCreditRequest.setRequestId(requestId);
		debitCreditRequest.setMetadata(metadata);
		LOGGER.debug("payload for coin credit request ::"+debitCreditRequest);
		return debitCreditRequest;

	}
	
	
	public void sendSms(String coins,String userId,String language,Integer orderId) throws Exception{
		
		NotificationRequest notificationRequest=new NotificationRequest();
		notificationRequest.setEvent("EVENT_SMS_ORDER_SUCCESS_COINS_CREDIT");
		notificationRequest.setUserId(userId);
		notificationRequest.setOrderId(orderId);
		notificationRequest.setLanguage(language);

		Map<String,String> variablesMap=new HashMap<>();
		variablesMap.put("coins",coins);

		notificationRequest.setVariablesMap(variablesMap);

		smsNotifier.notify(notificationRequest);
	}

}
