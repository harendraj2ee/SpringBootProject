package com.cricplay.pgi.services;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.TransDetailsEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.model.PGTxnUpdate;

@Service
public class CreateTransDetailServiceImpl implements CreateTransDetailService{

	public static final Logger LOGGER = Logger.getLogger(CreateTransDetailServiceImpl.class);
	
	@Autowired
	TransactionUpdateService transactionUpdateService;
	
	@Autowired
	TransactionDao transactionDao;
	
	@Override
	public TransDetailsEntity createTransDetail(PGTxnUpdate pgTxnUpdate,String userId,String paymentType,String requestId,String eventType) throws Exception {
		LOGGER.info("createTransDetail start for paymentType ::"+paymentType);
		Integer transId=transactionUpdateService.findTransactionIdByOrderIdAndPaymentType(pgTxnUpdate.getOrderId(),paymentType);
		TransactionEntity transactionEntity = new TransactionEntity();
		transactionEntity.setTransId(transId);
		
		TransDetailsEntity transDetailsEntity=new TransDetailsEntity();
		
		transDetailsEntity.setTransaction(transactionEntity);
		transDetailsEntity.setUserId(userId);
		transDetailsEntity.setPaymentType(paymentType);
		transDetailsEntity.setStatus(pgTxnUpdate.getPgTransaction().getStatus());
		if(!StringUtils.isEmpty(pgTxnUpdate.getPgTransaction().getRespMsg())) {
		transDetailsEntity.setDescription(pgTxnUpdate.getPgTransaction().getRespMsg());
		}else {
			transDetailsEntity.setDescription("");
		}
		transDetailsEntity.setCreatedOn(new Date());
		transDetailsEntity.setModifiedOn(new Date());
		transDetailsEntity.setRequestId(requestId);
		if(StringUtils.isNotEmpty(eventType)) {
		transDetailsEntity.setEventType(eventType);
		}else {
			transDetailsEntity.setEventType("");
		}
		return transactionDao.createTransDetail(transDetailsEntity);
	}

}
