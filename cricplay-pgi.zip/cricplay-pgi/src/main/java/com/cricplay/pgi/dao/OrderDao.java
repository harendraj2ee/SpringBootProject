package com.cricplay.pgi.dao;

import java.util.Date;
import java.util.List;
import java.util.Set;

import com.cricplay.pgi.common.BaseDaoResponse;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.OrderStatusEntity;
import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.entity.TransDetailsEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;

public interface OrderDao {

	public OrderEntity buildOrder(PlanEntity plan,String userId,Double winningBalance,String orderType,String pgVendor) throws Exception;
	
	public Set<TransactionEntity> buildTransaction(OrderEntity order,String userId,Double winningBalance,String orderType,String pgVendor,String requestId) throws Exception;
	
	public TransDetailsEntity buildTransDetails(TransactionEntity transactionEntity) throws Exception;
	
	public OrderEntity persistTransaction(PlanEntity planEntity,String userId,Double winningBalance,String orderType,String pgVendor) throws Exception;
	
	public PlanEntity findPlanById(Integer planId) throws Exception;
	
	public int updateTransactionStatusById(String txnStatus, String description,Date date,Integer txnId) throws Exception;
	
	public Integer updateOrderStatusById(String orderStatus, Date date, Integer orderId) throws Exception;
	
	//public OrderEntity findOrderByStatus(String status) throws Exception;

	public OrderEntity findOrderById(Integer id) throws Exception;
	
	public List<OrderStatusEntity> findOrderListByStatus(String Status) throws Exception;
	
	public Integer updateOrder(String requestId,Date date,Integer orderId) throws Exception;
	
	public BaseDaoResponse getOrderSummary(Integer orderId,String userId) throws Exception;

	public OrderEntity getOrderSummary(Integer orderId) throws Exception;
	
	public List<OrderEntity> findOrderEntityListByStatus(String Status);

	public boolean updateTransactionAndDtl(TransactionEntity transactionEntity ) throws Exception;
	
}
