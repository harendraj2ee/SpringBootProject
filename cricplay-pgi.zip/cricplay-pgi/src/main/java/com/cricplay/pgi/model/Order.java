package com.cricplay.pgi.model;

import java.io.Serializable;

public class Order implements Serializable {

	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private Integer planId;
	private boolean useWinning;
	private String payMode;
	private String channelId;

	public String getPayMode() {
		return payMode;
	}

	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}

	public boolean isUseWinning() {
		return useWinning;
	}

	public void setUseWinning(boolean useWinning) {
		this.useWinning = useWinning;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	@Override
	public String toString() {
		return "Order [planId=" + planId + ", useWinning=" + useWinning + ", payMode=" + payMode + ", channelId="
				+ channelId + "]";
	}

}
