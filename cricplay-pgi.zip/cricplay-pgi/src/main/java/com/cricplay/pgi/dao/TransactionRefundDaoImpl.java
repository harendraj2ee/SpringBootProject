package com.cricplay.pgi.dao;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.entity.TransactionRefundHistory;
import com.cricplay.pgi.data.repository.TransactionRefundHistoryRepository;
import com.cricplay.pgi.data.repository.TransactionRefundRepository;


@Repository
public class TransactionRefundDaoImpl implements TransactionRefundDao{
	
	@Autowired
	TransactionRefundRepository transactionRefundRepository;
	
	@Autowired
	TransactionRefundHistoryRepository transactionRefundHistoryRepository;

	@Override
	public List<TransactionRefundEntity> findTransactionRefundByTransType(String transcationType, String refundStatus) throws Exception {
		
//		List transactionList = new ArrayList();
//		transactionList= transactionRefundRepository.findTransactionRefundByTransType(transcationType, refundStatus);
//		transactionList.iterator();
		return transactionRefundRepository.findTransactionRefundByTransType(transcationType, refundStatus);
	}

	@Override
	public Set<TransactionRefundEntity> findTransactionRefundByRefundStatus(String refundStatus, String transcationType) throws Exception {
		return transactionRefundRepository.findTransactionRefundByRefundStatus(refundStatus, transcationType);
	}
	
	@Override
	public TransactionRefundHistory saveTransactionRefundHistory(TransactionRefundHistory transactionRefundHistory) throws Exception{
		
		return transactionRefundHistoryRepository.saveAndFlush(transactionRefundHistory);
	}

	@Override
	public List<TransactionRefundEntity> findTransactionRefundByOderId(Integer orderId,String refundStatus){
		return transactionRefundRepository.findTransactionRefundByOderId(orderId,refundStatus);
	}

}
