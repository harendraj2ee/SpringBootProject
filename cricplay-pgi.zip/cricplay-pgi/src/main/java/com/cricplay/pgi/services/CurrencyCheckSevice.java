package com.cricplay.pgi.services;

import org.springframework.http.ResponseEntity;

import com.cricplay.pgi.model.CurrencyStatusCheckResponse;

public interface CurrencyCheckSevice {

	public ResponseEntity<CurrencyStatusCheckResponse> currencyStatusCheck(String requestId);
}
