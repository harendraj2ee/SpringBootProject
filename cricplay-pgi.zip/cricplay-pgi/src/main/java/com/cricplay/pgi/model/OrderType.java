package com.cricplay.pgi.model;

public enum OrderType {
WinningOnly(1), WinningPlusPG(2), PGOnly(3);

Integer orderType;
OrderType(Integer orderType){
	this.orderType=orderType;
}
}
