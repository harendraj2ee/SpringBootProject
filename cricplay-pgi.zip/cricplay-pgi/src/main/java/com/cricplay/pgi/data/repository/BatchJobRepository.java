package com.cricplay.pgi.data.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cricplay.pgi.data.entity.BatchJobEntity;

public interface BatchJobRepository  extends JpaRepository<BatchJobEntity, Integer>  {
	
	@Query(value = "SELECT * FROM pg_batch_job where batch_type_id=?", nativeQuery = true)
	BatchJobEntity findBatchJobByBatchTypeId(Integer batchTypeId);
	
	@Query(value = "UPDATE pg_batch_job SET batch_size = ? where id = ?", nativeQuery = true)
	BatchJobEntity updateBatchJobByRow( Integer batchSize, Integer id);
	
}
