package com.cricplay.pgi.dao;

import java.util.Date;
import java.util.List;

import com.cricplay.pgi.data.entity.TransDetailsEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;

import com.cricplay.pgi.data.entity.TransactionRefundHistory;


public interface TransactionDao {

	public TransactionEntity updateTransaction(TransactionEntity transactionEntity);
	
	public Integer findTransactionIdByOrderIdAndPaymentType(Integer orderId, String paymentType) throws Exception;
	
	public int updatePgTransaciton(String transStatus,String pgTxnId,String bankTxnId,String txnType,String gatewayName,String respCode, String respmsg, String bankName,String paymentMode,String refundAmt,String txnDate,Integer orderId,String paymentType) throws Exception;
	
	public TransDetailsEntity createTransDetail(TransDetailsEntity transDetailsEntity) throws Exception;
	
	public TransactionRefundEntity createTransactionRefund(TransactionRefundEntity transactinRefundEntity) throws Exception;
	
	public int saveTransactionRefund(TransactionRefundEntity transactinRefundEntity) throws Exception;
	
	public Object[] findTransactionByOrderIdAndPaymentType(Integer orderId,String paymentType);
	
	public TransactionEntity findTransByOrderIdAndPaymentType(Integer orderId,String paymentType);
	
	public List<TransactionEntitySinglton> findTransaction(Integer orderId,String paymentType);
	
	public List<TransactionEntity> findTransByOrderId(Integer orderId);
	
	public List<TransactionEntitySinglton> findTransactionStatusBytransStatus(String transStatus);
	
	public List<TransactionEntitySinglton> findTransactionByOrderId(Integer orderId);
	
	public TransactionEntity getTransactionEntity(Integer transactionId);
	
	public List<TransactionEntity> findTransactionStatusBytransStatus(String transStatus,String paymentType);
	
	public List<TransactionEntity> findTransactionEntity(Integer orderId, String paymentType);
	
	public List<TransactionEntity> findTransactionByStatusAndPaymentType(String transStatus,String paymentType,Date createdOn);
	
	public int saveTransactionRefundHistory(TransactionRefundHistory transactinRefundHistory) throws Exception;
	
}

