package com.cricplay.pgi.dao;

import java.util.List;
import java.util.Set;

import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.entity.TransactionRefundHistory;

public interface TransactionRefundDao {
	
	public List<TransactionRefundEntity> findTransactionRefundByTransType(String transcationType, String refundStatus) throws Exception;

	public Set<TransactionRefundEntity> findTransactionRefundByRefundStatus(String refundStatus, String batchTransactionType) throws Exception;
	
	public TransactionRefundHistory saveTransactionRefundHistory(TransactionRefundHistory transactionRefundHistory) throws Exception;
	
	public List<TransactionRefundEntity> findTransactionRefundByOderId(Integer orderId,String refundStatus);
}