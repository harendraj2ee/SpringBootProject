package com.cricplay.pgi.dao;

import com.cricplay.pgi.data.entity.BatchTransactionEntity;

public interface BatchTransactionDao {
	
	public BatchTransactionEntity findBatchTransactionByBatchJobId(String batchJobId) throws Exception;

}
