package com.cricplay.pgi.Jobs;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.constants.AppConstant.ORDER_STATUS;
import com.cricplay.pgi.constants.AppConstant.ORDER_TYPE;
import com.cricplay.pgi.constants.AppConstant.PAYMENT_TYPE;
import com.cricplay.pgi.constants.AppConstant.PG_REFUND_STATUS;
import com.cricplay.pgi.constants.AppConstant.PG_TXN_STATUS;
import com.cricplay.pgi.constants.AppConstant.TXN_STATUS;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.BatchTransactionEntity;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.TransDetailsEntitySinglton;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.repository.BatchTransactionRepository;
import com.cricplay.pgi.data.repository.OrderRepository;
import com.cricplay.pgi.data.repository.TransactionDetailsRepository;
import com.cricplay.pgi.data.repository.TransactionRefundRepository;
import com.cricplay.pgi.services.BatchConfigurationService;
import com.cricplay.pgi.util.CommonUtil;
import com.cricplay.pgi.util.DateUtil;
import com.paytm.pg.merchant.CheckSumServiceHelper;

/**
 * 
 * @author infinity labs
 *
 */
@Service
@Transactional
public class PGStatusCheckService extends BatchService {

	private static final Logger logger = Logger.getLogger(PGStatusCheckService.class);
	
	private static final String DESCRIPTION = "Maximum retry limit reached!";

	
	@Value("${cricplay.pgi.pgstatuscheck.batch.rerty.threshold}")
	private Integer retryThreshold;
	
	@Autowired
	private BatchConfigurationService batchConfigurationService;
	
	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private AppProperties appProperties;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private TransactionRefundRepository transactionRefundRepository;
	
	@Autowired
	private TransactionDetailsRepository transactionDetailsRepository;
	
	@Autowired
	private BatchTransactionRepository batchTransactionRepository;
	
	@Autowired
	CommonUtil commonUtil;
	
	
	@Override
	public void process() {
		
		BatchJobEntity batchJobEntity=null;

		try {
			//Step 1 : Get BatchConfigurationEntity object
			BatchConfigurationEntity batchConfigurationEntity = batchConfigurationService.findBatchConfigurationByType(AppConstant.JOB_TYPE.PGSTATUSCHECK.getJobType());
			
			logger.info("\n Batch Configruation enity list data " + batchConfigurationEntity);
			//Step 2 : Trigger process if the current status is not in "Running"
			if (!RUNNING_STATUS.equalsIgnoreCase(batchConfigurationEntity.getCurrentStatus())) {
				
				
				
				List<TransactionEntity> transactionEntityPendingList = transactionDao.findTransactionStatusBytransStatus(TXN_STATUS.PENDING.getValue(),PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue());

				List<TransactionEntity> transactionEntityInitiatedList= transactionDao.findTransactionByStatusAndPaymentType(TXN_STATUS.INITIATED.getValue(), PAYMENT_TYPE.PG_PAYMENT_TYPE.getValue(), DateUtil.subtractNminToCurrentDateAndTime(new Date(), appProperties.getInitiationStatustimeBefore()));
				
			

				List<TransactionEntity> transactionEntityList = Stream.concat(transactionEntityPendingList.stream(), transactionEntityInitiatedList.stream())
		                .collect(Collectors.toList());
				if(transactionEntityList.size()>0) {
				batchJobEntity = batchConfigDataInitialize(RUNNING_STATUS, batchConfigurationEntity);
				
				 for(TransactionEntity transactionEntity:transactionEntityList) {
					//logger.info("\n Process Transaction Entity data" + transactionEntity);
				  logger.debug("PGStatusCheckService transaction id ::"+transactionEntity.getTransId());
					try {
						// batch transaction table : insert new record
						BatchTransactionEntity batchTransactionEntity = new BatchTransactionEntity();
						batchTransactionEntity.setCretedOn(new Date());
						batchTransactionEntity.setOrderId(Double.valueOf(transactionEntity.getOrder().getOrderId()));
						batchTransactionEntity.setTransactionId(transactionEntity.getTransId());
						batchTransactionEntity.setTransactionType(transactionEntity.getPaymentType());
						batchTransactionEntity.setBatchJobId(Double.valueOf(batchJobEntity.getId()));
						batchTransactionRepository.save(batchTransactionEntity);
						// end batch transaction table : insert
						
						callRestApi(transactionEntity);
						
					} catch (Exception e) {
						logger.debug("PGStatusCheckService exception message:::" + e.getMessage());
					}

				  }
				
				if(batchJobEntity!=null) {
					batchConfigStatusUpdate(batchJobEntity, transactionEntityList.size(), batchConfigurationEntity);
				}
				else {
					logger.debug("batchJobEntity null...");
				}
				}
				
			}
			else {

				logger.info("pg status check Batch process could not start, Because process is running mode");
			}
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		

	}
	
	/**
	 * 
	 * @param transactionEntity
	 * @throws Exception
	 */
	private void callRestApi(TransactionEntity transactionEntity) throws Exception {
		Integer orderId = transactionEntity.getOrder().getOrderId();
		
		ResponseEntity<String> response=null;
		
		if(AppConstant.PG_VENDOR.SHAREIT.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
			
			ResponseEntity<String> responseToken=commonUtil.getShareitToken();
			if(responseToken!=null) {
			JSONObject responseData = new JSONObject();
			responseData = new JSONObject(responseToken.getBody());
			
			headers.set("token", responseData.get("data").toString());
			
			MultiValueMap<String, String> reqParam=buildPayloadShareIt(transactionEntity);
			
			HttpEntity<MultiValueMap<String, String>> payload = new HttpEntity<MultiValueMap<String, String>>(reqParam, headers);
			logger.info("REST API payload shareIt :"+payload);
			try {
				response = restTemplate.postForEntity(appProperties.getCricPlayShareItApiUrl(), payload, String.class);
			}catch(Exception e) {
				logger.debug("Error while getting payment status check response form shareit");
				logger.debug("Exception :::"+e.getCause());
			}
			}
		}
		else if(AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(transactionEntity.getPgVendor())) {
			
			TreeMap<String, String> requestParams= buildPayloadPayTm(orderId,transactionEntity.getTransId(),transactionEntity.getPgVendor());
			HttpEntity<String> payload = new HttpEntity<String>(new JSONObject(requestParams).toString());
			
			logger.info("REST API Payload PayTM: "+payload);
			try {
			 response = restTemplate.exchange(appProperties.getPaytmTransactionStatusUrl(),HttpMethod.POST, payload, String.class);
			}catch(Exception e) {
				logger.debug("Error while getting payment status check response from paytm");
				logger.debug("Exception :::"+e.getCause());
			}
		}
		if(response!=null && null!=response.getBody()) {
		JSONObject responseBody = new JSONObject(response.getBody());
		logger.info("Response  : "+responseBody);
		// Get response from API
		if(responseBody!=null) {
			
			PgCheckStatusResponse pgCheckStatusResponse=parseResponse(responseBody,transactionEntity.getPgVendor());
			if(null!=pgCheckStatusResponse.getTransStatus()) {
			if (pgCheckStatusResponse.getTransStatus().equals("TXN_SUCCESS")) {
				
				// Update statue into pg_transaction table
				transactionEntity.setTransStatus(pgCheckStatusResponse.getTransStatus());
				transactionEntity.setModified_on(new Date());
				if(!transactionEntity.getPgVendor().equalsIgnoreCase("shareit")) {
				transactionEntity.setPgTxnId(pgCheckStatusResponse.getTxnId());
				transactionEntity.setBankTxnId(pgCheckStatusResponse.getBankTxnId());
				transactionEntity.setTxnType(pgCheckStatusResponse.getTxnType());
				transactionEntity.setGatewayName(pgCheckStatusResponse.getGatewayName());
				transactionEntity.setPaymentMode(pgCheckStatusResponse.getPaymentMode());
				transactionEntity.setRefundAmount(pgCheckStatusResponse.getRefundAmount());
				transactionEntity.setTxnDate(pgCheckStatusResponse.getTxnDate());
				}
				updateTransaction(transactionEntity);
				
				TransDetailsEntitySinglton transDetailsEntitySinglton= new TransDetailsEntitySinglton();
				transDetailsEntitySinglton.setTransId(transactionEntity.getTransId());
				transDetailsEntitySinglton.setUserId(transactionEntity.getUserId());
				transDetailsEntitySinglton.setPaymentType(transactionEntity.getPaymentType());
				transDetailsEntitySinglton.setEventType("");
				transDetailsEntitySinglton.setStatus(PG_TXN_STATUS.PG_SUCCESS.getValue());
				transDetailsEntitySinglton.setDescription("TXN_SUCCESS");
				transDetailsEntitySinglton.setCreatedOn(new Date());
				transDetailsEntitySinglton.setModifiedOn(new Date());
				transactionDetailsRepository.save(transDetailsEntitySinglton);
				
				OrderEntity orderEntity= orderRepository.findOrderById(transactionEntity.getOrder().getOrderId());
				orderEntity.setStatus(ORDER_STATUS.COIN_CREDIT_PENDING.getValue());
				orderEntity.setModifiedOn(new Date());		
				orderRepository.save(orderEntity);
				
			} 

			if (pgCheckStatusResponse.getTransStatus().equals("TXN_FAILURE")) {
				
				transactionEntity.setTransStatus(pgCheckStatusResponse.getTransStatus());
				transactionEntity.setModified_on(new Date());
				transactionEntity.setRespmsg(pgCheckStatusResponse.getMessage());
				transactionEntity.setRetryCounter(0);
				// transaction refund table update after failure status
				TransactionEntity transEntity=transactionDao.findTransByOrderIdAndPaymentType(orderId,PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
				refundDataProcess(transEntity, pgCheckStatusResponse.getTransStatus(),AppConstant.TRANS_DESCRIPTION.FAIL.getValue(),pgCheckStatusResponse.getTxnId());
			}
			
			if (pgCheckStatusResponse.getTransStatus().equals("PENDING")) {
				if(transactionEntity.getRetryCounter()!=null) {
					if(retryThreshold>transactionEntity.getRetryCounter()) {
						transactionEntity.setRetryCounter(transactionEntity.getRetryCounter()+1);
					}
					else {
						logger.debug("retry counter reached :::"+transactionEntity.getRetryCounter());
						transactionEntity.setTransStatus(PG_TXN_STATUS.FAIL.getValue());
						transactionEntity.setModified_on(new Date());
						TransactionEntity transEntity=transactionDao.findTransByOrderIdAndPaymentType(orderId,PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
						refundDataProcess(transEntity, TXN_STATUS.FAIL.getValue(),AppConstant.TRANS_DESCRIPTION.FAIL.getValue(),pgCheckStatusResponse.getTxnId());
						logger.debug("updating order status to fail after threshold limit.");
						OrderEntity order=transactionEntity.getOrder();
						order.setStatus(ORDER_STATUS.FAIL.getValue());
						order.setModifiedOn(new Date());	
						orderRepository.saveAndFlush(order);
					}
				}
				
				updateTransaction(transactionEntity);
				
				//transaction detail table
				TransDetailsEntitySinglton transDetailsEntitySinglton= new TransDetailsEntitySinglton();
				transDetailsEntitySinglton.setTransId(transactionEntity.getTransId());
				transDetailsEntitySinglton.setUserId(transactionEntity.getUserId());
				transDetailsEntitySinglton.setPaymentType(transactionEntity.getPaymentType());
				transDetailsEntitySinglton.setEventType("");
				transDetailsEntitySinglton.setStatus(PG_TXN_STATUS.FAIL.getValue());
				transDetailsEntitySinglton.setDescription(DESCRIPTION);
				transDetailsEntitySinglton.setCreatedOn(new Date());
				transDetailsEntitySinglton.setModifiedOn(new Date());
				transactionDetailsRepository.save(transDetailsEntitySinglton);
				
			}
			
		}
		}
	}
	}
	
	/**
	 * Refund Data Process
	 * @param transactionEntity
	 * @param status
	 */
	private void refundDataProcess(TransactionEntity transactionEntity, String status,String description,String transactionRefId) {

		logger.debug("refundDataProcess start...");
		try {
		// Update statue into pg_transaction table
/*		transactionEntity.setTransStatus(status);
		transactionEntity.setDescription(description);
		updateTransaction(transactionEntity);*/
		
		OrderEntity orderEntity= transactionEntity.getOrder();
		
		if(orderEntity.getOrderType().equalsIgnoreCase(ORDER_TYPE.WINNING_AND_PG.getValue())) {
			//order_id, transaction_ref_id, trans_id, transaction_type, refund_amount, total_refund_amount, refund_status 
			TransactionRefundEntity transactionRefundEntity = new TransactionRefundEntity();
			transactionRefundEntity.setOrderId(orderEntity.getOrderId());
			if(StringUtils.isNotEmpty(transactionRefId)) {
			transactionRefundEntity.setTransactionRefId(transactionRefId);
			}
			else {
				transactionRefundEntity.setTransactionRefId("0");
			}
			transactionRefundEntity.setTransId(transactionEntity.getTransId());
			transactionRefundEntity.setTranscationType(transactionEntity.getPaymentType());
			transactionRefundEntity.setRefundAmount(String.valueOf(transactionEntity.getAmount()));
			transactionRefundEntity.setTotalRefundAmount(String.valueOf(transactionEntity.getAmount()));
			transactionRefundEntity.setRefundStatus(PG_REFUND_STATUS.WINNING_REFUND_INITIATED.getValue());
			transactionRefundEntity.setRespMsg(transactionEntity.getRespmsg());
			transactionRefundEntity.setRetryCounter(transactionEntity.getRetryCounter());
			transactionRefundRepository.save(transactionRefundEntity);
			
			// insert new record into transactionrefund history table
			insertRecordTransactionRefundHistory(transactionRefundEntity, null);
			
			// update order table
			
			orderEntity.setStatus(ORDER_STATUS.FAIL.getValue());
			orderEntity.setModifiedOn(new Date());	
			orderRepository.save(orderEntity);
		} 
		}catch(Exception e) {
			logger.debug("Error in refundDataProcess.");
			logger.debug("Exception :::"+e.getCause());
		}
		logger.debug("refundDataProcess end...");
	}

	/**
	 * 
	 * @param orderId
	 * @param txnId
	 * @param pgVendor
	 * @return
	 */
	public TreeMap<String, String> buildPayloadPayTm(Integer orderId, Integer txnId, String pgVendor) {
		TreeMap<String, String> params = new TreeMap<String, String>();

		Map<String,String> mechantInfoMap= appProperties.getMechantInfo(pgVendor);
		if(AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(pgVendor)) {
			params.put("MID", mechantInfoMap.get("merchantId"));
			params.put("ORDERID", String.valueOf(orderId));
			//paytmParams.put("REFID", String.valueOf(txnId));
			try {
				params.put("CHECKSUM", CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(mechantInfoMap.get("merchantKey"), params));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		return params;
	}
	
	/**
	 * 
	 * @param transactionEntity
	 * @return
	 */
	public MultiValueMap<String, String> buildPayloadShareIt(TransactionEntity transactionEntity){
		
		Map<String,String> mechantInfoMap= appProperties.getMechantInfo(transactionEntity.getPgVendor());
		String merchantMid = mechantInfoMap.get("merchantId");
		Integer orderId = transactionEntity.getOrder().getOrderId();
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();

		map.add("merchantId", merchantMid);
		map.add("bizType", "payTransQry");
		map.add("timestamp", String.valueOf(Instant.now()));
		map.add("orderId", orderId.toString());
		map.add("version", appProperties.getShareItApiVersion());
		return map;
		
	}

	/**
	 * 
	 * @param responseBody
	 * @param pgVendor
	 * @return
	 */
	public PgCheckStatusResponse parseResponse(JSONObject responseBody, String pgVendor) {

		PgCheckStatusResponse pgCheckStatusResponse = new PgCheckStatusResponse();

		if (AppConstant.PG_VENDOR.PAYTM.getValue().equalsIgnoreCase(pgVendor)) {
			pgCheckStatusResponse.setTransStatus(responseBody.getString("STATUS"));
			pgCheckStatusResponse.setMessage(responseBody.get("RESPMSG").toString());
			if(responseBody.has("TXNID")) {
			pgCheckStatusResponse.setTxnId(responseBody.get("TXNID").toString());
			}
			if(responseBody.has("BANKTXNID")) {
			pgCheckStatusResponse.setBankTxnId(responseBody.get("BANKTXNID").toString());
			}
			if(responseBody.has("TXNTYPE")) {
			pgCheckStatusResponse.setTxnType(responseBody.get("TXNTYPE").toString());
			}
			if(responseBody.has("GATEWAYNAME")) {
			pgCheckStatusResponse.setGatewayName(responseBody.get("GATEWAYNAME").toString());
			}
			if(responseBody.has("PAYMENTMODE")) {
			pgCheckStatusResponse.setBankName(responseBody.get("PAYMENTMODE").toString());
			}
			if(responseBody.has("REFUNDAMT")) {
			pgCheckStatusResponse.setPaymentMode(responseBody.get("REFUNDAMT").toString());
			}
			if(responseBody.has("TXNDATE")) {
				pgCheckStatusResponse.setTxnDate(responseBody.get("TXNDATE").toString());
			}
		}
		if (AppConstant.PG_VENDOR.SHAREIT.getValue().equalsIgnoreCase(pgVendor)) {
			try {
				if (responseBody.get("bizCode").toString().equalsIgnoreCase("0023")
						|| responseBody.get("bizCode").toString().equalsIgnoreCase("0022")
						|| responseBody.get("bizCode").toString().equalsIgnoreCase("0021")) {
					logger.debug("token is invalid");
				} else if (responseBody.get("bizCode").toString().equalsIgnoreCase("0000")) {

					if (responseBody.has("data")) {
						if (responseBody.getJSONObject("data").has("status")) {
							pgCheckStatusResponse.setTransStatus(AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[Integer
									.parseInt(responseBody.getJSONObject("data").get("status").toString())]);
							pgCheckStatusResponse
									.setTxnId(responseBody.getJSONObject("data").get("tradeNo").toString());
							if (Integer.parseInt(responseBody.getJSONObject("data").get("status").toString()) == 2) {
								pgCheckStatusResponse.setMessage("Pay Failure");
							} else if (Integer
									.parseInt(responseBody.getJSONObject("data").get("status").toString()) == 0) {
								pgCheckStatusResponse.setMessage("In Process");
							}
						} else {
							pgCheckStatusResponse.setTransStatus(AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[0]);
							pgCheckStatusResponse.setTxnId("");
							pgCheckStatusResponse.setMessage("In Process");
						}
					}
				} else {
					pgCheckStatusResponse.setTransStatus(AppConstant.SHAREIT_CHECK_STATUS_RESPONSE_CODE[2]);
					if (responseBody.has("message")) {
						pgCheckStatusResponse.setMessage(responseBody.get("message").toString());
					} else {
						pgCheckStatusResponse.setMessage("");
					}
				}

			}

			catch (Exception e) {
				e.printStackTrace();
			}
		}

		return pgCheckStatusResponse;
	}

}

class PgCheckStatusResponse{

	private String transStatus;
	private String message;
	private String txnId;
	private String bankTxnId;
	private String txnType;
	private String gatewayName;
	private String bankName;
	private String paymentMode;
	private String refundAmount;
	private String txnDate;

	public String getTransStatus() {
		return transStatus;
	}

	public void setTransStatus(String transStatus) {
		this.transStatus = transStatus;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}

	public String getBankTxnId() {
		return bankTxnId;
	}

	public void setBankTxnId(String bankTxnId) {
		this.bankTxnId = bankTxnId;
	}

	public String getTxnType() {
		return txnType;
	}

	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}

	public String getGatewayName() {
		return gatewayName;
	}

	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(String refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getTxnDate() {
		return txnDate;
	}

	public void setTxnDate(String txnDate) {
		this.txnDate = txnDate;
	}

}
