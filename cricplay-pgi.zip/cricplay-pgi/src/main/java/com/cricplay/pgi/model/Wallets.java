package com.cricplay.pgi.model;

import java.io.Serializable;
import java.util.List;

public class Wallets implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<Wallet> wallet;

	public List<Wallet> getWallet() {
		return wallet;
	}

	public void setWallet(List<Wallet> wallet) {
		this.wallet = wallet;
	}

}
