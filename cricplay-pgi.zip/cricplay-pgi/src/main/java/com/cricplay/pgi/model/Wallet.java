package com.cricplay.pgi.model;

import java.io.Serializable;

public class Wallet implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String currency;
	Double value;
	
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getValue() {
		return value;
	}
	public void setValue(Double value) {
		this.value = value;
	}
	@Override
	public String toString() {
		return "Wallet [currency=" + currency + ", value=" + value + ", getCurrency()=" + getCurrency()
				+ ", getValue()=" + getValue() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
	
}
