package com.cricplay.pgi.dao;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.repository.BatchJobRepository;;

@Repository
public class BatchJobDaoImpl implements BatchJobDao{
	
private static final Logger LOGGER = Logger.getLogger(BatchJobDaoImpl.class);
	
	@Autowired
	BatchJobRepository batchJobRepository;

	@Override
	public BatchJobEntity findBatchJobByBatchTypeId(Integer batchTypeId) throws Exception {
		return batchJobRepository.findBatchJobByBatchTypeId(batchTypeId);
		
	}

	@Override
	public BatchJobEntity InsertBatchJobByRow(Integer batchTypeId, String batchType, Date startedOn, Date completedOn, String batchSize) throws Exception {
		
		BatchJobEntity batchJobEntity=new BatchJobEntity();
//		batchJobEntity.setId(Id);
		batchJobEntity.setBatchTypeId(batchTypeId);
		batchJobEntity.setBatchType(batchType);
		batchJobEntity.setStartedOn(startedOn);
		batchJobEntity.setCompletedOn(completedOn);
		batchJobEntity.setBatchSize("0");
		
		LOGGER.debug("Order Entity :: " +batchJobEntity.toString());
		batchJobEntity = batchJobRepository.save(batchJobEntity);
		
		LOGGER.debug("batchJobEntity  Setting Batch Job:: " +batchJobEntity.toString());
		return batchJobEntity;
	}

	@Override
	public BatchJobEntity updateBatchJobByRow(Integer batchSize, Integer id) throws Exception {
		return batchJobRepository.updateBatchJobByRow(batchSize, id);
	}

}
