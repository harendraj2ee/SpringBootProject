package com.cricplay.pgi.dao;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.repository.GetOrderRepository;

@Repository
public class GetOrderDaoImp implements GetOrderDao{
	public static final Logger LOGGER = Logger.getLogger(GetOrderDaoImp.class);
	@Autowired
	GetOrderRepository getOrderRepository;

	@Override
	public OrderEntity findOrderByStatus(String status) {
		LOGGER.debug("getting Order table by status start...");
		return getOrderRepository.findOrderByStatus(status);
	}

	@Override
	public OrderEntity findOrderById(Integer orderid) {
		LOGGER.debug("GETTING ORDER BY ID START >> ");
		return getOrderRepository.findOrderById(orderid);
	}

}
