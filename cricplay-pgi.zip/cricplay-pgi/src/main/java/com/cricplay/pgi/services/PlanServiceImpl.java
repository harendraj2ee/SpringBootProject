package com.cricplay.pgi.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.dao.PlanDao;
import com.cricplay.pgi.data.entity.PlanEntity;

@Service
public class PlanServiceImpl implements PlanService{
	
	@Autowired
	PlanDao planDao;

	@Override
	public PlanEntity getPlanById(Integer id) {
		
		PlanEntity plan=planDao.getPlanById(id);
		
		return plan;
	}

}
