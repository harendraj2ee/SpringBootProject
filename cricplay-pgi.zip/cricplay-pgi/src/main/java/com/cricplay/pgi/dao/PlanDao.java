package com.cricplay.pgi.dao;

import com.cricplay.pgi.data.entity.PlanEntity;

public interface PlanDao {
	
	public PlanEntity getPlanById(Integer id);
}
