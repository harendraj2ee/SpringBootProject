package com.cricplay.pgi.util;


import com.cricplay.pgi.config.AppProperties;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import com.cricplay.pgi.model.VerifyUserResponse;

/**
 * 
 * @author infinity labs
 *
 */
@Configuration
public class CommonUtil {
	
	private static final Logger logger = Logger.getLogger(CommonUtil.class);
	
	@Value( "${cricplay.pgi.verify.user.url}" )
	String verifyUserUrl;
	
	
	@Value( "${cricplay.pgi.winning.debit.url}" )
	String winningDebitUrl;
	
	@Autowired
	AppProperties appProperties;
	
	
	/**
	 * appending prefix to orderId to make it alphanumeric
	 * @param orderId
	 * @return
	 */
	public static String appendOrderPrefix(Integer orderId) {
		
		return "PG"+String.valueOf(orderId);
	}
	
	/**
	 * Generating unique request id for each order
	 * @param orderId
	 * @return
	 */
	public static String generateRequestId(Integer orderId) {
		String requestId="PG".concat(orderId.toString()).concat("-").concat(String.valueOf(System.currentTimeMillis()));
		return requestId;
	}
	
	/**
	 * verify user from cricplay api
	 * @param authorizationToken
	 * @return
	 * @throws Exception
	 */
    public  ResponseEntity<VerifyUserResponse> verifyUser(String authorizationToken) throws Exception{
        HttpHeaders headers = new HttpHeaders();
        headers.add("Authorization", authorizationToken);
        HttpEntity<String> entity = new HttpEntity<String>(headers);
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<VerifyUserResponse> response=null;
        try {
        	response = restTemplate.exchange(verifyUserUrl, HttpMethod.GET, entity, VerifyUserResponse.class);
        }catch(Exception e) {
        	logger.debug("error while verify user ::");
        	logger.debug("Exception ::"+e.getCause());
        }
        return response;
        
    }
    /**
     * Request token from share it
     * @return
     * @throws Exception
     */
    public ResponseEntity<String> getShareitToken() throws Exception{
    	
    	HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		
		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();

		map.add("bizType", "token");
		map.add("merchantId", appProperties.getShareItMerchantId());
		map.add("version", appProperties.getShareItApiVersion());
		map.add("secretKey", appProperties.getShareItSecretKey());
		RestTemplate restTemplate = new RestTemplate();
		HttpEntity<MultiValueMap<String, String>> tokenRequest = new HttpEntity<MultiValueMap<String, String>>(map, headers);
		ResponseEntity<String> tokenResponse=null;
		try {
			tokenResponse = restTemplate.postForEntity(appProperties.getCricPlayShareItApiUrl(), tokenRequest, String.class);
		}catch(Exception e) {
			logger.debug("error while getting shareit token");
			logger.debug("Exception ::",e.getCause());
		}
		return tokenResponse;
    	
    }
}
