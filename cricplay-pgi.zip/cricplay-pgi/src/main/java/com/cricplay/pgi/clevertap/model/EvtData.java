package com.cricplay.pgi.clevertap.model;


public class EvtData {

	private String status;
	private Double amount;
	private String desc;
	private Integer planId;
	private Double pgAmount;
	private Double winAmount;
	private String failureType;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public Integer getPlanId() {
		return planId;
	}

	public void setPlanId(Integer planId) {
		this.planId = planId;
	}


	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public Double getPgAmount() {
		return pgAmount;
	}

	public void setPgAmount(Double pgAmount) {
		this.pgAmount = pgAmount;
	}

	public Double getWinAmount() {
		return winAmount;
	}

	public void setWinAmount(Double winAmount) {
		this.winAmount = winAmount;
	}

	public String getFailureType() {
		return failureType;
	}

	public void setFailureType(String failureType) {
		this.failureType = failureType;
	}

	
}
