package com.cricplay.pgi.data.entity;

import com.cricplay.pgi.util.StringUtils;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "pg_sent_sms_details")
public class SmsSentEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;

	@Column(name = "user_id")
	private String userId;

	@Column(name = "sms_response")
	private String smsResponse;

	@Column(name = "event")
	private String event;

	@Column(name = "status")
	private String status;

	@Column(name = "language")
	private String language;


	@Column(name = "order_id")
	private Integer orderId;

	@Column(name = "created_on")
	private Date createdOn;

	@Override
	public String toString() {
		return StringUtils.toJson(this);
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSmsResponse() {
		return smsResponse;
	}

	public void setSmsResponse(String smsResponse) {
		this.smsResponse = smsResponse;
	}

	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

}