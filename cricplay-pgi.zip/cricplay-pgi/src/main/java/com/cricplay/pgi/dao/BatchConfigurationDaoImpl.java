package com.cricplay.pgi.dao;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.repository.BatchConfigurationRepository;

@Repository
public class BatchConfigurationDaoImpl implements BatchConfigurationDao {

	private static final Logger LOGGER = Logger.getLogger(BatchConfigurationDaoImpl.class);
	
	@Autowired
	BatchConfigurationRepository batchConfigurationRepository;
	
	@Override
	public BatchConfigurationEntity findBatchConfigurationByType(String batchType) throws Exception {
		
		return batchConfigurationRepository.findBatchConfigurationByType(batchType);
		
	}

	@Override
	public BatchConfigurationEntity UpdateBatchConfigurationById(String currentStatus, String batchStatus, Integer Id) throws Exception {
		
		return batchConfigurationRepository.UpdateBatchConfigurationById(currentStatus, batchStatus,  Id);
		
	}

	
}
