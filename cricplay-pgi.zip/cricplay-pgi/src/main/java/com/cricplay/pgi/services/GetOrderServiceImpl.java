package com.cricplay.pgi.services;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.GetOrderDao;
import com.cricplay.pgi.data.entity.OrderEntity;

@Service
public class GetOrderServiceImpl implements GetOrderService {
	AppConstant appConstant;
	public static final Logger LOGGER = Logger.getLogger(GetOrderServiceImpl.class);
	@Autowired
	AppProperties appProperties;
	@Autowired
	GetOrderDao getOrderDao;
	@Autowired
	RestTemplate restTemplate;
	@Override
	public OrderEntity findOrderByStatus(String status) {
		OrderEntity response=getOrderDao.findOrderByStatus(status);
        LOGGER.info("Response getOrderDao from verifying User service ::"+response);
		return response;
	}
	
	@Override
	public OrderEntity findOrderById(Integer orderid) {
		LOGGER.info("bEFORE call dao method...");
		OrderEntity response = getOrderDao.findOrderById(orderid);
		LOGGER.debug("after getOrderDao call... ");
		return response;
	}

}
