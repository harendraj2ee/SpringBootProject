package com.cricplay.pgi.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.services.BatchConfigurationService;
import com.cricplay.pgi.services.BatchJobService;
import com.cricplay.pgi.services.TransactionRefundService;

@CrossOrigin
@RestController
@RequestMapping(value = "/cricplay/api/v1")
public class BatchWinningCreditController {
	private static final Logger LOGGER = Logger.getLogger(BatchWinningCreditController.class);

	@Autowired
	BatchConfigurationService batchConfigurationService;

	@Autowired
	BatchJobService batchJobService;

	@Autowired
	TransactionRefundService transactionRefundService;

	@RequestMapping(value = "/getWinningByBatchType", method = RequestMethod.GET)
	public BatchConfigurationEntity findConfigurationByType(@RequestParam(value = "batchtype") String batchType)
			throws Exception {
		BatchConfigurationEntity batchConfigurationEntity = null;
		BatchJobEntity batchJobEntity = null;
		BatchConfigurationEntity updatedBatchConfigurationEntity = null;
		List<TransactionRefundEntity> transactionRefundEntity =  null;

		batchConfigurationEntity = batchConfigurationService.findBatchConfigurationByType(batchType);
		LOGGER.info("\n Batch Configruation enity list data " + batchConfigurationEntity);

		try {

			if (!batchConfigurationEntity.getCurrentStatus().equalsIgnoreCase("Running")) {

				updatedBatchConfigurationEntity = batchConfigurationService.updateBatchConfigurationById("Running",
						"Active", batchConfigurationEntity.getId());
				LOGGER.info("\n Batch Configration Entity update by cron type" + updatedBatchConfigurationEntity);

//				batchJobEntity = batchJobService.InsertBatchJobByRow(batchConfigurationEntity.getId(),
//						batchConfigurationEntity.getBatchType());
				LOGGER.info("\n Batch Job inserted data in Batch Table by Batchtype Id" + batchJobEntity);

				
				String transcationType = "Winning";
				String refundStatus = "Initiated";
				transactionRefundEntity = transactionRefundService.findTransactionRefundByTransType(transcationType, refundStatus);
				
				LOGGER.info("\n Transaction Refund Entity list fatch by service" + transactionRefundEntity);
				
				System.out.println("\n transactionRefundEntity --" + transactionRefundEntity);

				Integer count = 0;
				boolean transactionServiceStatus = true;
				for (TransactionRefundEntity transactionRefundList : transactionRefundEntity) {
					count = count + 1;
					if (transactionServiceStatus == true) {
						System.out.println("winning Credit job is running");

					} else {
						System.out.println("Winning job is not running ");

					}
				}

				LOGGER.info("Current Row id from Batch job table" + batchJobEntity.getId());
				LOGGER.info("Batch Job updated the count of order Table by Batchtype Id" + transactionRefundEntity.size());
				batchJobEntity = batchJobService.updateBatchJobByRow(count, batchJobEntity.getId());

				System.out.println("batchConfigurationEntity.getId() - " + batchConfigurationEntity.getId());
				updatedBatchConfigurationEntity = batchConfigurationService.updateBatchConfigurationById("Ideal",
						"Active", batchConfigurationEntity.getId());
				LOGGER.info("Batch Configration Entity update after Batch Transaction cron type"
						+ updatedBatchConfigurationEntity);

			} else {
				LOGGER.info("Winning Batch process could not start, Because process is running mode");
				return batchConfigurationEntity;
			}

			return batchConfigurationEntity;
		} catch (Exception e) {
			LOGGER.error("Exception occured while creating order::" + e.getMessage());
			throw new Exception(e);

		}

	}

}