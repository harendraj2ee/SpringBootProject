package com.cricplay.pgi.services;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;
import com.cricplay.pgi.model.PGTxnUpdate;

@Service
public class TransactionUpdateServiceImpl implements TransactionUpdateService {

	@Autowired
	TransactionDao transacitonDao;

	@Autowired
	OrderDao orderDao;

	@Override
	public Integer findTransactionIdByOrderId(Integer orderId) throws Exception {

		return transacitonDao.findTransactionIdByOrderIdAndPaymentType(orderId,
				AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());

	}

	@Override
	public Integer updatePgTransaction(PGTxnUpdate pgTxnUpdate, TransactionEntity transactionEntity,Integer orderId, String paymentType) throws Exception {

		String transStatus = null;
		String pgTxnId = null;
		String bankTxnId = null;
		String txnType = null;
		String gatewayName = null;
		String respCode = null;
		String respmsg = null;
		String bankName = null;
		String paymentMode = null;
		String refundAmt = null;
		String txnDate = null;

		if (pgTxnUpdate.getOrderId() != null) {
			orderId = pgTxnUpdate.getOrderId();
		}
		
		if (pgTxnUpdate.getPgTransaction().getStatus() != null) {
			transStatus = pgTxnUpdate.getPgTransaction().getStatus(); 
		} else {
			transStatus = AppConstant.PG_TXN_STATUS.PENDING.getValue();
		}
		if (pgTxnUpdate.getPgTransaction().getPgTxnId() != null) {
			pgTxnId = pgTxnUpdate.getPgTransaction().getPgTxnId();
		}
		if (pgTxnUpdate.getPgTransaction().getBankTxnId() != null) {
			bankTxnId = pgTxnUpdate.getPgTransaction().getBankTxnId();
		}
		if (pgTxnUpdate.getPgTransaction().getTxnType() != null) {
			txnType = pgTxnUpdate.getPgTransaction().getTxnType();
		}
		if (pgTxnUpdate.getPgTransaction().getGatewayName() != null) {
			gatewayName = pgTxnUpdate.getPgTransaction().getGatewayName();
		}
		if (pgTxnUpdate.getPgTransaction().getRespCode() != null) {
			respCode = pgTxnUpdate.getPgTransaction().getRespCode();
		}
		if (pgTxnUpdate.getPgTransaction().getRespMsg() != null) {
			respmsg = pgTxnUpdate.getPgTransaction().getRespMsg();
		}
		if (pgTxnUpdate.getPgTransaction().getBankName() != null) {
			bankName = pgTxnUpdate.getPgTransaction().getBankName();
		}
		if (pgTxnUpdate.getPgTransaction().getPaymentMode() != null) {
			paymentMode = pgTxnUpdate.getPgTransaction().getPaymentMode();
		}
		if (pgTxnUpdate.getPgTransaction().getRefundAmount() != null) {
			refundAmt = pgTxnUpdate.getPgTransaction().getRefundAmount();
		}
		if (pgTxnUpdate.getPgTransaction().getTxnDate() != null) {
			txnDate = pgTxnUpdate.getPgTransaction().getTxnDate();
		}
		if(!transactionEntity.getPgVendor().equalsIgnoreCase("shareit")) {
			return transacitonDao.updatePgTransaciton(transStatus, pgTxnId, bankTxnId, txnType, gatewayName, respCode,
				respmsg, bankName, paymentMode, refundAmt, txnDate, orderId, paymentType);
		}else {
				transactionEntity.setTransStatus(transStatus);
				transactionEntity.setRespCode(respCode);
				TransactionEntity transactionEntityUpdated=transacitonDao.updateTransaction(transactionEntity);
				if(transactionEntityUpdated.getTransId()!=null) {
				return 1;
				}
				else {
				return 0;
			}
		}
	}

	@Override
	public int updateTransactionStatusById(String status, String description,Date date, Integer transId) throws Exception {

		return orderDao.updateTransactionStatusById(status,description,date, transId);
	}

	@Override
	public Integer findTransactionIdByOrderIdAndPaymentType(Integer orderId, String paymentType) throws Exception {

		return transacitonDao.findTransactionIdByOrderIdAndPaymentType(orderId, paymentType);
	}

	@Override
	public List<TransactionEntitySinglton> findTransactionBytransStatus(String transStatus) throws Exception {
		return transacitonDao.findTransactionStatusBytransStatus(transStatus);
	}

	@Override
	public List<TransactionEntitySinglton> findTransacitionByOrderId(Integer orderId) throws Exception {
		
		return transacitonDao.findTransactionByOrderId(orderId);
	}
	
	@Override
	public boolean isWinningCreditExist(Integer transactionId) {
		TransactionEntity transactionEntity=transacitonDao.getTransactionEntity(transactionId);
		boolean isWinndingCredit=false;
		if(transactionEntity!=null && StringUtils.isNotBlank(transactionEntity.getWinningCreditRequest())) {
			isWinndingCredit=true;
		}
		return isWinndingCredit;
	}


	@Override
	public boolean updateTransactionAndDtlStatusById(TransactionEntity transactionEntity) throws Exception {

		return orderDao.updateTransactionAndDtl(transactionEntity);


	}

	public TransactionEntity findTransactionByOrderIdAndPaymentType(Integer orderId,String paymentType) throws Exception{

		return transacitonDao.findTransByOrderIdAndPaymentType(orderId,paymentType);
	}
}
