package com.cricplay.pgi.util;

import java.util.Calendar;
import java.util.Date;

public class DateUtil {
	
	public static Date subtractNminToCurrentDateAndTime(Date date, int min) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MINUTE, -min);
		return cal.getTime();
	}

}
