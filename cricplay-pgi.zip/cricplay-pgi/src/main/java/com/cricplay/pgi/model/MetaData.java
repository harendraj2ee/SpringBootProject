package com.cricplay.pgi.model;

import java.io.Serializable;

public class MetaData implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String orderId;
	String planName;
	
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	
}

