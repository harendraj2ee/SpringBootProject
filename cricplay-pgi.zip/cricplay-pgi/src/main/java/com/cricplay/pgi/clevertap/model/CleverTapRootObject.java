package com.cricplay.pgi.clevertap.model;

public class CleverTapRootObject {
	
	private String FBID;
	private long ts;
	private String type;
	private String evtName;
	private EvtData evtData;
	
	public long getTs() {
		return ts;
	}
	public void setTs(long ts) {
		this.ts = ts;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getEvtName() {
		return evtName;
	}
	public void setEvtName(String evtName) {
		this.evtName = evtName;
	}
	public EvtData getEvtData() {
		return evtData;
	}
	public void setEvtData(EvtData evtData) {
		this.evtData = evtData;
	}
	public String getFBID() {
		return FBID;
	}
	public void setFBID(String fBID) {
		FBID = fBID;
	}
	
	
	
}
