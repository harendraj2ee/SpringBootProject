/*
 * package com.cricplay.pgi.model;
 * 
 * import java.util.List;
 * 
 * public class OrderDTO { public List<OrderStatus> orderStatus;
 * 
 * String message; Integer statusCode; String status; public List<OrderStatus>
 * getOrderStatus() { return orderStatus; } public void
 * setOrderStatus(List<OrderStatus> orderStatus) { this.orderStatus =
 * orderStatus; } public String getMessage() { return message; } public void
 * setMessage(String message) { this.message = message; } public Integer
 * getStatusCode() { return statusCode; } public void setStatusCode(Integer
 * statusCode) { this.statusCode = statusCode; } public String getStatus() {
 * return status; } public void setStatus(String status) { this.status = status;
 * }
 * 
 * 
 * }
 */