package com.cricplay.pgi.data.repository;

import com.cricplay.pgi.data.entity.SmsSentEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;


public interface SmsSentRepository extends JpaRepository<SmsSentEntity, Integer> {

}
