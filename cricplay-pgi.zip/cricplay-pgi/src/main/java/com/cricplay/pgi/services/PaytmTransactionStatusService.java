package com.cricplay.pgi.services;

public interface PaytmTransactionStatusService {
	 public String paytmtransactionStatus(String orderId);	
}
