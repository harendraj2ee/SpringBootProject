package com.cricplay.pgi.model;

import java.util.Date;

public class BatchJob {
	private Integer id;
	private Integer batchTypeId; 
	private String batchType ;
	private Date startedOn ;
	private Date completedOn ;
	private  int batchSize;
	
	
	
	public BatchJob(Integer id, Integer batchTypeId, String batchType, Date startedOn, Date completedOn,
			int batchSize) {
		super();
		this.id = id;
		this.batchTypeId = batchTypeId;
		this.batchType = batchType;
		this.startedOn = startedOn;
		this.completedOn = completedOn;
		this.batchSize = batchSize;
	}
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getBatchTypeId() {
		return batchTypeId;
	}
	public void setBatchTypeId(Integer batchTypeId) {
		this.batchTypeId = batchTypeId;
	}
	public String getBatchType() {
		return batchType;
	}
	public void setBatchType(String batchType) {
		this.batchType = batchType;
	}
	public Date getStartedOn() {
		return startedOn;
	}
	public void setStartedOn(Date startedOn) {
		this.startedOn = startedOn;
	}
	public Date getCompletedOn() {
		return completedOn;
	}
	public void setCompletedOn(Date completedOn) {
		this.completedOn = completedOn;
	}
	public int getBatchSize() {
		return batchSize;
	}
	public void setBatchSize(int batchSize) {
		this.batchSize = batchSize;
	}

	@Override
	public String toString() {
		return "BatchJob [id=" + id + ", batchTypeId=" + batchTypeId + ", batchType=" + batchType + ", startedOn="
				+ startedOn + ", completedOn=" + completedOn + ", batchSize=" + batchSize + "]";
	} 
	

}
