package com.cricplay.pgi.controller;

import java.util.Map.Entry;
import java.util.TreeMap;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.model.Checksum;
import com.cricplay.pgi.model.TransactionRefund;
import com.paytm.pg.merchant.CheckSumServiceHelper;

@CrossOrigin
@RestController
@RequestMapping(value = "/cricplay/api/v1")
public class ChecksumController {
	@Autowired
	AppProperties appProperties;

	

	@RequestMapping(value = "/checksum", method = RequestMethod.POST, headers = "Accept=application/json")
	public String checksum(@RequestBody Checksum checksum) {
		JSONObject response = new JSONObject();
		JSONObject checksumAttribute = new JSONObject();

		String callUrl = null;
		String website = null;
		if (checksum.getChannelId().equals("WAP")) {
			callUrl = appProperties.getAppCallbackUrl();
			website = appProperties.getAppWebsite();
		} else {
			callUrl = appProperties.getCallbackUrl();
			website = appProperties.getWebsite();
		}

		response.put("mid", checksum.getMid());
		response.put("orderId", checksum.getOrderId());
		response.put("custId", checksum.getCustId());
		response.put("channelId", checksum.getChannelId());
		response.put("txnAmount", checksum.getTxnAmount());
		response.put("website", website);
		response.put("industryTypeId", checksum.getIndustryTypeId());
		response.put("callBackUrl", callUrl + checksum.getOrderId());
		response.put("checksum", checksum.getChecksumHash(appProperties.getMerchantKey()));
		// response.put("generateChecksum", checksum.generateChecksum());
		// response.put("marchentKey", AppConstant.merchantKey.getBytes());
		checksumAttribute.put("checksumAttributes", response);
		return checksumAttribute.toString();

	}

	@RequestMapping(value = "/checksum/verify", method = RequestMethod.POST, headers = "Accept=application/json")
	public String checksumVerify(@RequestBody Checksum checksum) throws Exception {

		String paytmChecksum = null;
		String validate = null;
		JSONObject response = new JSONObject();
		// Create a tree map from the form post param
		TreeMap<String, String> paytmParams = new TreeMap<String, String>();
		// Request is HttpServletRequest
		paytmParams.put("mid", checksum.getMid());
		paytmParams.put("orderId", checksum.getOrderId());
		paytmParams.put("custId", checksum.getCustId());
		paytmParams.put("channelId", checksum.getChannelId());
		paytmParams.put("txnAmount", checksum.getTxnAmount());
		paytmParams.put("website", checksum.getWebsite());
		paytmParams.put("industryTypeId", checksum.getIndustryTypeId());
		paytmParams.put("callBackUrl", checksum.getCallBackUrl());
		paytmParams.put("CHECKSUMHASH", checksum.getChecksumHash(appProperties.getMerchantKey()));


		for (Entry<String, String> requestParamsEntry : paytmParams.entrySet()) {
			if (requestParamsEntry.getKey().equals("CHECKSUMHASH")) {
				paytmChecksum = requestParamsEntry.getValue();
			} else {
				paytmParams.put(requestParamsEntry.getKey(), requestParamsEntry.getValue());
			}
		}
		// Call the method for verification
		boolean isValidChecksum = CheckSumServiceHelper.getCheckSumServiceHelper()
				.verifycheckSum(appProperties.getMerchantKey(), paytmParams, paytmChecksum);
//			 System.out.println("paytmParams >>> "+paytmParams);
//			 System.out.println("paytmChecksum :::::::: "+paytmChecksum);

		// If isValidChecksum is false, then checksum is not valid
		System.out.println("checksum is --" + isValidChecksum);
		if (isValidChecksum) {
			response.put("message", "Checksum Matched");
			response.put("checksumhash", paytmChecksum);
			response.put("status", 200);
		} else {
			response.put("message", "Checksum is not match");
			response.put("checksumhash", paytmChecksum);
			response.put("status", 501);
		}

		return response.toString();

	}

	@RequestMapping(value = "/refund-checksum/verify", method = RequestMethod.POST, headers = "Accept=application/json")
	public String checksumVerify(@RequestBody TransactionRefund transactionRefund) throws Exception {

		String paytmChecksum = null;
		String validate = null;
		JSONObject response = new JSONObject();
		// Create a tree map from the form post param
		TreeMap<String, String> paytmParams = new TreeMap<String, String>();
		// Request is HttpServletRequest
		paytmParams.put("mid", transactionRefund.getMid());
		paytmParams.put("orderId", transactionRefund.getOrderId());
		paytmParams.put("refId", transactionRefund.getRefId());
		paytmParams.put("txnId", transactionRefund.getTxnId());
		paytmParams.put("refundAmount", transactionRefund.getRefundAmount());
		paytmParams.put("txnType", transactionRefund.getTxnType());

		paytmParams.put("CHECKSUMHASH", transactionRefund.getChecksumHash(appProperties.getMerchantKey()));

		for (Entry<String, String> requestParamsEntry : paytmParams.entrySet()) {
			if (requestParamsEntry.getKey().equals("CHECKSUMHASH")) {
				paytmChecksum = requestParamsEntry.getValue();
			} else {
				paytmParams.put(requestParamsEntry.getKey(), requestParamsEntry.getValue());
			}
		}
		// Call the method for verification
		boolean isValidChecksum = CheckSumServiceHelper.getCheckSumServiceHelper()
				.verifycheckSum(appProperties.getMerchantKey(), paytmParams, paytmChecksum);
		// If isValidChecksum is false, then checksum is not valid
		System.out.println("checksum is --" + isValidChecksum);
		if (isValidChecksum) {
			response.put("message", "Checksum Matched");
			response.put("checksumhash", paytmChecksum);
			response.put("status", 200);
		} else {
			response.put("message", "Checksum is not match");
			response.put("checksumhash", paytmChecksum);
			response.put("status", 501);
		}

		return response.toString();

	}

}