package com.cricplay.pgi.services;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.model.TransactionStatusRequest;
import com.cricplay.pgi.model.TransactionStatusResponse;

@Service
public class TransactionStatusServiceImpl implements TransactionStatusService{

	public static final Logger LOGGER = Logger.getLogger(GetOrderServiceImpl.class);
	
	@Autowired
	AppProperties appProperties;

	@Autowired
	RestTemplate restTemplate;
	

	@Override
	public ResponseEntity<TransactionStatusResponse> getTransactionStatus(TransactionStatusRequest payload) {
		
		JSONObject json = new JSONObject(payload);
		String payloadjson=json.toString();
		
		HttpHeaders headers=new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> request=new HttpEntity<String>(payloadjson,headers);
		
		return restTemplate.postForEntity(appProperties.getTransactionStatusUrl(), request, TransactionStatusResponse.class);
	}

}
