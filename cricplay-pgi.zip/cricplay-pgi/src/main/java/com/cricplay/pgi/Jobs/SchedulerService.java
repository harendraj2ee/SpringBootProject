package com.cricplay.pgi.Jobs;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * SchedulerService is responsible to trigger following services.
 * 1. PGRefundService => Done
 * 2. PGStatusCheck
 * 3. ReconcileCreditService
 * 4. WinningCrditService
 * 5. PGRefundStatusService
 * 
 * @author infinity
 *
 */

@Component
@EnableScheduling
@ConditionalOnProperty(name="node",havingValue="BATCH")
public class SchedulerService {

	private static final Logger logger = Logger.getLogger(SchedulerService.class);
	
	@Value("${node}")
	private String node;
	
	@Autowired 
	private PGRefundService pGRefundService;
	
	@Autowired 
	private PGStatusCheckService pGStatusCheckService;
	
	@Autowired 
	private WinningCreditService winningCreditService;
	
	@Autowired 
	private ReconcileCreditPointService reconcileCreditPointService;
	
	@Autowired 
	private PGRefundStatusCheckService pGRefundStatusCheckService;
	
	/**
	 * Trigger PGRefundService
	 */


//	@Scheduled(fixedDelay = 14400000)
//	@Scheduled(cron = "${cricplay.pgi.batch.pgrefundservice.cron.expression}")

	//@Scheduled(fixedDelay = 14400000)
	@Scheduled(cron = "${cricplay.pgi.batch.pgrefundservice.cron.expression}")

	public void startPGRefundService() {
		logger.info("Going to start PG Refund Service Thread ");
		try {
			//if (StringUtils.isNotBlank(node) && node.equalsIgnoreCase(AppConstant.NODE.BATCH.getValue())){
				pGRefundService.process();
			//}
		} catch (Exception e) {
			logger.error(new StringBuilder().append("Exception in Data Ingestion thread(PGRefundService). Reason ::").append(e.getMessage()).toString());
		}
	}
	
	//@Scheduled(fixedDelay = 14400000)
	//@Scheduled(fixedDelay = 120000)
	@Scheduled(cron = "${cricplay.pgi.batch.pgstatuscheckservice.cron.expression}")
	public void startPGStatusCheckService() {
		logger.info("Going to start PG Status Check Service Thread ");
		try {
				pGStatusCheckService.process();
		} catch (Exception e) {
			logger.error(new StringBuilder().append("Exception in Data Ingestion thread(PGStatusCheckService). Reason ::").append(e.getMessage()).toString());
		}
	}
	
	//@Scheduled(fixedDelay = 120000)
	@Scheduled(cron = "${cricplay.pgi.batch.winningcreditservice.cron.expression}")
	public void startWinningCreditService() {
		logger.info("Going to start Winning Credit Service Thread ");
		try {
			winningCreditService.process();
		} catch (Exception e) {
			logger.error(new StringBuilder().append("Exception in Data Ingestion thread(WinningCreditService). Reason ::").append(e.getMessage()).toString());
		}
	}
	
	//@Scheduled(fixedDelay = 120000)
	@Scheduled(cron = "${cricplay.pgi.batch.reconcilecreditpointservice.cron.expression}")
	public void startReconcileCreditPointService() {
		logger.info("Going to start ReconcileCreditPointService Thread ");
		try {
			reconcileCreditPointService.process();
		} catch (Exception e) {
			logger.error(new StringBuilder().append("Exception in Data Ingestion thread(ReconcileCreditPointService). Reason ::").append(e.getMessage()).toString());
		}
	}
	
	//@Scheduled(fixedDelay = 14400000)
	@Scheduled(cron = "${cricplay.pgi.batch.pgrefundcheckservice.cron.expression}")
	public void startPGRefundStatusCheckService() {
		logger.info("Going to start PGRefundStatusCheckService Thread ");
		try {
			pGRefundStatusCheckService.process();
		} catch (Exception e) {
			logger.error(new StringBuilder().append("Exception in Data Ingestion thread(PGRefundStatusCheckService). Reason ::").append(e.getMessage()).toString());
		}
	}
	


}
