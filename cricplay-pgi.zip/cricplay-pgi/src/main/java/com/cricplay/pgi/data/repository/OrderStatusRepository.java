package com.cricplay.pgi.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchTransactionEntity;
import com.cricplay.pgi.data.entity.OrderStatusEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;

public interface OrderStatusRepository extends JpaRepository<OrderStatusEntity, String> {
	

	@Query(value = "SELECT * FROM pg_batch_configuration where batch_type=?", nativeQuery = true)
	BatchConfigurationEntity findByBatchType(String batchType);
	
	@Query(value = "UPDATE * FROM pg_batch_transaction where batch_type=?", nativeQuery = true)
	BatchTransactionEntity findByBatchId(String batchType);
	

	@Query(value = "SELECT * FROM pg_order where status=?", nativeQuery = true)
	List<OrderStatusEntity> findOrderListByStatus(String status);
	
	
	@Query(value = "UPDATE pg_batch_job SET batch_size = ? WHERE id = ?" , nativeQuery = true)
	OrderStatusEntity findOrderById(Integer batchsize, Integer id);

}
