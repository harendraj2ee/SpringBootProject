package com.cricplay.pgi.model;

import java.io.Serializable;

public class CoinCreditResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String status;
	String transId;
	String currency;
	Double balance;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTransId() {
		return transId;
	}
	public void setTransId(String transId) {
		this.transId = transId;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	
}
