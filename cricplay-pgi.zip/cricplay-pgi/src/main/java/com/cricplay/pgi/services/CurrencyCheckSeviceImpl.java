package com.cricplay.pgi.services;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.model.CurrencyStatusCheckResponse;

/**
 * 
 * @author infinity labs
 *
 */
@Service
public class CurrencyCheckSeviceImpl implements CurrencyCheckSevice{
	
	public static final Logger LOGGER = Logger.getLogger(CurrencyCheckSeviceImpl.class);
	
	@Autowired
	RestTemplate restTemplate;
	
	@Autowired
	AppProperties appProperties;
	
	
	/**
	 * Service to check RequestId status
	 */
	@Override
	public ResponseEntity<CurrencyStatusCheckResponse> currencyStatusCheck(String requestId) {
		
		LOGGER.debug("currencyStatusCheck start..."+ requestId);
		ResponseEntity<CurrencyStatusCheckResponse> response=null;
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		
		HttpEntity<String> request = new HttpEntity<String>(headers);
		String currencyCheckUrl=appProperties.getCurrencyCheckUrl()+"?"+"requestId="+requestId;
		
		try {
			response = restTemplate.exchange(currencyCheckUrl, HttpMethod.GET, request, CurrencyStatusCheckResponse.class);
			LOGGER.debug("currency check status found :"+""+response);
		}catch(Exception e) {
			LOGGER.debug("Error while getting response of currency status check");
		}
		return response;
	}
}
