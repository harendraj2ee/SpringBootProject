package com.cricplay.pgi.Jobs;

import java.util.Date;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.clevertap.model.CleverTap;
import com.cricplay.pgi.clevertap.model.CleverTapEvtDataRequest;
import com.cricplay.pgi.clevertap.model.CleverTapUploadResponse;
import com.cricplay.pgi.component.CleverTapPayloadBuilder;
import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.constants.AppConstant.EVENT_TYPE;
import com.cricplay.pgi.constants.AppConstant.PAYMENT_TYPE;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.BatchConfigurationEntity;
import com.cricplay.pgi.data.entity.BatchJobEntity;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.entity.TransDetailsEntitySinglton;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionRefundEntity;
import com.cricplay.pgi.data.repository.PlanRepository;
import com.cricplay.pgi.data.repository.TransactionDetailsRepository;
import com.cricplay.pgi.model.CurrencyStatusCheckResponse;
import com.cricplay.pgi.model.DebitCreditRequest;
import com.cricplay.pgi.model.DebitResponse;
import com.cricplay.pgi.model.MetaData;
import com.cricplay.pgi.services.BatchConfigurationService;
import com.cricplay.pgi.services.CleverTapEventUploadService;
import com.cricplay.pgi.services.CurrencyCheckSevice;
import com.cricplay.pgi.services.TransactionRefundService;
import com.cricplay.pgi.util.CommonUtil;
import com.paytm.pg.merchant.CheckSumServiceHelper;

/**
 * 
 * @author infinity labs
 *
 */
@Transactional
@Service
public class WinningCreditService extends BatchService{

	private static final Logger logger = Logger.getLogger(WinningCreditService.class);
	
	@Value("${cricplay.pgi.winning.credit.batch.rerty.threshold}")
	private Integer retryThreshold;

	@Autowired
	private BatchConfigurationService batchConfigurationService;

	@Autowired
	private TransactionDao transactionDao;

	@Autowired
	private TransactionRefundService transactionRefundService;

	@Autowired
	private AppProperties appProperties;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private OrderDao orderDao;
	
	@Autowired
	private PlanRepository planRepository;
	
	@Autowired
	private CurrencyCheckSevice currencyCheckService;
	
	@Autowired
	private TransactionDetailsRepository transactionDetailsRepository;
	
	@Autowired
	CleverTapEventUploadService cleverTapEventUploadService;
	
	@Autowired
	CleverTapPayloadBuilder builder;


	/**
	 * Trigger batch process for PGRefundService
	 */
		@Override
		public void process() {

			BatchJobEntity batchJobEntity=null;

			try {
				//Step 1 : Get BatchConfigurationEntity object
				BatchConfigurationEntity batchConfigurationEntity = batchConfigurationService.findBatchConfigurationByType(AppConstant.JOB_TYPE.WINNINGCREDIT.getJobType());
				
				logger.info("\n Batch Configruation enity list data " + batchConfigurationEntity);
				
				//Step 2 : Trigger process if the current status is not in "Running"
				if (!RUNNING_STATUS.equalsIgnoreCase(batchConfigurationEntity.getCurrentStatus())) {

					batchJobEntity =batchConfigDataInitialize(RUNNING_STATUS, batchConfigurationEntity);
					
					//Step 5 : Get list of records from TransactionRefund table
					Set<TransactionRefundEntity> transactionRefundStatusList = transactionRefundService.findTransactionRefundByRefundStatus(INITIATED_STATUS,WINNING_BATCH_TRANSACTION_STATUS);

					//Step 6 : Start process each transaction from batch against records get from TransactionRefund table
					for (TransactionRefundEntity transactionRefundEntity : transactionRefundStatusList) {
						
						logger.info("\n Process Transaction Refund Entity " + transactionRefundEntity);
						
						// Step 7: Verify winning credit existance for transactionId
						
						TransactionEntity transactionEntity=transactionDao.getTransactionEntity(transactionRefundEntity.getTransId());
						if(transactionEntity!=null && StringUtils.isNotBlank(transactionEntity.getWinningCreditRequest())) {
							
							String winningCreditRequest = transactionEntity.getWinningCreditRequest();
							
							ResponseEntity<CurrencyStatusCheckResponse> currencyCheckResponse=currencyCheckService.currencyStatusCheck(winningCreditRequest);
							//checking if requestId exist in previous coin credit request
							if(currencyCheckResponse!=null && currencyCheckResponse.getStatusCodeValue()==200) {
								transactionRefundEntity.setRefundStatus("Success");
								transactionDao.saveTransactionRefund(transactionRefundEntity);
								
								// insert new record into transactionrefund history table
								insertRecordTransactionRefundHistory(transactionRefundEntity, null);
							}
							// not validate the request id
							else {
								processTransactionData(transactionRefundEntity, transactionEntity);
							}
							
							
						}
						else {
							processTransactionData(transactionRefundEntity, transactionEntity);
						}
						
					}
						
					if(batchJobEntity!=null) {
						batchConfigStatusUpdate(batchJobEntity, transactionRefundStatusList.size(), batchConfigurationEntity);
					}
					


				} else {

					logger.info("Winning Batch process could not start, Because process is running mode");
				}

			} catch (Exception e) {
				logger.error("Exception occured while creating order::" + e.getMessage());
				e.printStackTrace();

			}
		}

	/**
	 * 
	 * @param transactionRefundEntity
	 * @param transactionEntity
	 * @throws Exception
	 */
	private void processTransactionData(TransactionRefundEntity transactionRefundEntity,
			TransactionEntity transactionEntity) throws Exception {
		String requestId = CommonUtil.generateRequestId(transactionRefundEntity.getOrderId());
		
		// insert new record into transaction detail table
/*		TransDetailsEntitySinglton transDetailsEntity = new TransDetailsEntitySinglton();
		//TODO: Set the fields data
		transDetailsEntity.setCreatedOn(new Date());
		transDetailsEntity.setEventType(EVENT_TYPE.PRO_WINNING_REFUND.getValue());
		transDetailsEntity.setModifiedOn(new Date());
		transDetailsEntity.setPaymentType(PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
		transDetailsEntity.setRequestId(requestId);
		if(null!=transactionEntity.getTransId()) {
		transDetailsEntity.setTransId(transactionEntity.getTransId());
		}
		else {
		transDetailsEntity.setTransId(0);
		}
		if(transactionEntity.getRespmsg()!=null) {
		transDetailsEntity.setDescription(transactionEntity.getRespmsg());
		}else {
			transDetailsEntity.setDescription("");
		}
		transDetailsEntity.setUserId(transactionEntity.getUserId());
		transDetailsEntity.setStatus(transactionRefundEntity.getRefundStatus());
		transactionDetailsRepository.save(transDetailsEntity);*/
		
		// update transaction table
		transactionEntity.setWinningCreditRequest(requestId);
		transactionEntity.setModified_on(new Date());
		updateTransaction(transactionEntity);
		
		
		OrderEntity orderEntity = orderDao.findOrderById(transactionRefundEntity.getOrderId());
		PlanEntity planEntity =planRepository.findPlanById(orderEntity.getPlanId());
		ResponseEntity<DebitResponse> response = debitCreditUserWinning(String.valueOf(orderEntity.getUserId()), planEntity, orderEntity, EVENT_TYPE.PRO_WINNING_REFUND.getValue(), Double.valueOf(transactionRefundEntity.getRefundAmount()),requestId);
		
		if(response!=null) {
		JSONObject responseRefundBody = new JSONObject(response.getBody());
		logger.info("Response : "+responseRefundBody);
		
		//Step 9 : if status of response is not equal to 200 and retryThreshold is greater than retryCounter then update transaction_refund table with Failed status.
		if (!responseRefundBody.get("status").equals("SUCCESS")){
			
			if(retryThreshold>transactionRefundEntity.getRetryCounter()) {
				transactionRefundEntity.setRefundStatus("Failed");
				transactionDao.saveTransactionRefund(transactionRefundEntity);
				
			}
			//Step 10 : Update retryCounter into transaction_refund table
			else {
				if(transactionRefundEntity.getRetryCounter()!=null && transactionRefundEntity.getRetryCounter()>0) {
					transactionRefundEntity.setRetryCounter(transactionRefundEntity.getRetryCounter()+1);
				}
				else {
					transactionRefundEntity.setRetryCounter(1);
				}
				transactionDao.saveTransactionRefund(transactionRefundEntity);
			}
		}	
		
		else {
			
			// trigger clever tap.
			
			CleverTapEvtDataRequest evtDataRequest= new CleverTapEvtDataRequest();
			evtDataRequest.setStatus("REFUND_WIN");
			evtDataRequest.setAmount(orderEntity.getPrice());
			evtDataRequest.setDesc(orderEntity.getCoins()+"coins");
			evtDataRequest.setPlanId(planEntity.getPlanId());
			evtDataRequest.setPgAmount(planEntity.getAmount()-Double.valueOf(transactionRefundEntity.getRefundAmount()));
			evtDataRequest.setWinAmount(Double.valueOf(transactionRefundEntity.getRefundAmount()));
			CleverTap evtData=builder.buildCleverTapPayload(evtDataRequest, CommonUtil.generateRequestId(orderEntity.getOrderId()));
			ResponseEntity<CleverTapUploadResponse> res=cleverTapEventUploadService.cleverTapUploadEvent(evtData);
			logger.debug("clever tap event trigger response ::"+res.getStatusCodeValue());
			
			transactionRefundEntity.setRefundStatus("Success");
			transactionDao.saveTransactionRefund(transactionRefundEntity);
			// update order status to refunded for winning refund success.
			orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.REFUNDED.getValue(), new Date(), orderEntity.getOrderId());
			
		}
		}	
		// insert new record into transactionrefund history table
		insertRecordTransactionRefundHistory(transactionRefundEntity, null);
	}
		
		/**
		 * Build Payload for rest api call
		 * @param refundStatusObj
		 * @return TreeMap<String, String>
		 */
		public TreeMap<String, String> buildPayload(TransactionRefundEntity refundStatusObj) {
			String merchantMid = appProperties.getMerchantId();
			Integer orderId = refundStatusObj.getOrderId();
			String merchantKey = appProperties.getMerchantKey();
			String transactionType = refundStatusObj.getTranscationType();
			String refundAmount = refundStatusObj.getRefundAmount();
			//String transactionId = refundStatusObj.getPgRefundTransId();
			String transactionId = String.valueOf(refundStatusObj.getId());
			
			String refId = refundStatusObj.getTransactionRefId();

			TreeMap<String, String> paytmParams = new TreeMap<String, String>();
			paytmParams.put("MID", merchantMid);
			paytmParams.put("REFID", refId);
			paytmParams.put("TXNID", transactionId);
			paytmParams.put("ORDERID", orderId.toString());
			paytmParams.put("REFUNDAMOUNT", refundAmount);
			paytmParams.put("TXNTYPE", transactionType);
			try {
			paytmParams.put("CHECKSUM", CheckSumServiceHelper.getCheckSumServiceHelper().genrateRefundCheckSum(merchantKey, paytmParams));
			} catch (Exception ex) {
				logger.info("OrderId :"+ orderId);
				logger.info("Internal TransactionId :"+transactionId);
				logger.info("Internal TransactionRefundId :"+refId);
				logger.info("Error Message "+ex.getMessage());
				ex.printStackTrace();
			}
			return paytmParams;
		}
		
		/**
		 * Winning refund CRICPLAY Rest API call
		 * @param userId
		 * @param planEntity
		 * @param orderEntity
		 * @param eventType
		 * @param amount
		 * @param requestId
		 * @return ResponseEntity<DebitResponse>
		 */
		public ResponseEntity<DebitResponse> debitCreditUserWinning(String userId, PlanEntity planEntity, OrderEntity orderEntity,String eventType,Double amount,String requestId){
			logger.debug("\n debit winning balance start...");
			MetaData metaData=new MetaData();
			metaData.setOrderId("PG".concat(orderEntity.getOrderId().toString()));
			metaData.setPlanName(planEntity.getPlanName());
			DebitCreditRequest data=new DebitCreditRequest();
			data.setRequestId(requestId);
			data.setEvent(eventType);
			data.setUserId(userId);
			data.setAmount(amount);
			data.setMetadata(metaData);
			
			JSONObject obj = new JSONObject(data);
			String strJson = obj.toString();
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			logger.debug("\n Payload for WinningDebit ::"+strJson);
			ResponseEntity<DebitResponse> response=null;
			HttpEntity<String> request = new HttpEntity<String>(strJson, headers);
			try {
				response=restTemplate.postForEntity(appProperties.getWinningDebitUrl(), request, DebitResponse.class);
				logger.info("\n Response from winningDebit service ::"+response.getStatusCodeValue());
			}catch(Exception e) {
				logger.debug("Error whille getting response from winning credit.");
				logger.debug("Exception ::"+e.getCause());
			}
			return response;
		}
		
}