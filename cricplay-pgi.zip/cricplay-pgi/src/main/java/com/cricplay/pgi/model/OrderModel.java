package com.cricplay.pgi.model;

import java.io.Serializable;
import java.util.Date;


/**
 * 
 * @author infinity labs
 *
 */

 public class OrderModel  implements Serializable{
	
	private static final long serialVersionUID = 1L;
	 String orderId;
	 Integer planId;
	 String planName;
	 String orderStatus;
	 String createdOn;
	 String modifiedOn;
	 Double winningBalanceUsed;
	 Double amountPaidByPG;
	 Double amountPaid;
	 Integer coins;
	 String message;
	 


	public Integer getPlanId() {
		return planId;
	}
	public void setPlanId(Integer planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public Double getWinningBalanceUsed() {
		return winningBalanceUsed;
	}
	public void setWinningBalanceUsed(Double winningBalanceUsed) {
		this.winningBalanceUsed = winningBalanceUsed;
	}
	public Double getAmountPaidByPG() {
		return amountPaidByPG;
	}
	public void setAmountPaidByPG(Double amountPaidByPG) {
		this.amountPaidByPG = amountPaidByPG;
	}
	public Double getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(Double amountPaid) {
		this.amountPaid = amountPaid;
	}
	
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}

	 
	 
	

	public Integer getCoins() {
		return coins;
	}
	public void setCoins(Integer coins) {
		this.coins = coins;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	
	@Override
	public String toString() {
		return "OrderModel [orderId=" + orderId + ", planId=" + planId + ", planName=" + planName + ", orderStatus="
				+ orderStatus + ", createdOn=" + createdOn + ", modifiedOn=" + modifiedOn + ", winningBalanceUsed="
				+ winningBalanceUsed + ", amountPaidByPG=" + amountPaidByPG + ", amountPaid=" + amountPaid + ", coins="
				+ coins + ", message=" + message + "]";
	}
	
}
