package com.cricplay.pgi.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricplay.pgi.dao.BatchConfigurationDao;
import com.cricplay.pgi.data.entity.BatchConfigurationEntity;

@Service
public class BatchConfigurationServiceImpl implements BatchConfigurationService{
	
	@Autowired
	BatchConfigurationDao batchConfigurationDao;

	@Override
	public BatchConfigurationEntity findBatchConfigurationByType(String batchType) throws Exception{
		
		return batchConfigurationDao.findBatchConfigurationByType(batchType);
	}

	@Override
	public BatchConfigurationEntity updateBatchConfigurationById(String currentStatus,String batchStatus, Integer Id) throws Exception {
		
		return batchConfigurationDao.UpdateBatchConfigurationById(currentStatus,batchStatus, Id);
	}

	@Override
	public BatchConfigurationEntity findBatchConfigurationByStatus() {
		// TODO Auto-generated method stub
		return null;
	}


}
