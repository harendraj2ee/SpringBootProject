package com.cricplay.pgi.data.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.entity.TransactionEntitySinglton;

@Repository
public interface TransactionSingletonRepository extends JpaRepository<TransactionEntitySinglton, Integer>{

	@Query(value = "SELECT * FROM pg_transaction where trans_id=?", nativeQuery = true)
	TransactionEntity findTransacitonById(Integer orderId);
	
	@Transactional
	@Modifying()
	@Query(value ="update pg_transaction set trans_status=?, modified_on=? where trans_id=?", nativeQuery = true)
	int updateTransactionStatusById(String status,Date date,Integer transId);
	
	@Query(value="select trans_id from pg_transaction where order_id=? and payment_type=?", nativeQuery = true)
	Integer findTransactionIdByOrderIdAndPaymentType(Integer orderId, String paymentType);
	
	@Query(value="select * from pg_transaction where order_id=? and payment_type=?", nativeQuery = true)
	Object[] findTransactionByOrderIdAndPaymentType(Integer orderId,String paymentType);
	
	@Query(value="select * from pg_transaction where order_id=? and payment_type=?", nativeQuery = true)
	TransactionEntity findTransByOrderIdAndPaymentType(Integer orderId,String paymentType);
	
	@Transactional
	@Modifying()
	@Query(value ="UPDATE pg_transaction SET trans_status =?, pg_txnid =?, bank_txnid = ?, txn_type =?, gateway_name =?, respcode =?, respmsg=?, bank_name =?, payment_mode =?, refund_amt =?, txn_date =? WHERE order_id =? and payment_type=?;", nativeQuery = true)
	int updatePgTransaction(String transStatus,String pgTxnId,String bankTxnId,String txnType,String gatewayName,String respCode,String respmsg, String bankName,String paymentMode,String refundAmt,String txnDate,Integer orderId,String paymentType);
	
	
	@Query(value="select * from pg_transaction where order_id=?", nativeQuery = true)
	List<TransactionEntity> findTransByOrderId(Integer orderId);
	
	@Query(value="select * from pg_transaction where trans_status=?", nativeQuery = true)
	List<TransactionEntity> findTransactionStatusBytransStatus(String transStatus);
	
	@Query(value = "SELECT * FROM pg_transaction where order_id=?", nativeQuery = true)
	List<TransactionEntitySinglton> findTransacitonByOrderId(Integer orderId); 
	
	@Query(value="select * from pg_transaction where trans_status=? and payment_type=?", nativeQuery = true)
	List<TransactionEntitySinglton> getTransactionEntityList(String transStatus,String paymentType);
	
	
}
