package com.cricplay.pgi.services;

import java.text.DecimalFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.cricplay.pgi.clevertap.model.CleverTap;
import com.cricplay.pgi.clevertap.model.CleverTapEvtDataRequest;
import com.cricplay.pgi.clevertap.model.CleverTapUploadResponse;
import com.cricplay.pgi.component.CleverTapPayloadBuilder;
import com.cricplay.pgi.config.AppProperties;
import com.cricplay.pgi.constants.AppConstant;
import com.cricplay.pgi.constants.PGResponseCodes;
import com.cricplay.pgi.dao.OrderDao;
import com.cricplay.pgi.dao.TransactionDao;
import com.cricplay.pgi.data.entity.OrderEntity;
import com.cricplay.pgi.data.entity.OrderStatusEntity;
import com.cricplay.pgi.data.entity.PlanEntity;
import com.cricplay.pgi.data.entity.TransDetailsEntity;
import com.cricplay.pgi.data.entity.TransactionEntity;
import com.cricplay.pgi.data.repository.TransDetailsRepository;
import com.cricplay.pgi.data.repository.TransactionDetailsRepository;
import com.cricplay.pgi.model.Checksum;
import com.cricplay.pgi.model.CoinCreditRequest;
import com.cricplay.pgi.model.CoinCreditResponse;
import com.cricplay.pgi.model.DebitCreditRequest;
import com.cricplay.pgi.model.DebitResponse;
import com.cricplay.pgi.model.MetaData;
import com.cricplay.pgi.model.Order;
import com.cricplay.pgi.model.OrderResponse;
import com.cricplay.pgi.model.ShareItToken;
import com.cricplay.pgi.model.VerifyUserResponse;
import com.cricplay.pgi.model.Wallet;
import com.cricplay.pgi.model.Wallets;
import com.cricplay.pgi.util.CommonUtil;

@Service
public class CreateOrderServiceImpl implements CreateOrderService {

	public static final Logger LOGGER = Logger.getLogger(CreateOrderServiceImpl.class);

	@Autowired
	AppProperties appProperties;

	@Autowired
	OrderDao orderDao;

	@Autowired
	TransDetailsRepository transDetailsRepository;

	@Autowired
	TransactionDetailsRepository transactionDetailsRepository;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	CoinCreditProcess coinCreditProcess;

	@Autowired
	CleverTapEventUploadService cleverTapEventUploadService;

	@Autowired
	CleverTapPayloadBuilder builder;

	@Autowired
	TransactionUpdateService transactionUpdateService;
	
	@Autowired
	TransactionDao transactionDao;

	public OrderResponse createOrder(Order order, String authToken, String language) throws Exception {

		OrderResponse orderResponse = null;

		String userUniqueId = null;
		PlanEntity planEntity;
		Double winningBalance = null;
		String orderType = null;
		String pgVendor = null;

		LOGGER.debug("verify user start...");
		ResponseEntity<VerifyUserResponse> verifyUserResponse = verifyUser(authToken);
		LOGGER.debug("verify user end.");

		if (!StringUtils.isEmpty(verifyUserResponse) && verifyUserResponse.getStatusCodeValue() == 200) {
			userUniqueId = verifyUserResponse.getBody().getUserUniqueId();
			LOGGER.debug("userUniqueId :" + userUniqueId);

			if (!StringUtils.isEmpty(userUniqueId)) {
				planEntity = orderDao.findPlanById(order.getPlanId());
				if(planEntity !=null) {
				if (order.isUseWinning() == true) {
					// fetch winnign amout from cricplya api

					winningBalance = getWinningBalance(userUniqueId);

					if (order.isUseWinning() == true && winningBalance >= planEntity.getAmount()) {
						orderType = AppConstant.ORDER_TYPE.WINNINGS_ONLY.getValue();
					} else if (order.isUseWinning() == true && winningBalance < planEntity.getAmount()) {
						orderType = AppConstant.ORDER_TYPE.WINNING_AND_PG.getValue();
						pgVendor = order.getPayMode();
					}

					LOGGER.info("order type :" + "" + orderType);
					if (winningBalance != null && winningBalance >= planEntity.getAmount()) {
						// winning only case
						LOGGER.debug("persisting order start...");
						OrderEntity orderEntity = orderDao.persistTransaction(planEntity, userUniqueId, winningBalance,
								orderType, pgVendor);
						LOGGER.debug("order persisted ::" + orderEntity.getOrderId());

						if (orderEntity != null && null != orderEntity.getOrderId()) {

							// call winning debit api
							LOGGER.debug("\n calling debitCreditUserWinning for winning debit...");
							ResponseEntity<DebitResponse> winningDebitResponse = debitCreditUserWinning(userUniqueId,
									planEntity, orderEntity, AppConstant.EVENT_TYPE.PRO_WINNING_DEBIT.getValue(),
									planEntity.getAmount());
							LOGGER.info("\n Response of debit Winning ::" + winningDebitResponse.getStatusCodeValue());

							if (!StringUtils.isEmpty(winningDebitResponse)
									&& winningDebitResponse.getStatusCodeValue() == 200) {
								// update transaction status.
								LOGGER.debug("\n updatating transaction status start...");

								Set<TransactionEntity> transacitonEnties = orderEntity.getTransactions();
								TransactionEntity transactionEntity = transacitonEnties.iterator().next();
								//LOGGER.debug("Transaction Entity ::" + transactionEntity.toString());

								int count = orderDao.updateTransactionStatusById(
										AppConstant.TXN_STATUS.SUCCESS.getValue(),AppConstant.TRANS_DESCRIPTION.SUCCESS.getValue(), new Date(),
										transactionEntity.getTransId());
								// create new entry in transdtl table here.
								transactionEntity.setTransStatus(AppConstant.TXN_STATUS.SUCCESS.getValue());
								transactionEntity.setDescription(AppConstant.TRANS_DESCRIPTION.SUCCESS.getValue());
								TransDetailsEntity transDtlEntity=orderDao.buildTransDetails(transactionEntity);
								transactionDao.createTransDetail(transDtlEntity);
								
								if (count == 1) {
									LOGGER.debug("\n transaction status updated. calling coing credit...");

									int respCode = coinCreditProcess.initiateCoinCreditProcess(orderEntity, language);

									LOGGER.info("\n Response of coin credit ::" + respCode);

									if (respCode == 200) { // coin credit process success case
										// clever tap event trigger for Successful purchase of coins
										CleverTapEvtDataRequest evtDataRequest = new CleverTapEvtDataRequest();
										evtDataRequest.setStatus(AppConstant.TXN_STATUS.SUCCESS.getValue());
										evtDataRequest.setAmount(orderEntity.getPrice());
										evtDataRequest.setDesc(orderEntity.getCoins() + "coins");
										evtDataRequest.setPlanId(planEntity.getPlanId());
										evtDataRequest.setPgAmount(planEntity.getAmount() - winningBalance);
										evtDataRequest.setWinAmount(winningBalance);
										CleverTap evtData = builder.buildCleverTapPayload(evtDataRequest, userUniqueId);
										ResponseEntity<CleverTapUploadResponse> res = cleverTapEventUploadService
												.cleverTapUploadEvent(evtData);
										LOGGER.debug("clever tap event trigger response ::" + res.getStatusCodeValue());
										LOGGER.debug("\n update order status start...");

										Integer countValue = orderDao.updateOrderStatusById(
												AppConstant.ORDER_STATUS.SUCCESS.getValue(), new Date(),
												orderEntity.getOrderId());
										if (countValue != null && countValue == 1) {
											LOGGER.debug("order status updated.");
											orderResponse = new OrderResponse();
											orderResponse.setStatusCode(respCode);
											orderResponse
													.setOrderId(CommonUtil.appendOrderPrefix(orderEntity.getOrderId()));
											orderResponse.setStatus("SUCCESS");
											orderResponse.setMessage("Order Created Successfully");
											return orderResponse;
										} else {
											LOGGER.info("Update Order Status failed. Status response of query ::"
													+ countValue);
										}
									}
									// coin credit process failure case.
									else {
										// clever tap event trigger for Failed purchase of coins
										CleverTapEvtDataRequest evtDataRequest = new CleverTapEvtDataRequest();
										evtDataRequest.setStatus(AppConstant.TXN_STATUS.FAIL.getValue());
										evtDataRequest.setAmount(orderEntity.getPrice());
										evtDataRequest.setDesc(orderEntity.getCoins() + "coins");
										evtDataRequest.setPlanId(planEntity.getPlanId());
										evtDataRequest.setPgAmount(planEntity.getAmount() - winningBalance);
										evtDataRequest.setWinAmount(winningBalance);
										CleverTap evtData = builder.buildCleverTapPayload(evtDataRequest, userUniqueId);
										ResponseEntity<CleverTapUploadResponse> res = cleverTapEventUploadService
												.cleverTapUploadEvent(evtData);
										LOGGER.debug("clever tap event trigger response ::" + res.getStatusCodeValue());

										// Refund winnings will be part of batch reconcillation.
										// here order status update only(order fail)
										LOGGER.debug("\n Order fail due to coin credit api fail.");
										orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.FAIL.getValue(),
												new Date(), orderEntity.getOrderId());
										orderResponse = new OrderResponse();
										orderResponse.setStatusCode(respCode);
										orderResponse
												.setStatus(PGResponseCodes.PG_RESPONSE_CODE_DESCRIPTION.get(respCode));
										orderResponse
												.setMessage(PGResponseCodes.PG_RESPONSE_CODE_COMMENT.get(respCode));
										return orderResponse;
									}
								}

							} else {
								LOGGER.info("\n Order fail due to winning debit api fail.");
								orderDao.updateOrderStatusById(AppConstant.ORDER_STATUS.FAIL.getValue(),
												new Date(), orderEntity.getOrderId());
								orderResponse = new OrderResponse();
								orderResponse.setStatusCode(winningDebitResponse.getStatusCodeValue());
								orderResponse.setStatus(PGResponseCodes.PG_RESPONSE_CODE_DESCRIPTION
										.get(winningDebitResponse.getStatusCodeValue()));
								orderResponse.setMessage(PGResponseCodes.PG_RESPONSE_CODE_COMMENT
										.get(winningDebitResponse.getStatusCodeValue()));
								return orderResponse;
							}
						}
					} else if (winningBalance > 0.0 && winningBalance < planEntity.getAmount()) {
						// debit all winning(call wallet debit api)(Winning+PG case)
						// create checksum and return the same
						DecimalFormat df = new DecimalFormat("####0.00");
						Double pgAmount = Double.parseDouble(df.format(planEntity.getAmount() - winningBalance));

						// Double txnAmount=planEntity.getAmount()-winningBalance;

						LOGGER.info("\n Winning + PG case :: Txn amount for PG :" + "" + pgAmount);
						OrderEntity orderEntity = orderDao.persistTransaction(planEntity, userUniqueId, winningBalance,
								orderType, pgVendor);

						ResponseEntity<DebitResponse> response = debitCreditUserWinning(userUniqueId, planEntity,
								orderEntity, AppConstant.EVENT_TYPE.PRO_WINNING_DEBIT.getValue(), winningBalance);

						LOGGER.debug("\n response from debitCreditUserWinnings ::" + response.getStatusCodeValue());
						if (response != null && response.getStatusCodeValue() == 200) {
							orderResponse = new OrderResponse();
							if (!order.getPayMode().equalsIgnoreCase("shareit")) {
								Checksum checksum = buildChecksum(order, orderEntity, userUniqueId, pgAmount.toString());
								String checkSumHash = checksum.getChecksumHash(appProperties.getMerchantKey());
								checksum.setCheckSumHash(checkSumHash);
								orderResponse.setChecksum(checksum);
							} else {
								orderResponse.setToken(getSharitToken(planEntity,orderEntity,userUniqueId,pgAmount.toString()));
							}
							
							//Checksum checksum = buildChecksum(order, orderEntity, userUniqueId, pgAmount.toString());
							//String checkSumHash = checksum.getChecksumHash(appProperties.getMerchantKey());
							//checksum.setCheckSumHash(checkSumHash);
							
							orderResponse.setOrderId(CommonUtil.appendOrderPrefix(orderEntity.getOrderId()));
							//orderResponse.setChecksum(checksum);
							orderResponse.setStatusCode(response.getStatusCodeValue());
							orderResponse.setStatus(
									PGResponseCodes.PG_RESPONSE_CODE_DESCRIPTION.get(response.getStatusCodeValue()));
							orderResponse.setMessage(
									PGResponseCodes.PG_RESPONSE_CODE_COMMENT.get(response.getStatusCodeValue()));

							// mark winning transaction as success
							Integer winningTranId = transactionUpdateService.findTransactionIdByOrderIdAndPaymentType(
									orderEntity.getOrderId(),
									AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue());
							orderDao.updateTransactionStatusById(AppConstant.TXN_STATUS.SUCCESS.getValue(),AppConstant.TRANS_DESCRIPTION.SUCCESS.getValue(), new Date(), winningTranId);
							TransactionEntity transactionEntity=transactionDao.getTransactionEntity(winningTranId);
							//create new entry in transdtls table here
							transactionEntity.setTransStatus(AppConstant.TXN_STATUS.SUCCESS.getValue());
							transactionEntity.setDescription(AppConstant.TRANS_DESCRIPTION.SUCCESS.getValue());
							TransDetailsEntity transDtlEntity=orderDao.buildTransDetails(transactionEntity);
							transactionDao.createTransDetail(transDtlEntity);
							
						}
					} else {
						orderResponse = new OrderResponse();
						orderResponse.setStatusCode(424);
						orderResponse.setStatus(PGResponseCodes.PG_RESPONSE_CODE_DESCRIPTION.get(424));
						orderResponse.setMessage(PGResponseCodes.PG_RESPONSE_CODE_COMMENT.get(424));
					}
				} else {
					// go to PAYTM for payment(only PG)
					// create/verify checksum and return the same
					orderType = AppConstant.ORDER_TYPE.PG_ONLY.getValue();
					pgVendor = order.getPayMode();
					DecimalFormat df = new DecimalFormat("####0.00");
					Double pgAmount = Double.parseDouble(df.format(planEntity.getAmount()));
					// Double pgAmount=planEntity.getAmount();
					OrderEntity orderEntity = orderDao.persistTransaction(planEntity, userUniqueId, winningBalance,	orderType, pgVendor);
					if (orderEntity != null && null != orderEntity.getOrderId()) {
						orderResponse = new OrderResponse();
						if (!order.getPayMode().equalsIgnoreCase("shareit")) {
							Checksum checksum = buildChecksum(order, orderEntity, userUniqueId, pgAmount.toString());
							String checkSumHash = checksum.getChecksumHash(appProperties.getMerchantKey());
							checksum.setCheckSumHash(checkSumHash);
							orderResponse.setChecksum(checksum);
						} else {
							orderResponse.setToken(getSharitToken(planEntity,orderEntity,userUniqueId,pgAmount.toString()));
						}

						
						orderResponse.setStatusCode(200);
						orderResponse.setOrderId(CommonUtil.appendOrderPrefix(orderEntity.getOrderId()));

						orderResponse.setStatus("SUCCESS");
						orderResponse.setMessage("Order Created Successfully");
						return orderResponse;
					}
				}
			}else {
				orderResponse = new OrderResponse();
				orderResponse.setMessage("Plan does not exist.");
			}
		}
		} else {
			// not allowed to create order
			orderResponse = new OrderResponse();
			orderResponse.setStatusCode(verifyUserResponse.getStatusCodeValue());
			orderResponse.setStatus(
					PGResponseCodes.PG_RESPONSE_CODE_DESCRIPTION.get(verifyUserResponse.getStatusCodeValue()));
			orderResponse
					.setMessage(PGResponseCodes.PG_RESPONSE_CODE_COMMENT.get(verifyUserResponse.getStatusCodeValue()));
			return orderResponse;
		}

		return orderResponse;
	}

	@Override
	public Double getWinningBalance(String userUniqueId) throws Exception {
		LOGGER.debug("\n getting user winning balance start...");
		Double winningBalance = null;
		ResponseEntity<Wallets> response = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> request = new HttpEntity<String>(headers);
		String url = appProperties.getWalletBalanceUrl() + "?" + "userId=" + userUniqueId;
		try {
			response = restTemplate.exchange(url, HttpMethod.GET, request, Wallets.class);
		} catch (Exception e) {
			LOGGER.debug("Error while getting winning balance");
		}
		if (response != null) {
			Wallets wallets = response.getBody();
			for (Wallet wallet : wallets.getWallet()) {
				if (wallet.getCurrency().equalsIgnoreCase("WINNING")) {
					winningBalance = wallet.getValue();
				}
			}
		}
		LOGGER.debug("\n winning balance found :" + "" + winningBalance);
		return winningBalance;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.cricplay.pgi.services.CreateOrderService#debitCreditUserWinning(java.lang
	 * .String, com.cricplay.pgi.data.entity.PlanEntity,
	 * com.cricplay.pgi.data.entity.OrderEntity, java.lang.String)
	 */
	@Override
	public ResponseEntity<DebitResponse> debitCreditUserWinning(String userId, PlanEntity planEntity,
			OrderEntity orderEntity, String eventType, Double amount) {
		LOGGER.debug("\n debit winning balance start...");
		String requestId = null;
		MetaData metaData = new MetaData();
		metaData.setOrderId("PG".concat(orderEntity.getOrderId().toString()));
		metaData.setPlanName(planEntity.getPlanName());
		for (TransactionEntity transaction : orderEntity.getTransactions()) {
			if (transaction.getPaymentType()
					.equalsIgnoreCase(AppConstant.PAYMENT_TYPE.WINNINGS_PAYMENT_TYPE.getValue())) {
				requestId = transaction.getWinningDebitRequest();
				LOGGER.debug("winning debit request id ::" + requestId);
			}
		}
		DebitCreditRequest data = new DebitCreditRequest();
		data.setRequestId(requestId);
		data.setEvent(eventType);
		data.setUserId(userId);
		data.setAmount(amount);
		data.setMetadata(metaData);

		JSONObject obj = new JSONObject(data);
		String strJson = obj.toString();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		LOGGER.debug("\n Payload for WinningDebit ::" + strJson);

		HttpEntity<String> request = new HttpEntity<String>(strJson, headers);
		ResponseEntity<DebitResponse> response = restTemplate.postForEntity(appProperties.getWinningDebitUrl(), request,
				DebitResponse.class);
		LOGGER.info("\n Response from winningDebit service ::" + response.getStatusCodeValue());
		return response;
	}

	/**
	 * 
	 * @param userId
	 * @param planEntity
	 * @param orderEntity
	 * @param eventType
	 * @return
	 */
	@Override
	public ResponseEntity<CoinCreditResponse> creditCoin(String userId, PlanEntity planEntity, OrderEntity orderEntity,
			String eventType) throws Exception {
		LOGGER.debug("\n coin credit start...");
		MetaData metaData = new MetaData();
		metaData.setOrderId(orderEntity.getOrderId().toString());
		metaData.setPlanName(planEntity.getPlanName());

		CoinCreditRequest data = new CoinCreditRequest();
		data.setRequestId(orderEntity.getTransactions().iterator().next().getTransId().toString());
		data.setEvent(eventType);
		data.setUserId(userId);
		data.setAmount(planEntity.getCoins());
		data.setMetadata(metaData);

		JSONObject obj = new JSONObject(data);
		String strJson = obj.toString();

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		LOGGER.debug("\n Payload for coin credit ::" + strJson);
		HttpEntity<String> request = new HttpEntity<String>(strJson, headers);

		ResponseEntity<CoinCreditResponse> response = restTemplate.exchange(appProperties.getCoinCreditUrl(),
				HttpMethod.POST, request, CoinCreditResponse.class);
		LOGGER.info("\n Response from coin credit service ::" + response.getStatusCodeValue());
		return response;

	}

	@Override
	public ResponseEntity<VerifyUserResponse> verifyUser(String authorizationToken) throws Exception {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", authorizationToken);

		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<VerifyUserResponse> response = restTemplate.exchange(appProperties.getVerifyUserUrl(),
				HttpMethod.GET, entity, VerifyUserResponse.class);
		LOGGER.info("Response from verifying User service ::" + response);
		return response;
	}

	@Override
	public Checksum buildChecksum(Order order, OrderEntity orderEntity, String userUniqueId, String txnAmount)
			throws Exception {
		Checksum checksum = new Checksum();
		String callUrl = null;
		String website = null;
		if (order.getChannelId().equals("WAP")) {
			callUrl = appProperties.getAppCallbackUrl();
			website = appProperties.getAppWebsite();
		} else {
			callUrl = appProperties.getCallbackUrl();
			website = appProperties.getWebsite();
		}
		checksum.setMid(appProperties.getMerchantId());
		checksum.setOrderId(orderEntity.getOrderId().toString());
		checksum.setCustId(userUniqueId);
		checksum.setChannelId(order.getChannelId());
		checksum.setTxnAmount(txnAmount);
		checksum.setWebsite(website);
		checksum.setIndustryTypeId(AppConstant.INDUSTRY_TYPE);
		checksum.setCallBackUrl(callUrl + checksum.getOrderId());

		LOGGER.debug("Checksum :: " + checksum.toString());
		return checksum;

	}

	@Override

//	public OrderEntity findOrderByStatus(String status) throws Exception {
//		
//		OrderEntity response=orderDao.findOrderByStatus(status);
//		return response;
//	}
	public OrderEntity findOrderById(Integer id) throws Exception {
		return orderDao.findOrderById(id);
	}

	@Override
	public List<OrderStatusEntity> findOrderListByStatus(String Status) throws Exception {
		return orderDao.findOrderListByStatus(Status);
	}

	public ShareItToken getSharitToken(PlanEntity planEntity,  OrderEntity orderEntity, String userUniqueId, String txnAmount) {

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
		// multipart form-data creating for data

		MultiValueMap<String, String> map = new LinkedMultiValueMap<String, String>();

		map.add("bizType", "token");
		map.add("merchantId", appProperties.getShareItMerchantId());
		map.add("version", appProperties.getShareItApiVersion());
		map.add("secretKey", appProperties.getShareItSecretKey());

		HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<MultiValueMap<String, String>>(map, headers);
		ResponseEntity<String> response = restTemplate.postForEntity(appProperties.getCricPlayShareItApiUrl(), request, String.class);
		
		JSONObject responseData =  new JSONObject(response.getBody());
		
		ShareItToken shareItToken = new ShareItToken();
		
		shareItToken.setMerchantId(appProperties.getShareItMerchantId());
		shareItToken.setOrderId(orderEntity.getOrderId().toString());
		shareItToken.setCusID(userUniqueId);
		shareItToken.setActualAmount(txnAmount);
		shareItToken.setTotalAmount(txnAmount);
		shareItToken.setCallbackUrl(appProperties.getShareItCallBackUrl());
		
		shareItToken.setCurrency(appProperties.getShareItCurrency());
		shareItToken.setSubject(planEntity.getPlanName().toString());
		shareItToken.setCountryCode(AppConstant.countryCode);
		shareItToken.setActualAmount(txnAmount);
		shareItToken.setTotalAmount(txnAmount);
		shareItToken.setToken(responseData.get("data").toString());		

		return shareItToken;
	}
}
