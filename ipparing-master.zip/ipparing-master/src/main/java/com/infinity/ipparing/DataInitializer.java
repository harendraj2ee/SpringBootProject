/*
 * package com.infinity.ipparing;
 * 
 * import java.util.Arrays;
 * 
 * import org.apache.log4j.Logger; import
 * org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.boot.CommandLineRunner; import
 * org.springframework.context.annotation.Bean; import
 * org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder; import
 * org.springframework.security.crypto.password.PasswordEncoder; import
 * org.springframework.stereotype.Component;
 * 
 * import com.infinity.ipparing.entity.User; import
 * com.infinity.ipparing.repository.UserRepository;
 * 
 * @Component public class DataInitializer implements CommandLineRunner {
 * private static final Logger LOGGER = Logger.getLogger(DataInitializer.class);
 * // ...
 * 
 * @Autowired UserRepository users;
 * 
 * @Autowired PasswordEncoder passwordEncoder;
 * 
 * 
 * @Override public void run(String... args) throws Exception { // ... User
 * user= new User(); user.setUsername("admin");
 * user.setPassword(passwordEncoder.encode("admin"));
 * user.setRoles(Arrays.asList("ADMIN")); this.users.save(user);
 * 
 * this.users.save(User.builder().username("admin").password(this.
 * passwordEncoder.encode("password")) .roles(Arrays.asList("ROLE_USER",
 * "ROLE_ADMIN")).build());
 * 
 * this.users.findAll().forEach(v -> LOGGER.debug(" User :" + v.toString())); }
 * 
 * 
 * @Bean PasswordEncoder getEncoder() { return new BCryptPasswordEncoder(); } }
 */