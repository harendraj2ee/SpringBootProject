package com.infinity.ipparing.model;

import java.io.Serializable;
import java.util.List;

public class AsnPrefixVO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String asnNumber;
	private List<String> prefix;
	
	public String getAsnNumber() {
		return asnNumber;
	}
	public void setAsnNumber(String asnNumber) {
		this.asnNumber = asnNumber;
	}
	public List<String> getPrefix() {
		return prefix;
	}
	public void setPrefix(List<String> prefix) {
		this.prefix = prefix;
	}

}
