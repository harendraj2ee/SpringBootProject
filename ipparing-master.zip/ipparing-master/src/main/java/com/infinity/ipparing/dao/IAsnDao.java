package com.infinity.ipparing.dao;


import java.util.List;


import com.infinity.ipparing.entity.AsnEntity;

public interface IAsnDao {
	
	public AsnEntity saveAsn(AsnEntity asnEntity) throws Exception;
	
	public List<String> findAsn(int page, int size) throws Exception;

}
