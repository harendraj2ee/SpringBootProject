package com.infinity.ipparing.model;

import java.io.Serializable;
import java.util.List;

public class AsnPrefixDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String asnNumber;
	
	private String description;
	
	private List<PrefixDTO> listPrefix;

	public String getAsnNumber() {
		return asnNumber;
	}

	public void setAsnNumber(String asnNumber) {
		this.asnNumber = asnNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<PrefixDTO> getListPrefix() {
		return listPrefix;
	}

	public void setListPrefix(List<PrefixDTO> listPrefix) {
		this.listPrefix = listPrefix;
	}

}
