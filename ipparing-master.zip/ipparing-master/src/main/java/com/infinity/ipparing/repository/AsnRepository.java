package com.infinity.ipparing.repository;




import java.util.List;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.infinity.ipparing.entity.AsnEntity;

@Repository
public interface AsnRepository extends PagingAndSortingRepository<AsnEntity, Integer>{
	
	  @Query(value="select distinct asn_number from ipp_asn", nativeQuery = true)
	  public List<String> findAsn(PageRequest pageRequest) throws Exception;
	 

}
