package com.infinity.ipparing.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infinity.common.AsnValidator;
import com.infinity.common.IPAddressValidator;
import com.infinity.config.AppProperties;
import com.infinity.constant.AppConstant;
import com.infinity.ipparing.entity.AsnEntity;
import com.infinity.ipparing.entity.PrefixEntity;
import com.infinity.ipparing.model.AsnPrefixDTO;
import com.infinity.ipparing.model.AsnPrefixVO;
import com.infinity.ipparing.model.EditPrefixes;
import com.infinity.ipparing.model.ListAsnPrefixVo;
import com.infinity.ipparing.model.PrefixDTO;
import com.infinity.ipparing.model.PrefixModifyRequest;
import com.infinity.ipparing.model.Response;
import com.infinity.ipparing.service.IAsnService;
import com.infinity.ipparing.service.IPrefixService;

@CrossOrigin
@RestController
@RequestMapping(value="/ipparing/api/v1")
public class AsnPrefixController {
	
	private static final Logger LOGGER = Logger.getLogger(AsnPrefixController.class);
	
	@Autowired
	IAsnService asnService;
	
	@Autowired
	IPrefixService prefixService;
	
	@Autowired
	IPAddressValidator ipValidator;
	
	@Autowired
	AsnValidator asnValidator;
	
	@Autowired
	AppProperties appProperties;
	
	
	/**
	 * 
	 * @param asnPrefixDto
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/asn", method = RequestMethod.POST, headers = "Accept=application/json")
	public ResponseEntity<Response> saveAsnAndPrefix(@RequestBody AsnPrefixDTO asnPrefixDto, HttpServletRequest request)
			throws Exception {

		LOGGER.info("AsnPrefixController saveAsnAndPrefix...");
		Response response = new Response();
		Boolean ipFlag=true;
		List<PrefixDTO> listPrefixRequest=asnPrefixDto.getListPrefix();
		for(PrefixDTO prefixdto:listPrefixRequest) {
			ipFlag=ipValidator.validate(prefixdto.getPrefix());
		}
		if(ipFlag) {
		AsnPrefixDTO responseDto = new AsnPrefixDTO();
		AsnEntity asnEntity = new AsnEntity();

		if (!asnPrefixDto.getAsnNumber().isEmpty() && !(asnValidator.validate(asnPrefixDto.getAsnNumber())).isEmpty()) {
			asnEntity.setAsnNumber(asnValidator.validate(asnPrefixDto.getAsnNumber()));
		} else {
			response.setCode("400");
			response.setMessage("asn number not valid");
			return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
		}
		if (!asnPrefixDto.getDescription().isEmpty()) {
			asnEntity.setDescription(asnPrefixDto.getDescription());
		} else {
			asnEntity.setDescription("");
		}
		asnEntity.setCreatedBy(appProperties.getSystem());
		asnEntity.setCreatedOn(new Date());
		asnEntity.setModifiedBy(appProperties.getSystem());
		asnEntity.setModifiedOn(new Date());
		
		AsnEntity responseAsnEntity = asnService.saveAsn(asnEntity);

		if (responseAsnEntity != null) {
			List<PrefixDTO> listPrefix = asnPrefixDto.getListPrefix();
			List<PrefixDTO> list= new ArrayList<>();
			responseDto
					.setAsnNumber(responseAsnEntity.getAsnNumber().isEmpty() ? "" : responseAsnEntity.getAsnNumber());
			responseDto.setDescription(
					responseAsnEntity.getDescription().isEmpty() ? "" : responseAsnEntity.getDescription());
			for (PrefixDTO prefixDTO : listPrefix) {
				PrefixEntity prefixeEntity = mapToPrefixEntity(prefixDTO,responseAsnEntity.getAsnNumber());
				PrefixEntity respPrefixEntity = prefixService.savePrefix(prefixeEntity);
				if (respPrefixEntity != null) {
					PrefixDTO mappedPrefixDto = mapToPrefixDTO(respPrefixEntity);
					list.add(mappedPrefixDto);
				}
			}
			responseDto.setListPrefix(list);
			response.setCode("200");
			response.setMessage("success");
			response.setResponseObj(responseDto);
		}

		else {
			response.setCode("500");
			response.setMessage("Error while saving Asn");
			response.setResponseObj(responseDto);
			return new ResponseEntity<Response>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		}
		else {
			 response.setCode("400");
			 response.setMessage("please enter valid prefix as xx.xx.xx.xx");
			 return new ResponseEntity<Response>(response, HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Response>(response, HttpStatus.OK);

	}
	
	/**
	 * 
	 * @param asnNumber
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/asn", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Response> findByAsnNumber(@RequestParam(value = "asnNumber") String asnNumber, HttpServletRequest request) throws Exception{
		LOGGER.info("AsnPrefixController findByAsnNumber...");
		Response response = new Response();
		AsnPrefixVO asnPrefixVo= new AsnPrefixVO();
		List<PrefixEntity> responseEntity=prefixService.findByAsnNumber(asnNumber,AppConstant.PREFIX_STATUS.ACTIVE.getValue());
		List<String> list = new ArrayList<>();
		for(PrefixEntity prefix: responseEntity) {
			list.add(prefix.getPrefix());
			
		}
		asnPrefixVo.setAsnNumber(asnNumber);
		asnPrefixVo.setPrefix(list);
		response.setCode("200");
		response.setMessage("success");
		response.setResponseObj(asnPrefixVo);
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	/**
	 * 
	 * @param asnNumber
	 * @param prefix
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/asn", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public ResponseEntity<Response> deleteByAsnAndPrefix(@RequestParam(value = "asnNumber") String asnNumber,
			@RequestParam(value = "prefix") String prefix, HttpServletRequest request) throws Exception {
		LOGGER.info("AsnPrefixController deleteByAsnAndPrefix...");
		Response response = new Response();
		AsnPrefixVO asnPrefixVo= new AsnPrefixVO();
		List<String> list = new ArrayList<>();
		Integer count=prefixService.deletByAsnAndPrefix(AppConstant.PREFIX_STATUS.DELETED.getValue(), new Date(), asnNumber, prefix);
		if(count==1) {
			list.add(prefix);
			asnPrefixVo.setAsnNumber(asnNumber);
			asnPrefixVo.setPrefix(list);
			response.setCode("200");
			response.setMessage("success");
			response.setResponseObj(asnPrefixVo);
		}
	
		return new ResponseEntity<Response>(response, HttpStatus.OK);

	}

	/**
	 * 
	 * @param asnNumber
	 * @param prefixNew
	 * @param prefixOld
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/asn", method = RequestMethod.PUT, headers = "Accept=application/json")
	public ResponseEntity<Response> updatePrefix(@RequestBody PrefixModifyRequest prefixModidyRequest,
			HttpServletRequest request) throws Exception {
		LOGGER.info("AsnPrefixController updatePrefix...");
		Response response = new Response();
		AsnPrefixVO asnPrefixVo = new AsnPrefixVO();
		List<String> list = new ArrayList<>();
		List<EditPrefixes> editPrefixesList = prefixModidyRequest.getEditPrefixesList();
		for (EditPrefixes prefixes : editPrefixesList) {
			PrefixEntity prefixEntity = prefixService.findByAsnAndPrefix(prefixModidyRequest.getAsnNumber(),
					prefixes.getOldPrefix());
			if (prefixEntity != null) {
				Integer id = prefixEntity.getId();
				Integer count = prefixService.updatePrefix(prefixes.getNewPrefix(), new Date(), id);
				if (count == 1) {
					list.add(prefixes.getNewPrefix());
					asnPrefixVo.setAsnNumber(prefixEntity.getAsnNumber());
					asnPrefixVo.setPrefix(list);
					response.setCode("200");
					response.setMessage("success");
					response.setResponseObj(asnPrefixVo);
				}
			}
		}

		return new ResponseEntity<Response>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/asn/getAll", method = RequestMethod.GET, headers = "Accept=application/json")
	public ResponseEntity<Response> findAllAsn(@RequestParam(value = "page") int page, @RequestParam(value = "size") int size, HttpServletRequest request) throws Exception{
		LOGGER.info("AsnPrefixController findByAsnNumber...");
		Response response = new Response();
		
		List<String> list = new ArrayList<>();
		List<AsnPrefixVO> listAsnPrefixVo=new ArrayList<>();
		List<String> listAsn = asnService.findAsn(page, size);
		for (String asn : listAsn) {
			AsnPrefixVO asnPrefixVo = new AsnPrefixVO();
			List<PrefixEntity> responseEntity = prefixService.findByAsnNumber(asn,
					AppConstant.PREFIX_STATUS.ACTIVE.getValue());
			
			for(PrefixEntity prefix: responseEntity) {
				list.add(prefix.getPrefix());
				
			}
			asnPrefixVo.setAsnNumber(asn);
			asnPrefixVo.setPrefix(list);
			listAsnPrefixVo.add(asnPrefixVo);
		}
		response.setCode("200");
		response.setMessage("success");
		response.setResponseObj(listAsnPrefixVo);
		return new ResponseEntity<Response>(response, HttpStatus.OK);	
	}
	
	
	
	/**
	 * 
	 * @param prefixDTO
	 * @return
	 */
	private PrefixEntity mapToPrefixEntity(PrefixDTO prefixDTO,String asnNumber) {
		PrefixEntity prefixEntity = new PrefixEntity();
		prefixEntity.setAsnNumber(asnNumber);
		prefixEntity.setPrefix(prefixDTO.getPrefix().isEmpty() ? "" : prefixDTO.getPrefix());
		prefixEntity.setStatus(AppConstant.PREFIX_STATUS.ACTIVE.getValue());
		prefixEntity.setCreatedBy(appProperties.getSystem());
		prefixEntity.setCreatedOn(new Date());
		prefixEntity.setModifiedBy(appProperties.getSystem());
		prefixEntity.setModifiedOn(new Date());
		return prefixEntity;
	}

	/**
	 * 
	 * @param prefixEntity
	 * @return
	 */
	private PrefixDTO mapToPrefixDTO(PrefixEntity prefixEntity) {
		PrefixDTO prefixDTO = new PrefixDTO();
		//prefixDTO.setAsnNumber(asnNumber);
		prefixDTO.setPrefix(prefixEntity.getPrefix().isEmpty() ? "" : prefixEntity.getPrefix());
		return prefixDTO;

	}
}
