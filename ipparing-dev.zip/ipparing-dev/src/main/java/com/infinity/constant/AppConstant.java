package com.infinity.constant;

public class AppConstant {

	public enum PREFIX_STATUS{
		
		ACTIVE("active"), DELETED("deleted");
		
		private final String prefixStatus;
		
		public String getValue() {
			return this.prefixStatus;
		}
		
		private PREFIX_STATUS(String prefixStatus) {
			this.prefixStatus = prefixStatus;
		}
	}
}
