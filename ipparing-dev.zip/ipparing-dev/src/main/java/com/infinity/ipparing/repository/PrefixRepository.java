package com.infinity.ipparing.repository;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.infinity.ipparing.entity.PrefixEntity;

@Repository
public interface PrefixRepository extends JpaRepository<PrefixEntity, Integer>{
	
	@Query(value = "SELECT * FROM ipp_prefix where asn_number=? and status=?", nativeQuery = true)
	public List<PrefixEntity> findByAsnNumber(String asnNumber,String status);
	
	@Transactional
	@Modifying
	@Query(value = "update ipp_prefix set status=?, modified_on=? where asn_number=? and prefix=?", nativeQuery = true)
	public int deleteByAsnAndPrefix(String status, Date date, String asnNumber, String prefix);
	
	@Transactional
	@Modifying
	@Query(value ="update ipp_prefix set prefix=?, modified_on=? where id=?", nativeQuery=true)
	public int updatePrefixByAsn(String prefix, Date date, Integer id);
	
	@Query(value ="select * from ipp_prefix where asn_number=? and prefix=?", nativeQuery=true)
	public PrefixEntity findByAsnAndPrefix(String asn,String prefix);

}
