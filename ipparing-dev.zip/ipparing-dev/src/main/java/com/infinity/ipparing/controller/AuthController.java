
package com.infinity.ipparing.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.infinity.config.AppProperties;
import com.infinity.ipparing.model.LoginUser;
import com.infinity.ipparing.model.Response;
import com.infinity.ipparing.service.ITokenService;

@CrossOrigin
@RestController
@RequestMapping(value="/ipparing/api/v1")
public class AuthController {
	
	private static final Logger LOGGER = Logger.getLogger(AuthController.class);
	
	@Autowired
	ITokenService tokenService;
	
	@Autowired
	AppProperties appProperties;
	

	 @RequestMapping(value = "/signin", method = RequestMethod.POST, headers = "Accept=application/json")
	 public ResponseEntity<Response> signin(@RequestBody LoginUser loginUser) {
		LOGGER.info("AsnPrefixController generateToken...");
		Response response = new Response();
		try {
			String token=tokenService.generateJwtToken(loginUser);
			response.setCode("200");
			response.setMessage("success");
			response.setResponseObj(token);
		} catch (Exception e) {
			LOGGER.info("GenerateToken Exception ::"+e.getMessage());
		}
	
		return new ResponseEntity<Response>(response, HttpStatus.OK);
	 }
	 
	 @RequestMapping(value = "/validate-token", method = RequestMethod.GET, headers = "Accept=application/json")
	 public ResponseEntity<String> validateToken(HttpServletRequest request){
			LOGGER.info("TokenServiceImpl validateToken...");
			String token=request.getHeader("Authorization");
			RestTemplate restTemplate = new RestTemplate();
			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", token);
			HttpEntity<String> entity = new HttpEntity<String>(headers);
			ResponseEntity<String> response = null;
			try {
				response = restTemplate.exchange(appProperties.getVerifyTokenUrl(), HttpMethod.GET, entity, String.class);
				LOGGER.info("AsnPrefixController validateToken ::" + response.getBody().toString());
			} catch (Exception e) {
				LOGGER.info("Exception ::" + e.getMessage());
			}
		 
			return new ResponseEntity<String>(response.getBody().toString(), HttpStatus.OK);
		 
	 }
}
