package com.infinity.ipparing.model;

import java.io.Serializable;
import java.util.List;

public class ListAsnPrefixVo implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	List<AsnPrefixVO> listAsnPrefixVo;

	public List<AsnPrefixVO> getListAsnPrefixVo() {
		return listAsnPrefixVo;
	}

	public void setListAsnPrefixVo(List<AsnPrefixVO> listAsnPrefixVo) {
		this.listAsnPrefixVo = listAsnPrefixVo;
	}

}
