package com.infinity.ipparing.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinity.ipparing.dao.IAsnDao;
import com.infinity.ipparing.entity.AsnEntity;

@Service
public class AsnServiceImpl implements IAsnService{
	
	private static final Logger logger = Logger.getLogger(AsnServiceImpl.class);
	
	@Autowired
	IAsnDao asnDao;

	@Override
	public AsnEntity saveAsn(AsnEntity asnEntity) throws Exception{
		logger.info("calling AsnServiceImpl saveAsn...");
		return asnDao.saveAsn(asnEntity);
	}

	@Override
	public List<String> findAsn(int page, int size) throws Exception {
		return asnDao.findAsn(page, size);
	}

	@Override
	public int getAllAsnCount() throws Exception {
		return asnDao.getAllAsnCount();
	}

}
