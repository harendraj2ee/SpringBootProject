package com.infinity.ipparing.service;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infinity.ipparing.dao.IPrefixDao;
import com.infinity.ipparing.entity.PrefixEntity;

@Service
public class PrefixServiceImpl implements IPrefixService{
	
	private static final Logger logger = Logger.getLogger(PrefixServiceImpl.class);
	
	@Autowired
	IPrefixDao prefixDao;

	@Override
	public PrefixEntity savePrefix(PrefixEntity prefixEntity) throws Exception{
		logger.info("PrefixServiceImpl savePrefix...");
		return prefixDao.savePrefix(prefixEntity);
	}

	@Override
	public List<PrefixEntity> findByAsnNumber(String asnNumber,String status) throws Exception {
		logger.info("PrefixServiceImpl findByAsnNumber...");
		return prefixDao.findByAsnNumber(asnNumber,status);
	}

	@Override
	public int deletByAsnAndPrefix(String status, Date date, String asnNumber, String prefix)
			throws Exception {
		logger.info("PrefixServiceImpl deletByAsnAndPrefix...");
		return prefixDao.deleteByAsnAndPrefix(status, date, asnNumber, prefix);
	}

	@Override
	public PrefixEntity findByAsnAndPrefix(String asn, String prefix) throws Exception {
		logger.info("PrefixServiceImpl findByAsnAndPrefix...");
		return prefixDao.findByAsnAndPrefix(asn, prefix);
	}

	@Override
	public Integer updatePrefix(String prefix, Date date, Integer id) throws Exception {
		logger.info("PrefixServiceImpl updatePrefix...");
		return prefixDao.updatePrefix(prefix, date, id);
	}

}
