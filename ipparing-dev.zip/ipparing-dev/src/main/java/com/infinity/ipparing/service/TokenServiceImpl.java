package com.infinity.ipparing.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infinity.config.AppProperties;
import com.infinity.ipparing.model.LoginUser;

@Service
public class TokenServiceImpl implements ITokenService{

	private static final Logger LOGGER = Logger.getLogger(TokenServiceImpl.class);
	
	@Autowired
	AppProperties appProperties;
	
	@Override
	public String generateJwtToken(LoginUser loginUser) {
		LOGGER.info("TokenServiceImpl generateJwtToken...");
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		ObjectMapper Obj = new ObjectMapper();
		String jsonStr;
		ResponseEntity<String> token = null;
		try {
			jsonStr = Obj.writeValueAsString(loginUser);
			HttpEntity<String> entity = new HttpEntity<String>(jsonStr, headers);
			token = restTemplate.postForEntity(appProperties.getGenerateTokenUrl(), entity, String.class);

		} catch (Exception e) {
			LOGGER.info("Exception ::" + e.getMessage());
		}
		return token.getBody().toString();
	}

	@Override
	public Map<String,Object> validateToken(String token) {
		Map<String,Object> responseMap=new HashMap<>();
		LOGGER.info("TokenServiceImpl validateToken...");
		RestTemplate restTemplate = new RestTemplate();
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", token);
		HttpEntity<String> entity = new HttpEntity<String>(headers);
		ResponseEntity<String> response = null;
		try {
			response = restTemplate.exchange(appProperties.getVerifyTokenUrl(), HttpMethod.GET, entity, String.class);
			responseMap.put("response", response.getBody().toString());
			LOGGER.info("AsnPrefixController validateToken ::" + response.getBody().toString());
		} catch (Exception e) {
			LOGGER.info("Exception ::" + e.getMessage());
		}
		return responseMap;
	}

}
