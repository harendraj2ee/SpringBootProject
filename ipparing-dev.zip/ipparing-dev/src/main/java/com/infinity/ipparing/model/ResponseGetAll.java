package com.infinity.ipparing.model;

public class ResponseGetAll extends Response{
	
	private int totalCount;

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

}
