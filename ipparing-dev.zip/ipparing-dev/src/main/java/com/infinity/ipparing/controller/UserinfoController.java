/*
 * package com.infinity.ipparing.controller;
 * 
 * import java.util.HashMap; import java.util.Map; import
 * java.util.stream.Collectors;
 * 
 * import org.apache.log4j.Logger; import org.springframework.http.HttpStatus;
 * import org.springframework.http.ResponseEntity; import
 * org.springframework.security.core.GrantedAuthority; import
 * org.springframework.security.core.annotation.AuthenticationPrincipal; import
 * org.springframework.security.core.userdetails.UserDetails; import
 * org.springframework.web.bind.annotation.CrossOrigin; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RequestMethod; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * import com.infinity.ipparing.model.Response;
 * 
 * @CrossOrigin
 * 
 * @RestController
 * 
 * @RequestMapping(value="/ipparing/api/v1") public class UserinfoController {
 * private static final Logger LOGGER =
 * Logger.getLogger(UserinfoController.class);
 * 
 * @RequestMapping(value = "/me", method = RequestMethod.GET, headers =
 * "Accept=application/json") public ResponseEntity<Response>
 * currentUser(@AuthenticationPrincipal UserDetails userDetails){
 * LOGGER.info("UserinfoController currentUser..."); Response response = new
 * Response(); Map<Object, Object> model = new HashMap<>();
 * model.put("username", userDetails.getUsername()); model.put("roles",
 * userDetails.getAuthorities() .stream() .map(a -> ((GrantedAuthority)
 * a).getAuthority()) .collect(Collectors.toList()) );
 * response.setResponseObj(model); return new ResponseEntity<Response>(response,
 * HttpStatus.OK); } }
 * 
 */