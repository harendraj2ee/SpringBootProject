package com.infinity.ipparing.dao;

import java.util.Date;
import java.util.List;

import com.infinity.ipparing.entity.PrefixEntity;

public interface IPrefixDao {
	
	public PrefixEntity savePrefix(PrefixEntity prefixEntity) throws Exception;
	
	public List<PrefixEntity> findByAsnNumber(String asnNumber,String status) throws Exception;
	
	public int deleteByAsnAndPrefix(String status,Date date,String asnNumber,String prefix) throws Exception;
	
	public PrefixEntity findByAsnAndPrefix(String asn,String prefix) throws Exception;
	
	public int updatePrefix(String prefix,Date date,Integer id);

}
