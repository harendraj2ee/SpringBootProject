package com.infinity.ipparing.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Repository;

import com.infinity.ipparing.entity.AsnEntity;
import com.infinity.ipparing.repository.AsnRepository;

@Repository
public class AsnDaoImpl implements IAsnDao{
	
	@Autowired
	AsnRepository asnRepository;
	
	@Override
	public AsnEntity saveAsn(AsnEntity asnEntity) throws Exception {
		return asnRepository.save(asnEntity);
	}

	@Override
	public List<String> findAsn(int page, int size) throws Exception {
		
		return asnRepository.findAsn(new PageRequest(page, size));
	}

	@Override
	public int getAllAsnCount() throws Exception {
		return asnRepository.getAllAsnCount();
	}

}
