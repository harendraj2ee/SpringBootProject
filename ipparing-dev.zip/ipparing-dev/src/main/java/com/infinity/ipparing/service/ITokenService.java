package com.infinity.ipparing.service;

import java.util.Map;

import com.infinity.ipparing.model.LoginUser;

public interface ITokenService {
	
	public String generateJwtToken(LoginUser loginUser);
	
	public Map<String,Object> validateToken(String token);

}
