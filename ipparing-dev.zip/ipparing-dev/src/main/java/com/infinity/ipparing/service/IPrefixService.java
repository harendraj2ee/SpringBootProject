package com.infinity.ipparing.service;

import java.util.Date;
import java.util.List;

import com.infinity.ipparing.entity.PrefixEntity;

public interface IPrefixService {
	
	public PrefixEntity savePrefix(PrefixEntity prefixEntity) throws Exception;
	
	public List<PrefixEntity> findByAsnNumber(String asnNumber,String status) throws Exception;
	
	public int deletByAsnAndPrefix(String status,Date date,String asnNumber,String prefix) throws Exception;
	
	public PrefixEntity findByAsnAndPrefix(String asn, String prefix) throws Exception;
	
	public Integer updatePrefix(String prefix, Date date,Integer id) throws Exception;

}
