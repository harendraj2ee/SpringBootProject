package com.infinity.ipparing.model;

import java.util.List;

public class PrefixModifyRequest {
	
	private String asnNumber;
	List<EditPrefixes> editPrefixesList;

	public String getAsnNumber() {
		return asnNumber;
	}

	public void setAsnNumber(String asnNumber) {
		this.asnNumber = asnNumber;
	}

	public List<EditPrefixes> getEditPrefixesList() {
		return editPrefixesList;
	}

	public void setEditPrefixesList(List<EditPrefixes> editPrefixesList) {
		this.editPrefixesList = editPrefixesList;
	}

}
