package com.infinity.ipparing.dao;

import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.infinity.ipparing.controller.AsnPrefixController;
import com.infinity.ipparing.entity.PrefixEntity;
import com.infinity.ipparing.repository.PrefixRepository;

@Repository
public class PrefixDaoImpl implements IPrefixDao{
	
	private static final Logger LOGGER = Logger.getLogger(AsnPrefixController.class);
	
	@Autowired
	PrefixRepository prefixRepository;

	@Override
	public PrefixEntity savePrefix(PrefixEntity prefixEntity) throws Exception {
		LOGGER.info("PrefixDaoImpl savePrefix..");
		return prefixRepository.save(prefixEntity);
	}

	@Override
	public List<PrefixEntity> findByAsnNumber(String asnNumber,String status) throws Exception {
		LOGGER.info("PrefixDaoImpl findByAsnNumber...");
		return prefixRepository.findByAsnNumber(asnNumber,status);
	}

	@Override
	public int deleteByAsnAndPrefix(String status, Date date, String asnNumber,String prefix) throws Exception {
		LOGGER.info("PrefixDaoImpl deleteByAsnAndPrefix...");
		return prefixRepository.deleteByAsnAndPrefix(status, date, asnNumber, prefix);
	}

	@Override
	public PrefixEntity findByAsnAndPrefix(String asn, String prefix) throws Exception {
		LOGGER.info("PrefixDaoImpl findByAsnAndPrefix...");
		return prefixRepository.findByAsnAndPrefix(asn, prefix);
	}

	@Override
	public int updatePrefix(String prefix, Date date,Integer id) {
		LOGGER.info("PrefixDaoImpl updatePrefixByAsn...");
		return prefixRepository.updatePrefixByAsn(prefix, date, id);
	}


}
