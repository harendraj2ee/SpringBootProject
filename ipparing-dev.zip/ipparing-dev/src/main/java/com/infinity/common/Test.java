package com.infinity.common;

public class Test {
	public static void main(String[] args) {
		String str="{\\\"ROLE_USER\\\":\\\"true\\\",\\\"ROLE_ADMIN\\\":\\\"true\\\",\\\"isValidToken\\\":\\\"true\\\"}";
		String result=str.replace("\\", "");
		System.out.println(result);
	}

}
