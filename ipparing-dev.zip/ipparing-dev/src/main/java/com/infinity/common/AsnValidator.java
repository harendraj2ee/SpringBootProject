package com.infinity.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.stereotype.Component;

@Component
public class AsnValidator {
	
	/**
	 * 
	 * 
	 * RANDONMSTRING120001 - vALID, has area of intrest
	 * 
	 * ASN120asdasd001 - INvALID, Doesnt has area of intrest
	 * 
	 * 120001asn - vALID, has area of intrest
	 * 
	 * 120001- vALID, has area of intrest
	 * 
	 * RANDONMSTRING -INvALID, Doesnt has area of intrest
	 * 
	 */

	private static Pattern pattern;
	private static Matcher matcher;

	private static final String ASN_PATTERN = "([a-z]+\\d+)|(\\d+[a-z]*)$";
	
	private static final String ASN_PATTERN1="\\d+";

	public String validate(String asnNumber) {
		
		pattern = Pattern.compile(ASN_PATTERN);
		matcher = pattern.matcher(asnNumber);
		boolean matches= matcher.matches();
		String result="";
		if(matches) {
			pattern = Pattern.compile(ASN_PATTERN1);
			matcher = pattern.matcher(asnNumber);
			matcher.find();
			//System.out.println(matcher.group());
			result=matcher.group();
		}
		return result;
	}
	
	
	/*
	 * public static void main(String[] args) {
	 * System.out.println(validate("adsadsada12321321321")); //valid
	 * System.out.println(validate("fdsgfdsg")); //invalid
	 * System.out.println(validate("3434dsgfds")); //valid
	 * System.out.println(validate("435435")); //valid
	 * System.out.println(validate("adsadsada1232132132146fdgfdgd"));//invalid
	 * System.out.println(validate("3434dsgfds3454354"));//invalid
	 * 
	 * 
	 * }
	 */
	 
	 
}
