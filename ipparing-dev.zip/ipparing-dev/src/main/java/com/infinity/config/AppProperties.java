package com.infinity.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AppProperties {

	@Value("${com.infinity.system}")
	String system;
	
	@Value("${com.infinity.generate.token.url}")
	String generateTokenUrl;
	
	@Value("${com.infinity.verify.token.url}")
	String verifyTokenUrl;
	
	@Value("${com.infinity.ipparing.auth}")
	String auth;

	public String getSystem() {
		return system;
	}

	public void setSystem(String system) {
		this.system = system;
	}

	public String getGenerateTokenUrl() {
		return generateTokenUrl;
	}

	public void setGenerateTokenUrl(String generateTokenUrl) {
		this.generateTokenUrl = generateTokenUrl;
	}

	public String getVerifyTokenUrl() {
		return verifyTokenUrl;
	}

	public void setVerifyTokenUrl(String verifyTokenUrl) {
		this.verifyTokenUrl = verifyTokenUrl;
	}

	public String getAuth() {
		return auth;
	}

	public void setAuth(String auth) {
		this.auth = auth;
	}
	
}
